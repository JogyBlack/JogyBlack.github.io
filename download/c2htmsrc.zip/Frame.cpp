//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include <vcl\Clipbrd.hpp>
#include <vcl\Registry.hpp>

#include <fstream>
#include <sstream>

#include "Frame.h"
#include "About.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "CGRID"
#pragma resource "*.dfm"
TFormMain *FormMain;
//---------------------------------------------------------------------------
__fastcall TFormMain::TFormMain(TComponent* Owner)
  : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TFormMain::FormCreate(TObject *Sender)
{
  Pages->ActivePageIndex = 0;

  ComboBoxInputFile->Text = "";
  ComboBoxOutputFile->Text = "";
  ComboBoxKeywords->Text = "";

  AddColors(ComboBoxColor);
  AddColors(ComboBoxTextColor);
  AddColors(ComboBoxBkColor);

  TRegistryIniFile *iniFile = new TRegistryIniFile("Software\\JogySoft\\C2HTML");

  ReadFileNames(iniFile, ComboBoxInputFile, "InputFiles");
  ReadFileNames(iniFile, ComboBoxOutputFile, "OutputFiles");
  ReadFileNames(iniFile, ComboBoxKeywords, "KeywordFiles");

  CheckBoxPreview->Checked = iniFile->ReadInteger("Options", "Preview", true);

  ReadOptions(iniFile);

  delete iniFile;

  CheckBoxFullPage->Checked = options.fullpage;
  CheckBoxLowercase->Checked = options.lowercase;
  CheckBoxCompact->Checked = options.compact;

  UpDownTabSpaces->Position = options.tabspaces;

  SetColor(ComboBoxTextColor, options.txtcolor.c_str());
  SetColor(ComboBoxBkColor, options.bkcolor.c_str());

  ListBoxElements->ItemIndex = 0;

  ListBoxElementsClick(this);

}
//---------------------------------------------------------------------------
void __fastcall TFormMain::FormDestroy(TObject *Sender)
{
  TRegistryIniFile *iniFile = new TRegistryIniFile("Software\\JogySoft\\C2HTML");

  WriteFileNames(iniFile, ComboBoxInputFile, "InputFiles");
  WriteFileNames(iniFile, ComboBoxOutputFile, "OutputFiles");
  WriteFileNames(iniFile, ComboBoxKeywords, "KeywordFiles");

  iniFile->WriteInteger("Options", "Preview", CheckBoxPreview->Checked);

  WriteOptions(iniFile);

  delete iniFile;
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::BitBtnQuitClick(TObject *Sender)
{
  Close();
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::RadioButtonInputFileClick(TObject *Sender)
{
  ComboBoxInputFile->Enabled = true;
  ButtonInputBrowse->Enabled = true;
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::RadioButtonInputClipboardClick(TObject *Sender)
{
  ComboBoxInputFile->Enabled = false;
  ButtonInputBrowse->Enabled = false;
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::RadioButtonOutputFileClick(TObject *Sender)
{
  ComboBoxOutputFile->Enabled = true;
  ButtonOutputBrowse->Enabled = true;
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::RadioButtonOutputClipboardClick(TObject *Sender)
{
  ComboBoxOutputFile->Enabled = false;
  ButtonOutputBrowse->Enabled = false;
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::ButtonInputBrowseClick(TObject *Sender)
{
  OpenDialogInput->FileName = ComboBoxInputFile->Text;
  if (OpenDialogInput->Execute())
    ComboBoxInputFile->Text = OpenDialogInput->FileName;
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::ButtonOutputBrowseClick(TObject *Sender)
{
  SaveDialogOutput->FileName = ComboBoxOutputFile->Text;
  if (SaveDialogOutput->Execute())
    ComboBoxOutputFile->Text = SaveDialogOutput->FileName;
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::BitBtnConvertClick(TObject *Sender)
{
  std::istream *is = 0;
  std::ostream *os = 0;

  std::ifstream ifs;
  std::ofstream ofs;

  std::istringstream iss;
  std::ostringstream oss;

  if (RadioButtonInputFile->Checked)
  {
    ifs.open(ComboBoxInputFile->Text.c_str());
    if (!ifs)
    {
      AnsiString msg = "Cannot open file " + ComboBoxInputFile->Text;
      Application->MessageBox(msg.c_str(), "C2HTML", MB_OK);
      return;
    }
    is = &ifs;

    AddComboBoxString(ComboBoxInputFile);
  }
  else
  {
    if (Clipboard()->HasFormat(CF_TEXT) && Clipboard()->AsText.Length() > 0)
      iss.str(Clipboard()->AsText.c_str());
    else
    {
      Application->MessageBox("Clipboard is empty", "C2HTML", MB_OK);
      return;
    }

    is = &iss;
  }

  if (RadioButtonOutputFile->Checked)
  {
    ofs.open(ComboBoxOutputFile->Text.c_str());
    if (!ofs)
    {
      AnsiString msg = "Cannot create file " + ComboBoxOutputFile->Text;
      Application->MessageBox(msg.c_str(), "C2HTML", MB_OK);
      return;
    }
    os = &ofs;

    AddComboBoxString(ComboBoxOutputFile);
  }
  else
  {
    os = &oss;
  }

  StringArray keywords;
  std::ifstream tok(ComboBoxKeywords->Text.c_str());
  if (tok)
  {
    keywords.Read(tok);

    AddComboBoxString(ComboBoxKeywords);
  }

  bool result = C2HTML(*is, *os, keywords, options, std::string(ComboBoxInputFile->Text.c_str())).Convert();

  if (result)
  {
    if (RadioButtonInputFile->Checked)
    {
      if (CheckBoxPreview->Enabled && CheckBoxPreview->Checked)
        ShellExecute(Handle, "open", ComboBoxOutputFile->Text.c_str(), NULL, "", SW_SHOWDEFAULT);
    }
    else
    {
      oss << std::ends;

      Clipboard()->AsText = oss.str().c_str();
    }
  }

}
//---------------------------------------------------------------------------
void __fastcall TFormMain::CheckBoxFullPageClick(TObject *Sender)
{
  CheckBoxPreview->Enabled = CheckBoxFullPage->Checked;

  options.fullpage = CheckBoxFullPage->Checked;
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::CheckBoxLowercaseClick(TObject *Sender)
{
  options.lowercase = CheckBoxLowercase->Checked;
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::CheckBoxCompactClick(TObject *Sender)
{
  options.compact = CheckBoxCompact->Checked;
}
//---------------------------------------------------------------------------

void __fastcall TFormMain::EditTabSpacesChange(TObject *Sender)
{
  options.tabspaces = EditTabSpaces->Text.ToInt();
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::ListBoxElementsClick(TObject *Sender)
{
  C2HTML::Options::Formatting *formatting = GetSelectedFormatting();

  if (formatting)
  {
    CheckBoxBold->Enabled = true;
    CheckBoxItalic->Enabled = true;
    CheckBoxUnderline->Enabled = true;

    CheckBoxBold->Checked = formatting->bold;
    CheckBoxItalic->Checked = formatting->italic;
    CheckBoxUnderline->Checked = formatting->underline;

    SetColor(ComboBoxColor, formatting->color.c_str());
  }
  else
  {
    CheckBoxBold->Enabled = false;
    CheckBoxItalic->Enabled = false;
    CheckBoxUnderline->Enabled = false;

    SetColor(ComboBoxColor, "");
  }
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::CheckBoxBoldClick(TObject *Sender)
{
  C2HTML::Options::Formatting *formatting = GetSelectedFormatting();

  if (formatting)
    formatting->bold = CheckBoxBold->Checked;
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::CheckBoxItalicClick(TObject *Sender)
{
  C2HTML::Options::Formatting *formatting = GetSelectedFormatting();

  if (formatting)
    formatting->italic = CheckBoxItalic->Checked;
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::CheckBoxUnderlineClick(TObject *Sender)
{
  C2HTML::Options::Formatting *formatting = GetSelectedFormatting();

  if (formatting)
    formatting->underline = CheckBoxUnderline->Checked;
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::ComboBoxColorChange(TObject *Sender)
{
  C2HTML::Options::Formatting *formatting = GetSelectedFormatting();

  if (formatting)
    formatting->color = GetColor(ComboBoxColor).c_str();
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::ComboBoxTextColorChange(TObject *Sender)
{
  options.txtcolor = GetColor(ComboBoxTextColor).c_str();
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::ComboBoxBkColorChange(TObject *Sender)
{
  options.bkcolor = GetColor(ComboBoxBkColor).c_str();
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::BitBtnAboutClick(TObject *Sender)
{
  FormAbout->ShowModal();
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::ButtonBrowseKeywordsClick(TObject *Sender)
{
  OpenDialogKeywords->FileName = ComboBoxKeywords->Text;
  if (OpenDialogKeywords->Execute())
    ComboBoxKeywords->Text = OpenDialogKeywords->FileName;
}
//---------------------------------------------------------------------------
C2HTML::Options::Formatting * TFormMain::GetSelectedFormatting()
{
  if (ListBoxElements->ItemIndex < 0)
    return 0;

  AnsiString str = ListBoxElements->Items->Strings[ListBoxElements->ItemIndex];
  if (str == "Comment")
    return &options.comment;
  else if (str == "Directive")
    return &options.directive;
  else if (str == "Constant")
    return &options.constant;
  else if (str == "Keyword")
    return &options.keyword;

  return 0;
}
//---------------------------------------------------------------------------
void TFormMain::AddColors(TComboBox *combo)
{
  combo->Items->Add("<none>");
  combo->Items->Add("Aqua");
  combo->Items->Add("Black");
  combo->Items->Add("Blue");
  combo->Items->Add("Fuchsia");
  combo->Items->Add("Gray");
  combo->Items->Add("Green");
  combo->Items->Add("Lime");
  combo->Items->Add("Maroon");
  combo->Items->Add("Navy");
  combo->Items->Add("Olive");
  combo->Items->Add("Purple");
  combo->Items->Add("Red");
  combo->Items->Add("Silver");
  combo->Items->Add("Teal");
  combo->Items->Add("Yellow");
  combo->Items->Add("White");
  combo->Items->Add("Other...");
}
//---------------------------------------------------------------------------
void TFormMain::SetColor(TComboBox *combo, const AnsiString &color)
{
  AnsiString temp(color);
  if (temp.Length() == 0)
    temp = "<none>";

  int index = combo->Items->IndexOf(temp);

  if (index < 0)
  {
    index = 0;
    combo->Items->Insert(0, temp);
  }

  combo->ItemIndex = index;
}
//---------------------------------------------------------------------------
AnsiString TFormMain::GetColor(TComboBox *combo)
{
  AnsiString color = combo->Text;
  if (color == "<none>")
    color = "";
  else if (color == "Other...")
  {
    if (ColorDialogSyntax->Execute())
    {
      char buf[10];
      wsprintf(buf, "#%02X%02x%02x",
               (ColorDialogSyntax->Color & 0xFF0000) >> 16,
               (ColorDialogSyntax->Color & 0x00FF00) >> 8,
               ColorDialogSyntax->Color & 0x0000FF);
      color = buf;
      SetColor(combo, color);
    }
    else
      color = "";
  }

  return color;
}
//---------------------------------------------------------------------------
void TFormMain::AddComboBoxString(TComboBox *combo)
{
  if (combo->Items->IndexOf(combo->Text) == -1)
    combo->Items->Insert(0, combo->Text);
}
//---------------------------------------------------------------------------
void TFormMain::ReadOptions(TRegistryIniFile *iniFile)
{
  options.lowercase = iniFile->ReadInteger("Options", "LowerCase", options.lowercase);
  options.compact = iniFile->ReadInteger("Options", "Compact", options.compact);
  options.fullpage = iniFile->ReadInteger("Options", "FullPage", options.fullpage);
  options.tabspaces = iniFile->ReadInteger("Options", "TabSpaces", options.tabspaces);

  ReadFormatting(iniFile, "Comment", &options.comment);
  ReadFormatting(iniFile, "Directive", &options.directive);
  ReadFormatting(iniFile, "Constant", &options.constant);
  ReadFormatting(iniFile, "Keyword", &options.keyword);
}
//---------------------------------------------------------------------------
void TFormMain::WriteOptions(TRegistryIniFile *iniFile)
{
  iniFile->WriteInteger("Options", "LowerCase", options.lowercase);
  iniFile->WriteInteger("Options", "Compact", options.compact);
  iniFile->WriteInteger("Options", "FullPage", options.fullpage);
  iniFile->WriteInteger("Options", "TabSpaces", options.tabspaces);

  WriteFormatting(iniFile, "Comment", &options.comment);
  WriteFormatting(iniFile, "Directive", &options.directive);
  WriteFormatting(iniFile, "Constant", &options.constant);
  WriteFormatting(iniFile, "Keyword", &options.keyword);
}
//---------------------------------------------------------------------------
void TFormMain::ReadFormatting(TRegistryIniFile *iniFile, const AnsiString &name, C2HTML::Options::Formatting *formatting)
{
  formatting->bold = iniFile->ReadInteger("Options\\" + name, "Bold", formatting->bold);
  formatting->italic = iniFile->ReadInteger("Options\\" + name, "Italic", formatting->italic);
  formatting->underline = iniFile->ReadInteger("Options\\" + name, "Underline", formatting->underline);
  formatting->color = iniFile->ReadString("Options\\" + name, "Underline", formatting->color.c_str()).c_str();
}
//---------------------------------------------------------------------------
void TFormMain::WriteFormatting(TRegistryIniFile *iniFile, const AnsiString &name, C2HTML::Options::Formatting *formatting)
{
  iniFile->WriteInteger("Options\\" + name, "Bold", formatting->bold);
  iniFile->WriteInteger("Options\\" + name, "Italic", formatting->italic);
  iniFile->WriteInteger("Options\\" + name, "Underline", formatting->underline);
  iniFile->WriteString("Options\\" + name, "Underline", formatting->color.c_str());
}
//---------------------------------------------------------------------------
void TFormMain::ReadFileNames(TRegistryIniFile *iniFile, TComboBox *combo, const AnsiString &name)
{
  int count = iniFile->ReadInteger(name, "Count", 0);
  for (int index = 0; index < count; index++)
    combo->Items->Add(iniFile->ReadString(name, Format("File%d", ARRAYOFCONST((index))), ""));
  if (combo->Items->Count > 0)
    combo->ItemIndex = 0;
}
//---------------------------------------------------------------------------
void TFormMain::WriteFileNames(TRegistryIniFile *iniFile, TComboBox *combo, const AnsiString &name)
{
  iniFile->WriteInteger(name, "Count", combo->Items->Count);
  for (int index = 0; index < combo->Items->Count; index++)
    iniFile->WriteString(name, Format("File%d", ARRAYOFCONST((index))), combo->Items->Strings[index]);
}
//---------------------------------------------------------------------------

