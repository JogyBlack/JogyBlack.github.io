/*
 * c2html.c
 *
 * Converts c and c++ code into HTML for publishing on the WWW
 * Copyright (C) 1996 Christopher Kohlhoff (chris@kohlhoff.com)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>


/*********************************************************************
 * Structures and Definitions
 */

/* StringArray structure for a sorted list of keywords */
typedef struct StringArray
{
  char** strings;
  int num;
} StringArray;

#define MAXIDENT 512
#define MAXLINE  512



/*********************************************************************
 * Function declarations
 */

void ConvertCodeToHtml(const char* filename, const char* kwfile, FILE* stream);
void WriteHtmlChar(char c, FILE* stream);
void WriteHtmlString(const char* str, FILE* stream);

/* functions dealing with highlighting */
void BeginCode(FILE* stream);
void EndCode(FILE* stream);
void BeginComment(FILE* stream);
void EndComment(FILE* stream);
void BeginDirective(FILE* stream);
void EndDirective(FILE* stream);
void BeginConstant(FILE* stream);
void EndConstant(FILE* stream);
void BeginKeyword(FILE* stream);
void EndKeyword(FILE* stream);

/* StringArray functions */
void  StringArrayRead(StringArray *array, const char* filename);
char* StringArrayFind(StringArray *array, const char* match);
int   StringArrayCmp(const void* a, const void* b);


/*********************************************************************
 * Program entry point
 */
int main(int argc, char* argv[])
{
  if (argc < 2)
  {
    fprintf(stderr, "Usage: c2html <filename> [<keyword file>]\n");
    return EXIT_FAILURE;
  }

  /*
   * NOTE: If a keyword file is not specified on the command line then c2html
   * currently checks in the current directory for the default file. A nice
   * change would be to get it to look on the path instead.
   */
  ConvertCodeToHtml(argv[1], (argc > 2 ? argv[2] : "c2html.tok"), stdout);

  return EXIT_SUCCESS;
}


/*********************************************************************
 * Machine States
 */

typedef enum State
{
  NORMAL,
  NORMAL_LINE_START,
  HALF_COMMENT,
  C_COMMENT,
  END_C_COMMENT,
  CPP_COMMENT,
  DIRECTIVE_HALF_COMMENT,
  DIRECTIVE_C_COMMENT,
  DIRECTIVE_END_C_COMMENT,
  SINGLE_STRING,
  SINGLE_STRING_ESC,
  DOUBLE_STRING,
  DOUBLE_STRING_ESC,
  DIRECTIVE,
  DIRECTIVE_LINE_WRAP,
  NUMBER_BEFORE_DOT,
  NUMBER_AFTER_DOT,
  IDENTIFIER
} State;


/*********************************************************************
 * ConvertCodeToHtml
 *
 * A State Machine that turns C or C++ code into HTML
 */
void ConvertCodeToHtml(const char* filename, const char* kwfile, FILE* output)
{
  int c;                    /* the character just read */
  State state;              /* the current state of the machine */
  int write;                /* should we write the character just read */
  char ident[MAXIDENT + 1]; /* the current identifier being read */
  int nident;               /* the position in the current identifier */
  StringArray keywords;     /* the array of keywords */
  int nkeywords;            /* the number of keywords */

  /* open the input FILE */
  FILE* fp = fopen(filename, "rt");
  if (fp == NULL) return;

  /* read in the keywords */
  StringArrayRead(&keywords, kwfile);

  BeginCode(output);

  /* state-machine to output the code */
  state = NORMAL_LINE_START;
  while ((c = fgetc(fp)) != EOF)
  {
    write = 1;
    switch(state)
    {
      case NORMAL_LINE_START:
        if (c == '#')
        {
          BeginDirective(output);
          state = DIRECTIVE;
        }
        else if (!isspace(c)) state = NORMAL;
      case NORMAL:
        if      (c == '\n') state = NORMAL_LINE_START;
        else if (c == '/')  state = HALF_COMMENT, write = 0;
        else if (isdigit(c))
        {
          BeginConstant(output);
          state = NUMBER_BEFORE_DOT;
        }
        else if (isalpha(c) || c == '_')
        {
          nident = 0;
          ident[nident++] = c;
          ident[nident] = '\0';
          state = IDENTIFIER;
          write = 0;
        }
        else if (c == '\'')
        {
          BeginConstant(output);
          state = SINGLE_STRING;
        }
        else if (c == '\"')
        {
          BeginConstant(output);
          state = DOUBLE_STRING;
        }
        break;

      case HALF_COMMENT:
        if (c == '/')
        {
          BeginComment(output);
          state = CPP_COMMENT;
        }
        else if (c == '*')
        {
          BeginComment(output);
          state = C_COMMENT;
        }
        else state = NORMAL;
        WriteHtmlChar('/', output);
        break;

      case C_COMMENT:
        if (c == '*') state = END_C_COMMENT;
        break;

      case END_C_COMMENT:
        if (c == '/')
        {
          WriteHtmlChar(c, output);
          EndComment(output);
          state = NORMAL, write = 0;
        }
        else if (c != '*') state = C_COMMENT;
        break;

      case CPP_COMMENT:
        if (c == '\n')
        {
          EndComment(output);
          state = NORMAL_LINE_START;
        }
        break;

      case DIRECTIVE_HALF_COMMENT:
        if (c == '/')
        {
          EndDirective(output);
          BeginComment(output);
          state = CPP_COMMENT;
        }
        else if (c == '*')
        {
          EndDirective(output);
          BeginComment(output);
          state = DIRECTIVE_C_COMMENT;
        }
        else state = DIRECTIVE;
        WriteHtmlChar('/', output);
        break;

      case DIRECTIVE_C_COMMENT:
        if (c == '*') state = DIRECTIVE_END_C_COMMENT;
        break;

      case DIRECTIVE_END_C_COMMENT:
        if (c == '/')
        {
          WriteHtmlChar(c, output);
          EndComment(output);
          BeginDirective(output);
          state = DIRECTIVE, write = 0;
        }
        else if (c != '*') state = DIRECTIVE_C_COMMENT;
        break;

      case SINGLE_STRING:
        if (c == '\'')
        {
          WriteHtmlChar(c, output);
          EndConstant(output);
          state = NORMAL;
          write = 0;
        }
        else if (c == '\\') state = SINGLE_STRING_ESC;
        break;

      case SINGLE_STRING_ESC:
        state = SINGLE_STRING;
        break;

      case DOUBLE_STRING:
        if (c == '\"')
        {
          WriteHtmlChar(c, output);
          EndConstant(output);
          state = NORMAL;
          write = 0;
        }
        else if (c == '\\') state = DOUBLE_STRING_ESC;
        break;

      case DOUBLE_STRING_ESC:
        state = DOUBLE_STRING;
        break;

      case DIRECTIVE:
        if (c == '\n')
        {
          EndDirective(output);
          state = NORMAL_LINE_START;
        }
        else if (c == '/')
        {
          state = DIRECTIVE_HALF_COMMENT;
          write = 0;
        }
        else if (c == '\\') state = DIRECTIVE_LINE_WRAP;
        break;

      case DIRECTIVE_LINE_WRAP:
        if (c == '\n' || !isspace(c)) state = DIRECTIVE;
        break;

      case NUMBER_BEFORE_DOT:
        if (c == '.') state = NUMBER_AFTER_DOT;
        else if (!isdigit(c) && c != 'x')
        {
          EndConstant(output);
          state = (c == '\n' ? NORMAL_LINE_START : NORMAL);
        }
        break;

      case NUMBER_AFTER_DOT:
        if (!isdigit(c))
        {
          EndConstant(output);
          state = (c == '\n' ? NORMAL_LINE_START : NORMAL);
        }
        break;

      case IDENTIFIER:
        if ((isalnum(c) || c == '_') && nident < MAXIDENT)
        {
          ident[nident++] = c;
          ident[nident] = '\0';
          write = 0;
        }
        else
        {
          if (StringArrayFind(&keywords, ident))
          {
            BeginKeyword(output);
            WriteHtmlString(ident, output);
            EndKeyword(output);
          }
          else WriteHtmlString(ident, output);
          state = (c == '\n' ? NORMAL_LINE_START : NORMAL);
        }
        break;

      default:
        fprintf(stderr, "We shouldn't be here!\n");
    }
    if (write) WriteHtmlChar(c, output);
  }

  EndCode(output);

  fclose(fp);
}


/*********************************************************************
 * WriteHtmlChar
 *
 * Writes a single character, escaping it if necessary
 */
void WriteHtmlChar(char c, FILE* stream)
{
  switch (c)
  {
    case '<':
    case '>':
    case '&':
    case '|':
      fprintf(stream, "&#%d;", c);
      break;

#ifndef COMPACT
    case ' ':
      fprintf(stream, "&nbsp;");
      break;
#endif

    case '\t':
#ifdef COMPACT
      fprintf(stream, "  ");
#else
      fprintf(stream, "&nbsp;&nbsp;");
#endif
      break;

#ifndef COMPACT
    case '\n':
      fprintf(stream, "<br>\n");
      break;
#endif

    default:
      fputc(c, stream);
  }
}


/*********************************************************************
 * WriteHtmlString
 *
 * Writes a string, escaping characters as necessary
 */
void WriteHtmlString(const char* str, FILE* stream)
{
  const char* p = str;
  while (*p)
    WriteHtmlChar(*p++, stream);
}



/*********************************************************************
 * Functions dealing with syntax highlighting
 */

void BeginCode(FILE* stream)
{
#ifdef COMPACT
  fprintf(stream, "<pre>");
#else
  fprintf(stream, "<code>\n");
#endif
}

void EndCode(FILE* stream)
{
#ifdef COMPACT
  fprintf(stream, "</pre>\n");
#else
  fprintf(stream, "</code>\n");
#endif
}

void BeginComment(FILE* stream)
{
  fprintf(stream, "<font color=#00007f><i>");
}

void EndComment(FILE* stream)
{
  fprintf(stream, "</i></font>");
}

void BeginDirective(FILE* stream)
{
  fprintf(stream, "<font color=#007f00>");
}

void EndDirective(FILE* stream)
{
  fprintf(stream, "</font>");
}

void BeginConstant(FILE* stream)
{
  fprintf(stream, "<font color=#0000bb>");
}

void EndConstant(FILE* stream)
{
  fprintf(stream, "</font>");
}

void BeginKeyword(FILE* stream)
{
  fprintf(stream, "<b>");
}

void EndKeyword(FILE* stream)
{
  fprintf(stream, "</b>");
}



/*********************************************************************
 * StringArrayRead
 * 
 * Reads a file of strings (one string per line) into the
 * StringArray structure. The array is then sorted.
 */
void StringArrayRead(StringArray* array, const char* filename)
{
  int blocksize = 8;     /* number of extra strings to add when resizing */
  int space = blocksize; /* the number of strings that can now fit */
  char line[MAXLINE];    /* current line read from the FILE */
  FILE* fp;              /* pointer to the token FILE */
  int n;                 /* index in current line */

  /* initialise the array to contain no elements */
  array->num = 0;
  array->strings = (char**) malloc(space * sizeof(char*));

  /* open the file of strings */
  fp  = fopen(filename, "rt");
  if (fp == NULL) return;

  /* read the file of strings into the array */
  while (!feof(fp))
  {
    /* read in a line and remove '\n' from the end */
    *line = '\0';
    fgets(line, MAXLINE, fp);
    n = strlen(line) - 1;
    if (line[n] == '\n') line[n] = '\0';
    if (!*line) continue;

    /* resize the array so that it contains enough space */
    if (array->num >= space)
    {
      space += blocksize;
      array->strings = realloc(array->strings, space * sizeof(char*));
    }

    /* add the string to the array */
    array->strings[array->num++] = strdup(line);
  }
  fclose(fp);

  /* sort the array of strings */
  qsort(array->strings, array->num, sizeof(char*), StringArrayCmp);
}


/*********************************************************************
 * StringArrayCmp
 *
 * Comparison function for StringArray sorting and searching.
 */
int StringArrayCmp(const void* a, const void* b)
{
  return strcmp((*(const char**)a), (*(const char**)b));
}


/*********************************************************************
 * StringArrayFind
 *
 * Finds a given string in the array, returns NULL if not found.
 */
char* StringArrayFind(StringArray* array, const char* match)
{
  char** retval = bsearch(&match, array->strings, array->num,
                          sizeof(char*), StringArrayCmp);
  if (retval) return *retval;
  return NULL;
}
