//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
USERES("C2HTML.res");
USEFORM("Frame.cpp", FormMain);
USEUNIT("Convert.cpp");
USEFORM("About.cpp", FormAbout);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
  try
  {
     Application->Initialize();
     Application->Title = "C2HTML";
     Application->CreateForm(__classid(TFormMain), &FormMain);
     Application->CreateForm(__classid(TFormAbout), &FormAbout);
     Application->Run();
  }
  catch (Exception &exception)
  {
     Application->ShowException(&exception);
  }
  return 0;
}
//---------------------------------------------------------------------------
