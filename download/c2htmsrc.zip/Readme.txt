c2html - C/C++ source to HTML converter
=======================================

This is a GUI written for Christopher Kohlhoff's program C2HTML,
which was published in Borland Code Central with article ID 578.

The source code for both this program, and the original can be 
downloaded from www.jogy.net.


Interface
---------
From the Main page you can enter whether the input and output
are from/to file or from/to clipboard.

From the Options page you can set the follwing options:
- Full HTML page
  The generated HTML code will contain <HTML>, <TITLE> and <BODY> tags,
  so it can be viewed as standalone HTML page

- Lowercase tags
  All HTML tags will be in lowercase

- Compact code
  The HTML code will be more compact and will use <PRE> tag instead of <CODE>

- Tab spaces
  Enter with how many spaces the Tab character will be replaced

- Text and Background color (for Full HTML page only)
  Select the background and default text color for the generated page

- Syntax highlighting
  Select how the different syntactic elements will be highlighted in the
  generated page - any combination of Bold, Italic, Underline and Text color

- Keyword file
  Select an external file, which contains keywords one per line, 
  which will be highlighted with the Keyword setting
  The original keyword file c2html.tok, created by Christopher Kohlhoff 
  is included with the program.


Version History
---------------
- v1.0     Initial release

- v1.01    Added in the the Color comboboxes support for selecting colors other than the standard ones.
           Added replacing of quotes with &quot; and of ampersands with &amp;
           


Copyright
---------
Copyright (C) 1996 Christopher Kohlhoff (chris@kohlhoff.com)
Copyright (C) 2001 Jogy (jogy@sirma.bg)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
