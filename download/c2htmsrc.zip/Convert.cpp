#include <memory>

#pragma hdrstop

#include "convert.h"

const int MAXIDENT = 512;
const int MAXLINE = 512;

////////////////////////////////////////////////////////////////////////////////

bool StringArray::Read(std::istream &is)
{
	erase(begin(), end());

	char *buf = new char[MAXLINE + 1];

  while (is)
  {
    is.getline(buf, MAXLINE);

    if (buf[0] != '\0')
      insert(end(), std::string(buf));
  }

  delete [] buf;

  return true;;
}

bool StringArray::Contains(const std::string &str)
{
	for (StringArrayIter iter(begin()); iter != end(); iter++)
  	if (*iter == str)
    	return true;

  return false;
}

////////////////////////////////////////////////////////////////////////////////

C2HTML::Options::Options()
: lowercase(true), compact(false), fullpage(true),
  tabspaces(2), bkcolor("White"), txtcolor("Black"),
  comment("Purple"), directive("Green"), constant("Blue"), keyword("", true)
{
}


C2HTML::Options::Formatting::Formatting(const std::string &_color, bool _bold,
                                        bool _italic, bool _underline)
: color(_color), bold(_bold), italic(_italic), underline(_underline)
{
}

////////////////////////////////////////////////////////////////////////////////

C2HTML::C2HTML(std::istream &_is, std::ostream &_os,
               StringArray &_keywords, Options &_options,
               const std::string &_title)
: is(_is), os(_os), keywords(_keywords), options(_options), title(_title),
  state(NORMAL_LINE_START)
{
	ident = new char[MAXIDENT + 1];
}

C2HTML::~C2HTML()
{
  delete [] ident;
}


bool C2HTML::Convert()
{
	if (!is || !os)
  	return false;

	BeginCode();

  while (is)
  {
    c = is.get();
    if (c == -1)
    	break;

    if (c == '\r')
      continue;

    write = true;

		switch (state)
    {
      case NORMAL_LINE_START:
        if (c == '#')
        {
          BeginDirective();
          state = DIRECTIVE;
        }
        else if (!isspace(c))
        	state = NORMAL;

      case NORMAL:
        if (c == '\n')
        	state = NORMAL_LINE_START;
        else if (c == '/')
          	state = HALF_COMMENT, write = 0;
        else if (isdigit(c))
        {
          BeginConstant();
          state = NUMBER_BEFORE_DOT;
        }
        else if (isalpha(c) || c == '_')
        {
          nident = 0;
          ident[nident++] = (char)c;
          ident[nident] = '\0';
          state = IDENTIFIER;
          write = false;
        }
        else if (c == '\'')
        {
          BeginConstant();
          state = SINGLE_STRING;
        }
        else if (c == '\"')
        {
          BeginConstant();
          state = DOUBLE_STRING;
        }
        break;

      case HALF_COMMENT:
        if (c == '/')
        {
          BeginComment();
          state = CPP_COMMENT;
        }
        else if (c == '*')
        {
          BeginComment();
          state = C_COMMENT;
        }
        else
        	state = NORMAL;
        WriteChar('/');
        break;

      case C_COMMENT:
        if (c == '*')
        	state = END_C_COMMENT;
        break;

      case END_C_COMMENT:
        if (c == '/')
        {
          WriteChar((char)c);
          EndComment();
          state = NORMAL, write = 0;
        }
        else if (c != '*')
        	state = C_COMMENT;
        break;

      case CPP_COMMENT:
        if (c == '\n')
        {
          EndComment();
          state = NORMAL_LINE_START;
        }
        break;

      case DIRECTIVE_HALF_COMMENT:
        if (c == '/')
        {
          EndDirective();
          BeginComment();
          state = CPP_COMMENT;
        }
        else if (c == '*')
        {
          EndDirective();
          BeginComment();
          state = DIRECTIVE_C_COMMENT;
        }
        else
        	state = DIRECTIVE;
        WriteChar('/');
        break;

      case DIRECTIVE_C_COMMENT:
        if (c == '*')
        	state = DIRECTIVE_END_C_COMMENT;
        break;

      case DIRECTIVE_END_C_COMMENT:
        if (c == '/')
        {
          WriteChar((char)c);
          EndComment();
          BeginDirective();
          state = DIRECTIVE;
          write = 0;
        }
        else if (c != '*')
        	state = DIRECTIVE_C_COMMENT;
        break;

      case SINGLE_STRING:
        if (c == '\'')
        {
          WriteChar((char)c);
          EndConstant();
          state = NORMAL;
          write = false;
        }
        else if (c == '\\')
        	state = SINGLE_STRING_ESC;
        break;

      case SINGLE_STRING_ESC:
        state = SINGLE_STRING;
        break;

      case DOUBLE_STRING:
        if (c == '\"')
        {
          WriteChar((char)c);
          EndConstant();
          state = NORMAL;
          write = false;
        }
        else if (c == '\\')
        	state = DOUBLE_STRING_ESC;
        break;

      case DOUBLE_STRING_ESC:
        state = DOUBLE_STRING;
        break;

      case DIRECTIVE:
        if (c == '\n')
        {
          EndDirective();
          state = NORMAL_LINE_START;
        }
        else if (c == '/')
        {
          state = DIRECTIVE_HALF_COMMENT;
          write = 0;
        }
        else if (c == '\\')
        	state = DIRECTIVE_LINE_WRAP;
        break;

      case DIRECTIVE_LINE_WRAP:
        if (c == '\n' || !isspace(c))
        	state = DIRECTIVE;
        break;

      case NUMBER_BEFORE_DOT:
        if (c == '.')
        	state = NUMBER_AFTER_DOT;
        else if (!isdigit(c) && c != 'x')
        {
          EndConstant();
          state = (c == '\n' ? NORMAL_LINE_START : NORMAL);
        }
        break;

      case NUMBER_AFTER_DOT:
        if (!isdigit(c))
        {
          EndConstant();
          state = (c == '\n' ? NORMAL_LINE_START : NORMAL);
        }
        break;

      case IDENTIFIER:
        if ((isalnum(c) || c == '_') && nident < MAXIDENT)
        {
          ident[nident++] = (char)c;
          ident[nident] = '\0';
          write = 0;
        }
        else
        {
          if (keywords.Contains(ident))
          {
            BeginKeyword();
            WriteString(ident);
            EndKeyword();
          }
          else WriteString(ident);
          state = (c == '\n' ? NORMAL_LINE_START : NORMAL);
        }
        break;
    }

    if (write)
    	WriteChar((char)c);

  }

  EndCode();

  return true;
}

void C2HTML::WriteTag(const std::string &tag)
{
	char *temp = new char[tag.length() + 1];
  strcpy(temp, tag.c_str());

	if (options.lowercase)
  	strlwr(temp);
  else
  	strupr(temp);

	os << temp;

  delete [] temp;
}


void C2HTML::BeginCode()
{
  if (options.fullpage)
  {
    WriteTag("<html>\n");
    WriteTag("<title>");
    os << title;
    WriteTag("</title>\n");
    WriteTag("<body");

    if (options.txtcolor.length() > 0)
      WriteTag(" text=" + options.txtcolor);
    if (options.bkcolor.length() > 0)
      WriteTag(" bgcolor=" + options.bkcolor);

    WriteTag(">\n");
  }

	if (options.compact)
  	WriteTag("<pre>\n");

  WriteTag("<code>\n");
}

void C2HTML::EndCode()
{
  WriteTag("</code>\n");

	if (options.compact)
  	WriteTag("</pre>\n");

  if (options.fullpage)
  {
    WriteTag("</body>\n");
    WriteTag("</html>\n");
  }
}

void C2HTML::BeginFormatting(const Options::Formatting &formatting)
{
	if (formatting.color.length() > 0)
	  WriteTag("<font color=\"" + formatting.color + "\">");

  if (formatting.bold)
  	WriteTag("<b>");

  if (formatting.italic)
  	WriteTag("<i>");

  if (formatting.underline)
  	WriteTag("<u>");
}

void C2HTML::EndFormatting(const Options::Formatting &formatting)
{
  if (formatting.underline)
  	WriteTag("</u>");

  if (formatting.italic)
  	WriteTag("</i>");

  if (formatting.bold)
  	WriteTag("</b>");

	if (formatting.color.length() > 0)
	  WriteTag("</font>");
}

void C2HTML::WriteChar(char c)
{
  switch (c)
  {
    case '<':
    case '>':
    case '|':
    	os << "&#" << (int)c << ";";
      break;

    case '&':
    	os << "&amp;";
      break;

    case '\"':
    	os << "&quot;";
      break;

    case ' ':
    	if (options.compact)
        os << " ";
      else
      	os << "&nbsp;";
      break;

    case '\t':
    	{
        for (int i = 0; i < options.tabspaces; i++)
          WriteChar(' ');
      }
      break;

    case '\n':
    	if (options.compact)
        os << std::endl;
      else
        WriteTag("<br>\n");
      break;

    default:
    	os << c;
  }
}

void C2HTML::WriteString(const char* str)
{
  const char* p = str;
  while (*p)
    WriteChar(*p++);
}

