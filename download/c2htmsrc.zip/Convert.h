#ifndef C2HTML_H__  	// Sentry
#define C2HTML_H__

#include <string>
#include <vector>
#include <iostreams>

class StringArray : public std::vector<std::string>
{
	public:
  	bool Read(std::istream &is);

		bool Contains(const std::string &str);
};

typedef std::vector<std::string>::iterator StringArrayIter;

class C2HTML
{
	public:
  	struct Options
    {
    	struct Formatting
      {
				Formatting(const std::string &_color = "", bool _bold = false,
                   bool _italic = false, bool _underline = false);

        std::string color;
        bool bold;
        bool italic;
        bool underline;
      };

    	Options();

    	bool lowercase;
			bool compact;
      bool fullpage;

      int tabspaces;

      std::string txtcolor;
      std::string bkcolor;

      Formatting comment;
      Formatting directive;
      Formatting constant;
      Formatting keyword;
    };

  	C2HTML(std::istream &_is, std::ostream &_os,
           StringArray &_keywords, Options &_options,
           const std::string &_title = "");
  	~C2HTML();

		bool Convert();

  private:

  	void WriteTag(const std::string &tag);
		void WriteChar(char c);
		void WriteString(const char* str);

  	void BeginCode();
    void EndCode();

  	void BeginFormatting(const Options::Formatting &formatting);
  	void EndFormatting(const Options::Formatting &formatting);

    void BeginComment() { BeginFormatting(options.comment); }
    void EndComment() { EndFormatting(options.comment); }
    void BeginDirective() { BeginFormatting(options.directive); }
    void EndDirective() { EndFormatting(options.directive); }
    void BeginConstant() { BeginFormatting(options.constant); }
    void EndConstant() { EndFormatting(options.constant); }
    void BeginKeyword() { BeginFormatting(options.keyword); }
    void EndKeyword() { EndFormatting(options.keyword); }


  	enum State
    {
      NORMAL,
      NORMAL_LINE_START,
      HALF_COMMENT,
      C_COMMENT,
      END_C_COMMENT,
      CPP_COMMENT,
      DIRECTIVE_HALF_COMMENT,
      DIRECTIVE_C_COMMENT,
      DIRECTIVE_END_C_COMMENT,
      SINGLE_STRING,
      SINGLE_STRING_ESC,
      DOUBLE_STRING,
      DOUBLE_STRING_ESC,
      DIRECTIVE,
      DIRECTIVE_LINE_WRAP,
      NUMBER_BEFORE_DOT,
      NUMBER_AFTER_DOT,
      IDENTIFIER
    } state;                  // the current state of the machine

		std::istream &is;					// input stream
    std::ostream &os;         // output stream

    StringArray &keywords;    // the array of keywords

    Options &options;					// conversion options

    const std::string &title; // title of the page

    int c;                    // the character just read
    bool write;               // should we write the character just read
    char *ident;              // the current identifier being read
    int nident;               // the position in the current identifier
};

#endif  	// Sentry

