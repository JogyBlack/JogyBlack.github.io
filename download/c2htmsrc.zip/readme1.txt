c2html - C/C++ source to HTML converter
=======================================

Building c2html
---------------
Either
  bcc32 c2html.c
or
  bcc32 -DCOMPACT c2html.c
to build a version which generates more compact HTML code.

Running c2html
--------------
The output of c2html is written to stdout. Therefore you would
typically use c2html like this:
  c2html mysource.cpp > output.html
There is an optional second argument which specifies the file
to use for the keywords, for example
  c2html mysource.cpp c:\keywords.tok > output.html

Customising the colours
-----------------------
To customise the colours and HTML tags used for syntax
highlighting, modify the functions named BeginXXXX/EndXXXXX.

Feedback
--------
Please report any problems, make feature requests or submit
code changes to chris@kohlhoff.com.

Copyright
---------
Copyright (C) 1996 Christopher Kohlhoff (chris@kohlhoff.com)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.