//---------------------------------------------------------------------------

#ifndef FrameH
#define FrameH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
#include <Dialogs.hpp>


#include "Convert.h"
#include "CGRID.h"
//---------------------------------------------------------------------------
class TFormMain : public TForm
{
__published:	// IDE-managed Components
  TPageControl *Pages;
  TTabSheet *TabSheetMain;
  TBitBtn *BitBtnQuit;
  TGroupBox *GroupBoxInput;
  TRadioButton *RadioButtonInputFile;
  TComboBox *ComboBoxInputFile;
  TButton *ButtonInputBrowse;
  TRadioButton *RadioButtonInputClipboard;
  TGroupBox *GroupBoxOutput;
  TRadioButton *RadioButtonOutputFile;
  TComboBox *ComboBoxOutputFile;
  TButton *ButtonOutputBrowse;
  TRadioButton *RadioButtonOutputClipboard;
  TBitBtn *BitBtnConvert;
  TOpenDialog *OpenDialogInput;
  TSaveDialog *SaveDialogOutput;
  TTabSheet *TabSheetOptions;
  TCheckBox *CheckBoxLowercase;
  TCheckBox *CheckBoxCompact;
  TLabel *LabelTabSpaces;
  TEdit *EditTabSpaces;
  TUpDown *UpDownTabSpaces;
  TCheckBox *CheckBoxFullPage;
  TCheckBox *CheckBoxPreview;
  TGroupBox *GroupBoxSyntax;
  TListBox *ListBoxElements;
  TColorDialog *ColorDialogSyntax;
  TCheckBox *CheckBoxBold;
  TCheckBox *CheckBoxItalic;
  TCheckBox *CheckBoxUnderline;
  TLabel *LabelColor;
  TComboBox *ComboBoxColor;
  TComboBox *ComboBoxTextColor;
  TLabel *LabelTextColor;
  TComboBox *ComboBoxBkColor;
  TLabel *LabelBkColor;
  TBitBtn *BitBtnAbout;
  TComboBox *ComboBoxKeywords;
  TButton *ButtonBrowseKeywords;
  TLabel *LabelKeyword;
  TOpenDialog *OpenDialogKeywords;
  void __fastcall BitBtnQuitClick(TObject *Sender);
  void __fastcall RadioButtonInputFileClick(TObject *Sender);
  void __fastcall RadioButtonInputClipboardClick(TObject *Sender);
  void __fastcall RadioButtonOutputFileClick(TObject *Sender);
  void __fastcall RadioButtonOutputClipboardClick(TObject *Sender);
  void __fastcall ButtonInputBrowseClick(TObject *Sender);
  void __fastcall ButtonOutputBrowseClick(TObject *Sender);
  void __fastcall FormCreate(TObject *Sender);
  void __fastcall BitBtnConvertClick(TObject *Sender);
  void __fastcall CheckBoxFullPageClick(TObject *Sender);
  void __fastcall ListBoxElementsClick(TObject *Sender);
  void __fastcall CheckBoxBoldClick(TObject *Sender);
  void __fastcall CheckBoxItalicClick(TObject *Sender);
  void __fastcall CheckBoxUnderlineClick(TObject *Sender);
  void __fastcall ComboBoxTextColorChange(TObject *Sender);
  void __fastcall FormDestroy(TObject *Sender);
  void __fastcall ComboBoxColorChange(TObject *Sender);
  void __fastcall ComboBoxBkColorChange(TObject *Sender);
  void __fastcall BitBtnAboutClick(TObject *Sender);
  void __fastcall ButtonBrowseKeywordsClick(TObject *Sender);
  void __fastcall CheckBoxLowercaseClick(TObject *Sender);
  void __fastcall CheckBoxCompactClick(TObject *Sender);
  void __fastcall EditTabSpacesChange(TObject *Sender);

private:	// User declarations
	C2HTML::Options options;

  C2HTML::Options::Formatting *GetSelectedFormatting();

  void AddColors(TComboBox *combo);
  void SetColor(TComboBox *combo, const AnsiString &color);
  AnsiString GetColor(TComboBox *combo);
  void ReadFileNames(TRegistryIniFile *iniFile, TComboBox *combo, const AnsiString &name);
  void WriteFileNames(TRegistryIniFile *iniFile, TComboBox *combo, const AnsiString &name);
  void ReadOptions(TRegistryIniFile *iniFile);
  void WriteOptions(TRegistryIniFile *iniFile);
  void ReadFormatting(TRegistryIniFile *iniFile, const AnsiString &name, C2HTML::Options::Formatting *formatting);
  void WriteFormatting(TRegistryIniFile *iniFile, const AnsiString &name, C2HTML::Options::Formatting *formatting);
  void AddComboBoxString(TComboBox *combo);

public:		// User declarations
  __fastcall TFormMain(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFormMain *FormMain;
//---------------------------------------------------------------------------
#endif
