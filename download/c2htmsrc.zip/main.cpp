#include <fstream>

#pragma hdrstop

#include "c2html.h"

int main(int argc, char *argv[])
{
	if (argc < 3)
  {
    cerr << "Usage : c2html infile outfile [tokfile]" << endl;
    return 0;
  }

	ifstream ifs(argv[1]);
  if (!ifs)
  {
    cerr << "Cannot open " << argv[1] << endl;
    return 1;
  }

 	ofstream ofs(argv[2]);
  if (!ofs)
  {
    cerr << "Cannot open " << argv[2] << endl;
    return 1;
  }

  const char *tokname = argc > 3 ? argv[3] : "c2html.tok";
  ifstream tok(tokname);
  if (!tok)
  {
    cerr << "Cannot open " << tokname << endl;
    return 1;
  }

  StringArray keywords;
  keywords.Read(tok);

	C2HTML::Options options;

  C2HTML(ifs, ofs, keywords, options).Convert();		  

  return 0;
}
