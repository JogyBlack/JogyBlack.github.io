/*------------------------------------------------------------------------------
Header: rebuild.h
Description:
Note:
Author: Jogy
Date created: 21 March 2000
Date last modified: 21 March 2000
------------------------------------------------------------------------------*/

#ifndef __rebuild_h__  	// Sentry
#define __rebuild_h__

#include "toolbase.h"

class ProjectRebuildTool : public ToolBase
{
  public:
    ProjectRebuildTool();

    virtual ToolTypes GetTypes() const { return TT_Viewer; }
    virtual const char *GetName() const;    virtual unsigned GetFlags() const { return TIFlag_OnToolsMenu; }    virtual const char *GetMenuName() const;    virtual const char *GetHelpHint() const;    virtual const char *GetRegKeyName() const;

    virtual ToolReturn Execute(IPolyString *cmdLine,
                               ProjectNode *nodeArray,
                               int numNodes);
};

////////////////////////////////////////////////////////////////////////////////

class ProjectRestoreTool : public ToolBase
{
  public:
    ProjectRestoreTool();

    virtual ToolTypes GetTypes() const { return TT_Viewer; }
    virtual const char *GetName() const;    virtual unsigned GetFlags() const { return TIFlag_OnToolsMenu; }    virtual const char *GetMenuName() const;    virtual const char *GetHelpHint() const;    virtual const char *GetRegKeyName() const;

    virtual ToolReturn Execute(IPolyString *cmdLine,
                               ProjectNode *nodeArray,
                               int numNodes);
};

////////////////////////////////////////////////////////////////////////////////

class ExportBranchTool : public ToolBase
{
  public:
    ExportBranchTool();

    virtual ToolTypes GetTypes() const { return TT_Viewer; }
    virtual const char *GetName() const;    virtual unsigned GetFlags() const { return TIFlag_OnToolsMenu; }    virtual const char *GetMenuName() const;    virtual const char *GetHelpHint() const;    virtual const char *GetRegKeyName() const;

    virtual ToolReturn Execute(IPolyString *cmdLine,
                               ProjectNode *nodeArray,
                               int numNodes);
};

////////////////////////////////////////////////////////////////////////////////

class ImportBranchTool : public ToolBase
{
  public:
    ImportBranchTool();

    virtual ToolTypes GetTypes() const { return TT_Viewer; }
    virtual const char *GetName() const;    virtual unsigned GetFlags() const { return TIFlag_OnToolsMenu; }    virtual const char *GetMenuName() const;    virtual const char *GetHelpHint() const;    virtual const char *GetRegKeyName() const;

    virtual ToolReturn Execute(IPolyString *cmdLine,
                               ProjectNode *nodeArray,
                               int numNodes);
};

////////////////////////////////////////////////////////////////////////////////

class ExportProjectTool : public ToolBase
{
  public:
    ExportProjectTool();

    virtual ToolTypes GetTypes() const { return TT_Viewer; }
    virtual const char *GetName() const;    virtual unsigned GetFlags() const { return TIFlag_OnToolsMenu; }    virtual const char *GetMenuName() const;    virtual const char *GetHelpHint() const;    virtual const char *GetRegKeyName() const;

    virtual ToolReturn Execute(IPolyString *cmdLine,
                               ProjectNode *nodeArray,
                               int numNodes);
};

////////////////////////////////////////////////////////////////////////////////

class ImportProjectTool : public ToolBase
{
  public:
    ImportProjectTool();

    virtual ToolTypes GetTypes() const { return TT_Viewer; }
    virtual const char *GetName() const;    virtual unsigned GetFlags() const { return TIFlag_OnToolsMenu; }    virtual const char *GetMenuName() const;    virtual const char *GetHelpHint() const;    virtual const char *GetRegKeyName() const;

    virtual ToolReturn Execute(IPolyString *cmdLine,
                               ProjectNode *nodeArray,
                               int numNodes);
};

////////////////////////////////////////////////////////////////////////////////

class TargetsSettingsTool : public ToolBase
{
  public:
    TargetsSettingsTool();

    virtual ToolTypes GetTypes() const { return TT_Viewer; }
    virtual const char *GetName() const;    virtual unsigned GetFlags() const { return TIFlag_OnToolsMenu; }    virtual const char *GetMenuName() const;    virtual const char *GetHelpHint() const;    virtual const char *GetRegKeyName() const;

    virtual ToolReturn Execute(IPolyString *cmdLine,
                               ProjectNode *nodeArray,
                               int numNodes);
};

////////////////////////////////////////////////////////////////////////////////


#endif  	// Sentry

