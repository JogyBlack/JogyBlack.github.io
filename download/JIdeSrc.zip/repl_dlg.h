/*------------------------------------------------------------------------------
Header: repl_dlg.h
Description:
Note:
Author: Jogy
Date created: 21 March 2000
Date last modified: 21 March 2000
------------------------------------------------------------------------------*/

#ifndef __repl_dlg_h__  	// Sentry
#define __repl_dlg_h__

struct ReplaceData
{
	ReplaceData(char *_find, int _find_len, char *_repl, int _repl_len)
  : find(_find), find_len(_find_len), repl(_repl), repl_len(_repl_len), recurse(false) {}

	char *find;
  int find_len;
  char *repl;
  int repl_len;
  bool recurse;
};

extern int ReplaceDialog(HWND hParent, ReplaceData *_data);

#endif  	// Sentry

