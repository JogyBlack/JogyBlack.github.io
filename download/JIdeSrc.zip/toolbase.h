/*------------------------------------------------------------------------------
Header: toolbase.h
Description:
Note:
Author: Jogy
Date created: 17 May 2000
Date last modified: 17 May 2000
------------------------------------------------------------------------------*/

#ifndef __toolbase_h__  	// Sentry
#define __toolbase_h__

class ToolBase : public IUnknownImp<IToolImplementor>
{
  public:    ToolBase();    virtual ToolTypes GetTypes() const { return TT_Viewer; }    virtual const char *GetName() const = 0;    virtual const char *GetPath() const;    virtual unsigned GetFlags() const { return 0; }    virtual const char *GetMenuName() const = 0;    virtual const char *GetHelpHint() const = 0;    virtual const char *GetDefCmdLine() const { return ""; }    virtual const char *GetSupportedTypes() const { return ""; }    virtual const char *GetDefaultForTypes() const { return ""; }
    virtual const char *GetTranslateTo() const { return ""; }
    virtual int RequiredVersion() const { return 0; }
    virtual const char *GetRegKeyName() const = 0;
};

typedef ToolBase *PToolBase;

#endif  	// Sentry

