#include "all.h"
#pragma hdrstop

#include "gen_txt.h"
#include "helper.h"

class Node
{
  public:
    Node(const char *_str, Node *_next);
    ~Node() { delete [] str; }

    const char *GetStr() const { return str; }

    Node *GetNext() const { return next; }
    void SetNext(Node *_next) { next = _next; }

    Node *Insert(const char *_str, Node *prev);

  private:
    char *str;
    Node *next;
};

Node::Node(const char *_str, Node *_next)
{
  if (_str) {
    str = new char[strlen(_str) + 1];
    strcpy(str, _str);
  }
  else
    str = 0;

    next = _next;
}

Node *Node::Insert(const char *_str, Node *prev)
{
  if (!_str)
    return this;

  int result = str[0] ? strcmp(str, _str) : 1;

  if (result == 0)
    return this;

  if (result > 0) {
    if (next)
      return next->Insert(_str, this);
    else {
      Node *newNode = new Node(_str, 0);
      SetNext(newNode);
      return newNode;
    }
  }
  else {
    Node *newNode = new Node(_str, this);
    if (prev)
      prev->SetNext(newNode);
    return newNode;
  }
}

////////////////////////////////////////////////////////////////////////////////

GenTxtTool::GenTxtTool()
{
}

const char *GenTxtTool::GetName() const
{
  return "GenTxt";}

const char *GenTxtTool::GetMenuName() const{  return "Generate Text File";}const char *GenTxtTool::GetHelpHint() const{  return "Generate text file with all source nodes from current project";}const char *GenTxtTool::GetRegKeyName() const{	return "Enable Generate Text File";
}ToolReturn GenTxtTool::Execute(IPolyString * cmdLine,                               ProjectNode * /*nodeArray*/,
                               int /*numNodes*/)
{
  if (cmdLine)
    cmdLine->Release();

  try {
    SetWaitCursor(true);

    // Set up servers
    ProjectServer projectServer;
    ScriptServer scriptServer;
    OptionSetServer optionSetServer;

    ProjectNode topNode = projectServer->QueryTopNode();
    ProjectNodeInfo info(projectServer->QueryNodeInfo(topNode));
    if (!info)
      throw "Cannot get top node info";

    PolyString result(CreatePolyString());
    scriptServer->RunScriptCommand(MakePolyString("return IDE.CurrentDirectory;"), result.Get());

    PolyString name(info->GetName());

    char outputFileName[_MAX_PATH];
    wsprintf(outputFileName, "%s\\%s.%s", result->GetCstr(), name->GetCstr(), "lst");

    ofstream ofs(outputFileName);
    if (!ofs)
      throw "Cannot create output file";

    Node *first = new Node("", 0);
/*
    ofs << "# Microsoft Developer Studio Project File - Name=\""
        << name->GetCstr() << "\" - Package Owner=<4>" << endl;

    ofs << "# Microsoft Developer Studio Generated Build File, Format Version 6.00" << endl;
    ofs << "# ** DO NOT EDIT **" << endl;

    ofs << "# TARGTYPE \"Win32 (x86) Application\" 0x0101" << endl;

    ofs << "# Begin Project" << endl;

    ofs << "# Begin Target" << endl;

    ofs << "# Begin Group \"Source Files\"" << endl;
    ofs << "# PROP Default_Filter \"cpp;c\"" << endl;
*/
    WriteChildren(topNode, projectServer, optionSetServer, first, ofs);
/*
    ofs << "# End Group \"Source Files\"" << endl;

    ofs << "# Begin Group \"Include Files\"" << endl;
    ofs << "# PROP Default_Filter \"hpp;h\"" << endl;
*/
    while (first) {
      Node *temp = first;

      first = first->GetNext();

      if (first && first->GetStr() && *first->GetStr()) {
//        ofs << "# Begin Source File" << endl;
//        ofs << "SOURCE=.\\" << first->GetStr() << endl;
        ofs << first->GetStr() << endl;
//        ofs << "# End Source File" << endl;
      }

      delete temp;
    }
/*
    ofs << "# End Group \"Include Files\"" << endl;

    ofs << "# End Target" << endl;

    ofs << "# End Project" << endl;
*/
    SetWaitCursor(false);

    return TR_Success;
  }
  catch (const char *msg) {
    SetWaitCursor(false);

    ShowMessageBox(msg, ErrorMBox);

    return TR_FatalError;
  }
}


void GenTxtTool::WriteChildren(ProjectNode node, ProjectServer &projectServer,
                               OptionSetServer &optionSetServer,
                               Node *first, ofstream &ofs)
{
  ProjectNodeInfo info(projectServer->QueryNodeInfo(node));

  if (info) {
    PolyString name(info->GetName());
    PolyString type(info->GetNodeType());

    if (!projectServer->NodeHasFlags(node, PNF_Exclude)) {

      if (name && type) {
        if (strcmp(type->GetCstr(), ".cpp") == 0 || strcmp(type->GetCstr(), ".c") == 0) {
//          ofs << "# Begin Source File" << endl;
//          ofs << "SOURCE=.\\" << name->GetCstr() << endl;
          ofs << name->GetCstr() << endl;
//          ofs << "# End Source File" << endl;

          PolyString src(optionSetServer->OptionGet(node, OID_Source));
          PolyString inc(optionSetServer->OptionGet(node, OID_Include));

          GetIncludes(name->GetCstr(), src ? src->GetCstr() : "",
                      inc ? inc->GetCstr() : "", first);
        }
      }

      ProjectNode child = info->GetFirstChild();
      if (child)
        WriteChildren(child, projectServer, optionSetServer, first, ofs);
    }

    ProjectNode next = info->GetNextSibling();
    if (next)
      WriteChildren(next, projectServer, optionSetServer, first, ofs);
  }
}

void GenTxtTool::GetIncludes(const char *fileName, const char *src,
                             const char *inc, Node *first)
{
  char *buf = new char[_MAX_PATH + 1];

  ifstream ifs(fileName);

  if (!ifs) {
    strcpy(buf, src);
    strcat(buf, fileName);
    ifs.open(buf);
  }

  if (!ifs) {
    delete [] buf;
    return;
  }

  while (ifs) {
    ifs.getline(buf, _MAX_PATH);

    if (buf[0] == '#' && buf[1] == 'i' && buf[2] == 'n') {
      char *p = strchr(buf, '\"');
      if (p) {
        p++;
        char *p2 = strchr(p, '\"');
        if (p2)
          *p2 = '\0';

        char *buf2 = new char[_MAX_PATH + 1];

        strcpy(buf2, p);
        ifstream ifs2(buf2);
        if (!ifs2) {
          strcpy(buf2, inc);
          strcat(buf2, p);
        }

        first->Insert(buf2, 0);

        delete [] buf2;
      }
    }
  }

  delete [] buf;
}

