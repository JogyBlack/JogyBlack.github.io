/*------------------------------------------------------------------------------
Header: helper.h
Description: 
Note: 
Author: Jogy
Date created: 22 March 2000
Date last modified: 22 March 2000
------------------------------------------------------------------------------*/

#ifndef __helper_h__  	// Sentry
#define __helper_h__

/*
  Define classes which encapsulate AddOn interfaces.


  INTERFACE_CLASS()
    Create interface class with GET_INTERFACE(). Throw exception if failed.

  INTERFACE_CLASS2()
    Create interface class from a function. Throw exception if failed.

  INTERFACE_CLASS3()
    Create interface class from a function.
    Does not throw exception if failed.

*/

#define INTERFACE_CLASS(Name,Interface) \
class Name { public: \
    Name() { \      if (((i = GET_INTERFACE(Interface)) == 0)) \        throw #Interface; \    } \    ~Name() { i->Release(); } \    Interface *operator->() { return i; } \    Interface *Get() { return i; } \  private: Interface *i; }
#define INTERFACE_CLASS2(Name,Interface) \
class Name { public: \
  Name(Interface *func) { \    if (((i = func) == 0)) \      throw #Interface; \    } \    ~Name() { i->Release(); } \    Interface *operator->() { return Get(); } \    Interface *Get() { \      if (!i) \        throw #Interface; \      return i; } \  private: Interface *i; }#define INTERFACE_CLASS3(Name,Interface) \
class Name { \
  public: \
    Name(Interface *func) { i = func; } \    ~Name() { if (i) i->Release(); } \    Interface *operator->() { return i; } \    Interface *Get() { return i; } \    operator bool() const { return i != 0; } \  private: Interface *i; }
INTERFACE_CLASS(IdeWindow, IIdeWindow);
INTERFACE_CLASS(IdeUI, IIdeUI);
INTERFACE_CLASS(MessageSystem, IMessageSystem);
INTERFACE_CLASS(ProjectServer, IProjectServer2);
INTERFACE_CLASS(ProjectServer3, IProjectServer3);
INTERFACE_CLASS(ScriptServer, IScriptServer);
INTERFACE_CLASS(TargetServer, ITargetServer);
INTERFACE_CLASS(OptionSetServer, IOptionSetServer);
INTERFACE_CLASS(MakeServer, IMakeServer);

INTERFACE_CLASS2(MessageFolder, IMessageFolder);

INTERFACE_CLASS3(ProjectNodeInfo, IProjectNodeInfo);
INTERFACE_CLASS3(PolyString, IPolyString);

////////////////////////////////////////////////////////////////////////////////

extern int GetIDEVersion();

enum MessageBoxType { ErrorMBox, GetYesNoMBox, DoOkCancelMBox, InfoMBox };
extern int ShowMessageBox(const char *msg, MessageBoxType type = InfoMBox);
extern bool SetWaitCursor(bool set);

////////////////////////////////////////////////////////////////////////////////

extern BOOL BackupOriginalFile(const char *name, const char *ext);
extern BOOL RestoreOriginalFile(const char *name, const char *ext);
extern BOOL DeleteOriginalFile(const char *name, const char *ext);
extern BOOL ChangeFileTime(HANDLE hFileSrc, HANDLE hFileDst);
extern BOOL ChangeFileTime(const char *name, const char *extSrc, const char *extDst);
extern void AddFilePath(char *str, const char *filepath);

////////////////////////////////////////////////////////////////////////////////

extern bool LoadOption(const char *name, char *buf, int buflen);
extern bool LoadOption(const char *name, bool defValue);
extern int LoadOption(const char *name, int defValue);
extern void SaveOption(const char *name, const char *buf, int buflen);
extern void SaveOption(const char *name, bool value);
extern void SaveOption(const char *name, int value);

#endif  	// Sentry

