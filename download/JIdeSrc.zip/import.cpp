#include "all.h"
#pragma hdrstop

#include "helper.h"
#include "import.h"

const int MAXLINE = 1024;

char *strnewdup(const char *str)
{
	if (str) {    char *newStr = new char[strlen(str) + 1];    strcpy(newStr, str);    return newStr;  }  else    return 0;}

////////////////////////////////////////////////////////////////////////////////

struct Version
{
	int major;  int minor;  int Compare(int _major, int _minor);};
int Version::Compare(int _major, int _minor)
{
  if (major == _major)
    return minor - _minor;
  else
    return major - _major;
}

////////////////////////////////////////////////////////////////////////////////

class NodeOptions
{
  public:    NodeOptions() { include = 0; library = 0; source = 0;                    intermediate = 0; final = 0; defines = 0; cmdLine = 0; }    ~NodeOptions() { delete [] include; delete [] library;                     delete [] source; delete [] intermediate; delete [] final;                     delete [] defines; delete [] cmdLine; }    const char *GetInclude() const { return include; }    const char *GetLibrary() const { return library; }    const char *GetSource() const { return source; }    const char *GetIntermediate() const { return intermediate; }    const char *GetFinal() const { return final; }    const char *GetDefines() const { return defines; }    const char *GetCmdLine() const { return cmdLine; }    void SetInclude(const char *_include) { delete [] include; include = strnewdup(_include); }    void SetLibrary(const char *_library) { delete [] library; library = strnewdup(_library); }    void SetSource(const char *_source) { delete [] source; source = strnewdup(_source); }    void SetIntermediate(const char *_intermediate) { delete [] intermediate; intermediate = strnewdup(_intermediate); }    void SetFinal(const char *_final) { delete [] final; final = strnewdup(_final); }    void SetDefines(const char *_defines) { delete [] defines; defines = strnewdup(_defines); }    void SetCmdLine(const char *_cmdLine) { delete [] cmdLine; cmdLine = strnewdup(_cmdLine); }  private:    char *include;    char *library;    char *source;    char *intermediate;    char *final;    char *defines;    char *cmdLine;};

////////////////////////////////////////////////////////////////////////////////

class NodeInfo
{
	public:    NodeInfo() { name = 0; type = 0; level = 0; }    ~NodeInfo() { delete [] name; delete [] type; }     void Clear() { delete [] name; name = 0; delete [] type; type = 0;                   level = 0; isTarget = false; }    const char *GetName() const { return name; }    const char *GetType() const { return type; }    int GetLevel() const { return level; }    bool IsTarget() const { return isTarget; }    TargetType GetTargetType() const { return targetType; }    TargetPlatform GetTargetPlatform() const { return targetPlatform; }
    TargetModel GetTargetModel() const { return targetModel; }
    TargetStdLibs GetTargetStdLibs() const { return targetStdLibs; }
    void SetName(const char *_name) { name = strnewdup(_name); }    void SetType(const char *_type) { type = strnewdup(_type); }    void SetLevel(int _level) { level = _level; }    void SetIsTarget(bool _isTarget = true) { isTarget = _isTarget; }    void SetTargetType(TargetType _targetType) { targetType = _targetType; }    void SetTargetPlatform(TargetPlatform _targetPlatform) { targetPlatform = _targetPlatform; }    void SetTargetModel(TargetModel _targetModel) { targetModel = _targetModel; }    void SetTargetStdLibs(TargetStdLibs _targetStdLibs) { targetStdLibs = _targetStdLibs; }  private:    char *name;    char *type;    int level;    bool isTarget;    TargetType targetType;    TargetPlatform targetPlatform;
    TargetModel targetModel;
    TargetStdLibs targetStdLibs;
};
////////////////////////////////////////////////////////////////////////////////

class NodeStack
{
	public:    NodeStack() { current = 0; }    ~NodeStack() {}    void Push(ProjectNode node) { nodes[current++] = node; }    void Pop() { current--; }    ProjectNode Peek() const { return current > 0 ? nodes[current - 1] : 0; }    int GetLevel() const { return current; }  private:    ProjectNode nodes[100];    int current;};


////////////////////////////////////////////////////////////////////////////////

ProjectImporter::ProjectImporter(istream &_is,
                                 MessageFolder &_messageFolder,                                 ProjectServer &_projectServer,                                 TargetServer &_targetServer,                                 OptionSetServer &_optionSetServer): is(_is), messageFolder(_messageFolder), projectServer(_projectServer),  targetServer(_targetServer), optionSetServer(_optionSetServer){  buf = new char[MAXLINE + 1];}ProjectImporter::~ProjectImporter(){	delete [] buf;}
bool ProjectImporter::ReadLine(char *line, int len)
{
  while (is)
  {
    is.getline(line, len);    if (line[0] != '\0')    {      char *p = strchr(line, '{');      if (p)      {        char *q = line;        // strip leading whitespaces        for (p++; *p == ' '; p++)          ;        while (*p != '\0')          *q++ = *p++;        *q = '\0';        q--;        // remove trailing }        if (*q == '}')          q--;        // strip trailing spaces        for (; *q == ' '; q--)          *q = '\0';        return true;      }      else      {        p = strchr(line, '}');        if (p) {          line[0] = '}';          line[1] = '\0';
          return true;        }      }    }  }  return false;}
char *ProjectImporter::ReadValue(char *line)
{
  char *p = strchr(line, '=');  if (!p)    return 0;  char *q = p;  for (p--; *p == ' '; p--)    *p = '\0';  for (q++; *q == ' '; q++)    ;  return q;}
bool ProjectImporter::ReadVersion(Version &ver)
{
  if (!ReadLine(buf, MAXLINE))    return false;  char *v = ReadValue(buf);  if (!v)    return false;  if (strcmp(buf, "Version") != 0)    return false;  ver.major = atoi(v);  v = strchr(v, '.');  if (v)    ver.minor = atoi(v + 1);  else    ver.minor = 0;  return true;}

bool ProjectImporter::ReadProjectName(char *name)
{
  if (!ReadLine(name, MAXLINE))    return false;  char *v = ReadValue(name);  if (!v)    return false;  if (strcmp(name, "Project") != 0)    return false;  while (*v)    *name++ = *v++;  *name = '\0';  return true;}
int ProjectImporter::ReadNodeCount()
{
  if (!ReadLine(buf, MAXLINE))
    return false;  char *v = ReadValue(buf);  if (!v)    return 0;  if (strcmp(buf, "Nodes") != 0)    return 0;  return atoi(v);}
bool ProjectImporter::ReadOptions(NodeOptions &options, HMSGITEM hMsgItem)
{
  if (!ReadLine(buf, MAXLINE))
    return false;

  if (strcmp(buf, "Options") != 0)
    return false;

	while (ReadLine(buf, MAXLINE))  {    if (buf[0] == '}')      return true;    if (hMsgItem)      messageFolder->NewMessage(hMsgItem, MakePolyString(buf));    char *v = ReadValue(buf);    if (strcmp(buf, "Include") == 0)      options.SetInclude(v);    else if (strcmp(buf, "Library") == 0)      options.SetLibrary(v);    else if (strcmp(buf, "Source") == 0)      options.SetSource(v);    else if (strcmp(buf, "Intermediate") == 0)      options.SetIntermediate(v);    else if (strcmp(buf, "Final") == 0)      options.SetFinal(v);    else if (strcmp(buf, "Defines") == 0)      options.SetDefines(v);    else if (strcmp(buf, "CmdLineOverride") == 0)      options.SetCmdLine(v);  }  return false;}

bool ProjectImporter::ReadFlags(ProjectNodeFlags &flags, HMSGITEM hMsgItem)
{
  if (!ReadLine(buf, MAXLINE))    return false;

  if (strcmp(buf, "Flags") != 0)
    return false;

  flags = (ProjectNodeFlags)0;

	while (ReadLine(buf, MAXLINE))  {    if (buf[0] == '}')      return true;    if (hMsgItem)      messageFolder->NewMessage(hMsgItem, MakePolyString(buf));    char *v = ReadValue(buf);    if (strcmp(buf, "Build") == 0) {      if (strcmp(v, "Depends") == 0)        flags |= PNF_BuildDepends;      else if (strcmp(v, "Always") == 0)        flags |= PNF_BuildAlways;      else if (strcmp(v, "Never") == 0)        flags |= PNF_BuildNever;    }    else if (strcmp(buf, "Exclude") == 0)      flags |= PNF_Exclude;    else if (strcmp(buf, "UserGen") == 0)      flags |= PNF_UserGen;  }  return false;}
bool ProjectImporter::ReadNode(NodeInfo &nodeInfo)
{
  nodeInfo.Clear();

	while (ReadLine(buf, MAXLINE))  {    if (buf[0] == '}')      return true;    char *v = ReadValue(buf);    if (strcmp(buf, "Target") == 0)    {      nodeInfo.SetIsTarget(true);      nodeInfo.SetName(v);    }    else if (strcmp(buf, "Node") == 0)      nodeInfo.SetName(v);    else if (strcmp(buf, "Type") == 0)    {      if (nodeInfo.IsTarget())        nodeInfo.SetTargetType((TargetType)atoi(v));      else        nodeInfo.SetType(v);    }    else if (strcmp(buf, "Level") == 0)      nodeInfo.SetLevel(atoi(v));    else if (strcmp(buf, "Platform") == 0)    {      if (nodeInfo.IsTarget())        nodeInfo.SetTargetPlatform((TargetPlatform)atoi(v));    }    else if (strcmp(buf, "Model") == 0)    {      if (nodeInfo.IsTarget())        nodeInfo.SetTargetModel((TargetModel)atoi(v));    }    else if (strcmp(buf, "StdLibs") == 0)    {      if (nodeInfo.IsTarget())        nodeInfo.SetTargetStdLibs((TargetStdLibs)atoi(v));    }  }  return false;}
void ProjectImporter::SetOptions(ProjectNode node, NodeOptions &options)
{
  SetOption(node, options.GetInclude(), OID_Include);
  SetOption(node, options.GetLibrary(), OID_Library);
  SetOption(node, options.GetSource(), OID_Source);  SetOption(node, options.GetIntermediate(), OID_Intermediate);  SetOption(node, options.GetFinal(), OID_Final);  SetOption(node, options.GetDefines(), OID_Defines);  SetOption(node, options.GetCmdLine(), OID_CmdlineOverride);}

void ProjectImporter::SetOption(ProjectNode node, const char *option,
                                OptionsStringIds oid)
{
  if (option)
    optionSetServer->OptionApply(node, oid, MakePolyString(option));  else    optionSetServer->OptionRemove(node, oid);}
void ProjectImporter::ReadProject(bool _loadTargets)
{
  loadTargets = _loadTargets;

  HMSGITEM hMsgItem = messageFolder->NewFileMessage(NULL, MakePolyString("Reading project"));  Version ver;  if (!ReadVersion(ver))    throw "Cannot read version";  if (ver.Compare(2, 0) != 0)    throw "Wrong version";  if (!ReadProjectName(buf))    throw "Cannot read project name";  messageFolder->NewMessage(hMsgItem, MakePolyString(buf));  NodeOptions options;  if (!ReadOptions(options, hMsgItem))    throw "Cannot read project options";  ProjectNode topNode = projectServer->QueryTopNode();  if (loadTargets)    SetOptions(topNode, options);  NodeStack stack;  stack.Push(topNode);  NodeInfo info;  ReadLine(buf, MAXLINE);  if (buf[0] != '}')    return;  while (ReadNode(info))  {    ProjectNodeFlags flags;    NodeOptions options;    if (info.IsTarget())      wsprintf(buf, "Target %s", info.GetName());    else      wsprintf(buf, "Node %s", info.GetName());    HMSGITEM hMsgItem = messageFolder->NewFileMessage(NULL, MakePolyString(buf));    if (info.IsTarget())    {    }    else    {      wsprintf(buf, "Type = %s", info.GetType());      messageFolder->NewMessage(hMsgItem, MakePolyString(buf));    }    wsprintf(buf, "Level = %d", info.GetLevel());    messageFolder->NewMessage(hMsgItem, MakePolyString(buf));    if (!ReadFlags(flags, hMsgItem))      break;    if (!ReadOptions(options, hMsgItem))      break;    while (info.GetLevel() < stack.GetLevel())      stack.Pop();    ProjectNode node = 0;    if (!loadTargets)    {      if (info.IsTarget())
        node = FindTarget(stack.Peek(), info.GetName());
      else
        node = FindNode(stack.Peek(), info.GetName(), info.GetType());    }    if (!node)    {      if (info.IsTarget())
      {        node = targetServer->TargetAdd(MakePolyString(info.GetName()),                                       stack.Peek(), info.GetTargetType(),                                       info.GetTargetPlatform(),                                       info.GetTargetStdLibs(),                                       info.GetTargetModel());      }      else        node = projectServer->NodeAdd(stack.Peek(), MakePolyString(info.GetName()),                                      MakePolyString(info.GetType()), flags);      projectServer->AddNodeFlags(node, flags);
      if (!(flags & PNF_Exclude))        projectServer->RemoveNodeFlags(node, PNF_Exclude);      if (!(flags & PNF_UserGen))        projectServer->RemoveNodeFlags(node, PNF_UserGen);      SetOptions(node, options);    }
    stack.Push(node);  }}
void ProjectImporter::ReadProject(ProjectNode node)
{
  Version ver;
  if (!ReadVersion(ver))    throw "Cannot read version";  if (ver.Compare(3, 0) != 0)    throw "Wrong version";  int nodeCount = ReadNodeCount();  if (nodeCount < 1)  	throw "Cannot read node count";  NodeStack stack;  stack.Push(node);  NodeInfo info;  while (ReadNode(info))  {    ProjectNodeFlags flags;    NodeOptions options;    if (info.IsTarget())      wsprintf(buf, "Target %s", info.GetName());    else      wsprintf(buf, "Node %s", info.GetName());    HMSGITEM hMsgItem = messageFolder->NewFileMessage(NULL, MakePolyString(buf));    if (info.IsTarget())    {    }    else {      wsprintf(buf, "Type = %s", info.GetType());      messageFolder->NewMessage(hMsgItem, MakePolyString(buf));    }    wsprintf(buf, "Level = %d", info.GetLevel());    messageFolder->NewMessage(hMsgItem, MakePolyString(buf));    if (!ReadFlags(flags, hMsgItem))      break;    if (!ReadOptions(options, hMsgItem))      break;    while (info.GetLevel() < stack.GetLevel())      stack.Pop();    ProjectNode node;    if (info.IsTarget())      node = targetServer->TargetAdd(MakePolyString(info.GetName()),                                     stack.Peek(), info.GetTargetType(),                                     info.GetTargetPlatform(),                                     info.GetTargetStdLibs(),                                     info.GetTargetModel());    else      node = projectServer->NodeAdd(stack.Peek(), MakePolyString(info.GetName()),                                    MakePolyString(info.GetType()), flags);    projectServer->AddNodeFlags(node, flags);    if (!(flags & PNF_Exclude))      projectServer->RemoveNodeFlags(node, PNF_Exclude);    SetOptions(node, options);    stack.Push(node);  }}
ProjectNode ProjectImporter::FindNode(ProjectNode parent, const char *name, const char *type)
{
  ProjectNodeInfo info(projectServer->QueryNodeInfo(parent));

  if (!info)
    return 0;

  ProjectNode child = info->GetFirstChild();

  while (child)
  {
    ProjectNodeInfo info2(projectServer->QueryNodeInfo(child));

    if (info2)
    {
      if (stricmp(info2->GetName()->GetCstr(), name) == 0 &&
          stricmp(info2->GetNodeType()->GetCstr(), type) == 0)
        return child;
    }
    
    child = info2->GetNextSibling();
  }

  return 0;
}

ProjectNode ProjectImporter::FindTarget(ProjectNode parent, const char *name)
{
  ProjectNodeInfo info(projectServer->QueryNodeInfo(parent));

  if (!info)
    return 0;

  ProjectNode child = info->GetFirstChild();

  while (child)
  {
    ProjectNodeInfo info2(projectServer->QueryNodeInfo(child));

    if (info2)
    {
      if (stricmp(info2->GetName()->GetCstr(), name) == 0 &&
          targetServer->NodeIsTarget(child))
        return child;
    }

    child = info2->GetNextSibling();
  }

  return 0;
}

