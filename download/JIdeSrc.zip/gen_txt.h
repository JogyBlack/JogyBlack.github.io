/*------------------------------------------------------------------------------
Header: gen_txt.h
Description:
Note:
Author: Jogy
Date created: 21 March 2000
Date last modified: 21 March 2000
------------------------------------------------------------------------------*/

#ifndef __gen_txt_h__  	// Sentry
#define __gen_txt_h__

#include "toolbase.h"

class ProjectServer;
class OptionSetServer;

class Node;

class GenTxtTool : public ToolBase
{
  public:
    GenTxtTool();

    virtual ToolTypes GetTypes() const { return TT_Viewer; }
    virtual const char *GetName() const;    virtual unsigned GetFlags() const { return TIFlag_OnToolsMenu; }    virtual const char *GetMenuName() const;    virtual const char *GetHelpHint() const;    virtual const char *GetRegKeyName() const;

    virtual ToolReturn Execute(IPolyString *cmdLine,
                               ProjectNode *nodeArray,
                               int numNodes);

  private:
    void WriteChildren(ProjectNode node, ProjectServer &projectServer,
                       OptionSetServer &optionSetServer, Node *first,
                       ofstream &ofs);

    void GetIncludes(const char *fileName, const char *src,
                     const char *inc, Node *first);
};

#endif  	// Sentry

