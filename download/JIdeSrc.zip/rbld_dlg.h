extern int RebuildDialog(HWND hParent, LibTypes *_libTypes);
extern int TargetsDialog(HWND hParent, LibTypes *_libTypes);
