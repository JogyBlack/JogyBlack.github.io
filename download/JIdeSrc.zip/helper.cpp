#include "all.h"
#pragma hdrstop

#include "helper.h"

int GetIDEVersion()
{
  ScriptServer scriptServer;
  PolyString result(CreatePolyString());
  scriptServer->RunScriptCommand(MakePolyString("return IDE.Version;"), result.Get());
	return atoi(result->GetCstr());
}

int ShowMessageBox(const char *msg, MessageBoxType type)
{
  try
  {
    IdeWindow ideWin;
//    IdeUI ideUI;

    HWND parent = ideWin->GetHwnd();

    int result/* = 0*/;

    int flags;

    switch (type)
    {
/*
      case ErrorMBox: result = ideUI->ErrorBox(parent, msg); break;
      case GetYesNoMBox: result = ideUI->GetYesNoBox(parent, msg); break;
      case DoOkCancelMBox: result = ideUI->DoOkCancelBox(parent, msg); break;
      case InfoMBox: result = ideUI->InfoBox(parent, msg); break;
*/
	    case ErrorMBox: flags = MB_OK | MB_ICONSTOP; break;
      case GetYesNoMBox: flags = MB_YESNO; break;
      case DoOkCancelMBox: flags = MB_OKCANCEL; break;
      case InfoMBox: flags = MB_OK; break;
    }

		result = MessageBox(parent, msg, "JIdeTool", flags);

    return result;
  }
  catch (...)
  {
    return -1;
  }
}

bool SetWaitCursor(bool set)
{
  try
  {
    int ver = GetIDEVersion();    if (ver >= 502)    {      IdeUI ideUI;      if (set)        ideUI->StartWait();      else        ideUI->StopWait();      return true;    }    else    	return false;  }  catch (...)  {    return false;  }}////////////////////////////////////////////////////////////////////////////////
BOOL BackupOriginalFile(const char *name, const char *ext)
{
  char source[MAX_PATH];
  char dest[MAX_PATH];

  strcpy(source, name);
  strcat(source, ext);

  strcpy(dest, source);

  dest[strlen(dest) - 1] = '0';

  return CopyFile(source, dest, FALSE);
}
BOOL RestoreOriginalFile(const char *name, const char *ext)
{
  char source[MAX_PATH];  char dest[MAX_PATH];

  strcpy(source, name);
  strcat(source, ext);

  strcpy(dest, source);

  source[strlen(source) - 1] = '0';

  return CopyFile(source, dest, FALSE);}
BOOL DeleteOriginalFile(const char *name, const char *ext)
{
  char filename[MAX_PATH];

  strcpy(filename, name);
  strcat(filename, ext);

  return DeleteFile(filename);}
BOOL ChangeFileTime(HANDLE hFileSrc, HANDLE hFileDst)
{
  FILETIME filetime;  SYSTEMTIME systemtime;  if (!GetFileTime(hFileSrc, NULL, NULL, &filetime))    return FALSE;  if (!FileTimeToSystemTime(&filetime, &systemtime))    return FALSE;  systemtime.wMinute++;  if (!SystemTimeToFileTime(&systemtime, &filetime))    return FALSE;  if (!SetFileTime(hFileDst, NULL, NULL, &filetime))    return FALSE;  return TRUE;}
BOOL ChangeFileTime(const char *name, const char *extSrc, const char *extDst)
{
  char source[MAX_PATH];
  char dest[MAX_PATH];

  strcpy(source, name);
  strcat(dest, name);

  strcat(source, extSrc);
  strcat(dest, extDst);

  HANDLE hFileSrc = CreateFile(source, GENERIC_READ, 0, NULL,
                               OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);  if (!hFileSrc)    return FALSE;  HANDLE hFileDst = CreateFile(dest, GENERIC_WRITE, 0, NULL,                               OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);  if (!hFileDst)  {    CloseHandle(hFileSrc);    return FALSE;  }  BOOL result = ChangeFileTime(hFileSrc, hFileDst);  CloseHandle(hFileSrc);  CloseHandle(hFileDst);  return result;}
void AddFilePath(char *str, const char *filepath)
{
  char *p = str + strlen(str);
  // Replace \ with \\ for the script command
  for (int i = 0; filepath[i] != '\0'; i++)
  {
    if (filepath[i] == '\\')
    {
      *p++ = '\\';
      *p++ = '\\';
    }
    else
      *p++ = filepath[i];
  }

  *p = '\0';
}

////////////////////////////////////////////////////////////////////////////////

const char KEYNAME[] = "Software\\Borland\\Borland C++\\5.0\\Ide\\AddOns\\JIdeTool";
const int BUFLEN = 80;

bool LoadOption(const char *name, char *buf, int buflen)
{
	HKEY hKey = NULL;
  DWORD type = REG_SZ;
  DWORD len = buflen;

	LONG result = RegOpenKeyEx(HKEY_LOCAL_MACHINE, KEYNAME, 0, KEY_READ, &hKey);
  if (result != ERROR_SUCCESS)
  	return false;

  result = RegQueryValueEx(hKey, name, 0, &type, (LPBYTE)buf, &len);
  if (result != ERROR_SUCCESS)
  {
  	RegCloseKey(hKey);
  	return false;
  }

	RegCloseKey(hKey);

  if (type != REG_SZ)
  	return false;

	return true;
}

bool LoadOption(const char *name, bool defValue)
{
  char buf[BUFLEN];

  if (LoadOption(name, buf, BUFLEN))
		return stricmp(buf, "Yes") == 0;
  else
  	return defValue;
}

int LoadOption(const char *name, int defValue)
{
  char buf[BUFLEN];

  if (LoadOption(name, buf, BUFLEN))
		return atoi(buf);
  else
  	return defValue;
}

void SaveOption(const char *name, const char *buf, int buflen)
{
	HKEY hKey = NULL;
  DWORD type = REG_SZ;
  DWORD len = buflen;

	LONG result = RegCreateKeyEx(HKEY_LOCAL_MACHINE, KEYNAME, 0, 0, 0, KEY_WRITE, 0, &hKey, 0);
  if (result != ERROR_SUCCESS)
  	return;

	RegSetValueEx(hKey, name, 0, type, (LPBYTE)buf, len);

  RegCloseKey(hKey);
}

void SaveOption(const char *name, bool value)
{
  char buf[BUFLEN];

  if (value)
  	strcpy(buf, "Yes");
  else
  	strcpy(buf, "No");

  SaveOption(name, buf, BUFLEN);
}

void SaveOption(const char *name, int value)
{
  char buf[BUFLEN];

  wsprintf(buf, "%d", value);

  SaveOption(name, buf, BUFLEN);
}

