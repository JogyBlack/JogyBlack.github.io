#include "all.h"
#pragma hdrstop

#include "rebuild.h"
#include "helper.h"
#include "export.h"
#include "import.h"
#include "rbld_dlg.h"
#include "fix_pdl.h"
#include "targdata.h"

////////////////////////////////////////////////////////////////////////////////

ProjectRebuildTool::ProjectRebuildTool()
{
}

const char *ProjectRebuildTool::GetName() const
{
  return "ProjectRebuild";}

const char *ProjectRebuildTool::GetMenuName() const{  return "&Project Rebuild";}const char *ProjectRebuildTool::GetHelpHint() const{  return "Create new project which contains all nodes from current project";}const char *ProjectRebuildTool::GetRegKeyName() const
{
  return "Enable Project Rebuilding";
}

ToolReturn ProjectRebuildTool::Execute(IPolyString * cmdLine ,
                                ProjectNode * /* nodeArray */,
                                int /* numNodes */ )
{
  if (cmdLine)
    cmdLine->Release();

  try
  {
    ProjectServer projectServer;

    if (projectServer->IsDefaultProject())
    {
      ShowMessageBox("No project opened.", ErrorMBox);
      return TR_Errors;
    }

    IdeWindow ideWin;

    LibTypes libTypes;

    if (RebuildDialog(ideWin->GetHwnd(), &libTypes) != IDOK)
      return TR_Success;

    SetWaitCursor(true);

    // Set up servers
    ScriptServer scriptServer;
    TargetServer targetServer;
    OptionSetServer optionSetServer;

    MessageSystem messageSystem;
    MessageFolder messageFolder = messageSystem->NewFolder(MakePolyString("AddOn"), MakePolyString("JIde"));


    HMSGITEM hMsgItem = messageFolder->NewFileMessage(NULL, MakePolyString("Saving project"));

    // Get project node info
    ProjectNode topNode = projectServer->QueryTopNode();
    ProjectNodeInfo info(projectServer->QueryNodeInfo(topNode));
    if (!info)
      throw "Cannot get top node info";

    // Get current directory for the project
    PolyString result(CreatePolyString());
    scriptServer->RunScriptCommand(MakePolyString("return IDE.CurrentDirectory;"), result.Get());

    PolyString name(info->GetName());

    char projectFileName[_MAX_PATH];
    wsprintf(projectFileName, "%s\\%s", result->GetCstr(), name->GetCstr());

    if (!BackupOriginalFile(projectFileName, ".ide"))
      throw "Cannot backup project";
    BackupOriginalFile(projectFileName, ".dsw");

    messageFolder->NewMessage(hMsgItem, MakePolyString(projectFileName));

    char outputFileName[MAX_PATH];
    wsprintf(outputFileName, "%s.jde", projectFileName);
    ofstream os(outputFileName);
    if (!os)
      throw outputFileName;


    os << "{ Version = 2.00 }" << endl;
    os << "{ Project = " << name->GetCstr() << endl;

    ProjectExporter exporter(os, messageFolder, projectServer,
                             targetServer, optionSetServer);

    exporter.SetLibTypes(libTypes);

    exporter.WriteOptions(topNode, false, hMsgItem);

    os << "}" << endl;

    // Export project targets and nodes
    exporter.WriteChildren(info->GetFirstChild(), 1);

    os.close();

    if (exporter.IsAppExpert())
    {
      int res = ShowMessageBox("The project contains AppExpert nodes. These nodes will be converted to non-AppExpert. Continue?", GetYesNoMBox);
      if (res != IDYES)
        return TR_Success;
    }

    char oldSaveAsText[10];

    if (libTypes.transferStyleSheets)
    {
      GetPrivateProfileString("Project", "SaveAsText", "0", oldSaveAsText, 10, "bcw5.ini");

   	 // Force the IDE to create .pdl file
	    WritePrivateProfileString("Project", "SaveAsText", "1", "bcw5.ini");
		}

    // Remove old project
    scriptServer->RunScriptCommand(MakePolyString("IDE.ProjectCloseProject();"));
    if (DeleteOriginalFile(projectFileName, ".ide") == 0)
      throw "Cannot delete file.";

    if (libTypes.transferStyleSheets)
    {
	    WritePrivateProfileString("Project", "SaveAsText", oldSaveAsText, "bcw5.ini");

    	// Backup and test for existence .pdl file
      if (!BackupOriginalFile(projectFileName, ".pdl"))
      {
        int res = ShowMessageBox("Cannot backup .pdl file. Continue?", GetYesNoMBox);
        if (res != IDYES)
          return TR_Success;
        else
          libTypes.transferStyleSheets = false;
      }
    }

    // Create new project
    char command[MAX_PATH + 40];
    strcpy(command, "IDE.ProjectNewProject(\"");
    AddFilePath(command, projectFileName);
    strcat(command, "\");");
    scriptServer->RunScriptCommand(MakePolyString(command));

    ifstream is(outputFileName);

    if (!is)
      throw outputFileName;

    ProjectImporter importer(is, messageFolder, projectServer,
                             targetServer, optionSetServer);

    // Read node in the new project
    importer.ReadProject();

    if (libTypes.transferStyleSheets)
    {
	    char oldReadAsText[10];
      GetPrivateProfileString("Project", "ReadAsText", "0", oldReadAsText, 10, "bcw5.ini");

      // Close the new project
      scriptServer->RunScriptCommand(MakePolyString("IDE.ProjectCloseProject();"));

      // Restore and fix the old .pdl file
      if (!FixPdl(projectFileName, libTypes.transferTools))
        throw "Cannot fix pdl file.";

      RestoreOriginalFile(projectFileName, ".dsw");

      ChangeFileTime(projectFileName, ".ide", ".pdl");
      ChangeFileTime(projectFileName, ".ide", ".dsw");

	    WritePrivateProfileString("Project", "ReadAsText", "1", "bcw5.ini");

      strcpy(command, "IDE.ProjectOpenProject(\"");
      AddFilePath(command, projectFileName);
      strcat(command, "\");");

      // Open again the project
      scriptServer->RunScriptCommand(MakePolyString(command));

	    WritePrivateProfileString("Project", "ReadAsText", oldReadAsText, "bcw5.ini");
    }

    SetWaitCursor(false);

    return TR_Success;
  }
  catch (const char *msg)
  {
    SetWaitCursor(false);

    ShowMessageBox(msg, ErrorMBox);

    return TR_FatalError;
  }
}

////////////////////////////////////////////////////////////////////////////////

ProjectRestoreTool::ProjectRestoreTool()
{
}

const char *ProjectRestoreTool::GetName() const
{
  return "ProjectRestore";}

const char *ProjectRestoreTool::GetMenuName() const{  return "&Project Restore";}const char *ProjectRestoreTool::GetHelpHint() const{  return "Create new project which contains all nodes from current project";}const char *ProjectRestoreTool::GetRegKeyName() const
{
  return "Enable Project Rebuilding";
}

ToolReturn ProjectRestoreTool::Execute(IPolyString * cmdLine ,
                                  ProjectNode * /* nodeArray */,
                                  int /* numNodes */ )
{
  if (cmdLine)
    cmdLine->Release();

  try
  {
    int res = ShowMessageBox("Restore rebuilt project?", GetYesNoMBox);
    if (res != IDYES)
      return TR_Success;

    bool transferPDL = true;

    SetWaitCursor(true);

    // Set up servers
    ProjectServer projectServer;
    ScriptServer scriptServer;

    ProjectNode topNode = projectServer->QueryTopNode();
    ProjectNodeInfo info(projectServer->QueryNodeInfo(topNode));
    if (!info)
      throw "Cannot get top node info";

    // Get current directory for the project
    PolyString result(CreatePolyString());
    scriptServer->RunScriptCommand(MakePolyString("return IDE.CurrentDirectory;"), result.Get());

    PolyString name(info->GetName());

    char projectFileName[MAX_PATH];
    wsprintf(projectFileName, "%s\\%s", result->GetCstr(), name->GetCstr());

    // Close current project
    scriptServer->RunScriptCommand(MakePolyString("IDE.ProjectCloseProject();"));


    // Restore backuped files

    if (!RestoreOriginalFile(projectFileName, ".ide"))
      throw "Cannot restore project";

    RestoreOriginalFile(projectFileName, ".dsw");

    if (transferPDL)
      if (!RestoreOriginalFile(projectFileName, ".pdl"))
        throw "Cannot restore project";


    // Open the restored project

    char command[MAX_PATH + 40];
    strcpy(command, "IDE.ProjectNewProject(\"");
    AddFilePath(command, projectFileName);
    strcat(command, "\");");


    scriptServer->RunScriptCommand(MakePolyString(command));

    SetWaitCursor(false);

    return TR_Success;
  }
  catch (const char *msg)
  {
    SetWaitCursor(false);

    ShowMessageBox(msg, ErrorMBox);

    return TR_FatalError;
  }
  catch (...)
  {
    ShowMessageBox("Exception", ErrorMBox);

    return TR_FatalError;
  }
}

////////////////////////////////////////////////////////////////////////////////

ExportBranchTool::ExportBranchTool()
{
}

const char *ExportBranchTool::GetName() const
{
  return "ExportBranch";}

const char *ExportBranchTool::GetMenuName() const{  return "&Export Branch";}const char *ExportBranchTool::GetHelpHint() const{  return "Export current node and all it\'s subnodes";}const char *ExportBranchTool::GetRegKeyName() const{
  return "Enable Export Import Project";
}

ToolReturn ExportBranchTool::Execute(IPolyString * cmdLine,                                  ProjectNode * /* nodeArray */,
                                  int /* numNodes */ )
{
  if (cmdLine)
    cmdLine->Release();

  try
  {

    // Set up servers
    TargetServer targetServer;
    ProjectServer projectServer;
    OptionSetServer optionSetServer;
    ScriptServer scriptServer;

    int nodeCount;
    ProjectNode *nodes = projectServer->QuerySelectedNodes(&nodeCount);

    if (!nodes || nodeCount < 1)
    	throw "No selected node";

    // Get current directory for the project
    PolyString result(CreatePolyString());
    scriptServer->RunScriptCommand(MakePolyString("return IDE.CurrentDirectory;"), result.Get());

    IdeWindow ideWin;

    char exportFileName[MAX_PATH];
    exportFileName[0] = '\0';

  	OPENFILENAME ofn;
    memset((void *)&ofn, '\0', sizeof(ofn));
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = ideWin->GetHwnd();
    ofn.lpstrFilter = "IDE Export files (*.idx)\0*.idx\0All files (*.*)\0*.*\0\0";
    ofn.lpstrFile = exportFileName;
    ofn.nMaxFile = MAX_PATH;
    ofn.lpstrDefExt = "idx";
    ofn.lpstrInitialDir = result->GetCstr();
    ofn.lpstrTitle = "Export branch to file";
    ofn.Flags = OFN_EXPLORER | OFN_HIDEREADONLY |
                OFN_NOCHANGEDIR | OFN_OVERWRITEPROMPT;

    if (!GetSaveFileName(&ofn))
      return TR_Success;

    SetWaitCursor(true);

    MessageSystem messageSystem;
    MessageFolder messageFolder = messageSystem->NewFolder(MakePolyString("AddOn"), MakePolyString("JIde"));

    ofstream os(exportFileName);
    if (!os)
      throw exportFileName;

    os << "{ Version = 3.00 }" << endl;
    os << "{ Nodes = " << nodeCount << " }" << endl;

    ProjectExporter exporter(os, messageFolder, projectServer,
                             targetServer, optionSetServer);

		for (int nodeIndex = 0; nodeIndex < nodeCount; nodeIndex++)
	    exporter.WriteChildren(nodes[nodeIndex], 1, false);

    os.close();

    SetWaitCursor(false);

    return TR_Success;
  }
  catch (const char *msg)
  {
    SetWaitCursor(false);

    ShowMessageBox(msg, ErrorMBox);

    return TR_FatalError;
  }
  catch (...)
  {
    ShowMessageBox("Exception", ErrorMBox);

    return TR_FatalError;
  }
}

////////////////////////////////////////////////////////////////////////////////

ImportBranchTool::ImportBranchTool()
{
}

const char *ImportBranchTool::GetName() const
{
  return "ImportBranch";}

const char *ImportBranchTool::GetMenuName() const{  return "&Import Branch";}const char *ImportBranchTool::GetHelpHint() const{  return "Import node and all it\'s subnodes";}const char *ImportBranchTool::GetRegKeyName() const{
  return "Enable Export Import Branch";
}
ToolReturn ImportBranchTool::Execute(IPolyString * cmdLine,
                                  ProjectNode * /* nodeArray */,
                                  int /* numNodes */ )
{
  if (cmdLine)
    cmdLine->Release();

  try
  {

    // Set up servers
    TargetServer targetServer;
    ProjectServer projectServer;
    OptionSetServer optionSetServer;
    ScriptServer scriptServer;

    int nodeCount;
    ProjectNode *nodes = projectServer->QuerySelectedNodes(&nodeCount);

    if (!nodes || nodeCount != 1)
    	throw "No selected node";

    // Get current directory for the project
    PolyString result(CreatePolyString());
    scriptServer->RunScriptCommand(MakePolyString("return IDE.CurrentDirectory;"), result.Get());

    IdeWindow ideWin;

    char importFileName[MAX_PATH];
    importFileName[0] = '\0';

  	OPENFILENAME ofn;
    memset((void *)&ofn, '\0', sizeof(ofn));
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = ideWin->GetHwnd();
    ofn.lpstrFilter = "IDE Export files (*.idx)\0*.idx\0All files (*.*)\0*.*\0\0";
    ofn.lpstrFile = importFileName;
    ofn.nMaxFile = MAX_PATH;
    ofn.lpstrDefExt = "idx";
    ofn.lpstrInitialDir = result->GetCstr();
    ofn.lpstrTitle = "Import branch from file";
    ofn.Flags = OFN_EXPLORER | OFN_HIDEREADONLY |
                OFN_NOCHANGEDIR | OFN_FILEMUSTEXIST;

    if (!GetOpenFileName(&ofn))
      return TR_Success;

    SetWaitCursor(true);

    MessageSystem messageSystem;
    MessageFolder messageFolder = messageSystem->NewFolder(MakePolyString("AddOn"), MakePolyString("JIde"));

    ifstream is(importFileName);

    if (!is)
      throw importFileName;

    ProjectImporter importer(is, messageFolder, projectServer,
                             targetServer, optionSetServer);

    // Read node in the new project
    importer.ReadProject(nodes[0]);

    SetWaitCursor(false);

    return TR_Success;
  }
  catch (const char *msg)
  {
    SetWaitCursor(false);

    ShowMessageBox(msg, ErrorMBox);

    return TR_FatalError;
  }
  catch (...)
  {
    ShowMessageBox("Exception", ErrorMBox);

    return TR_FatalError;
  }
}

////////////////////////////////////////////////////////////////////////////////

ExportProjectTool::ExportProjectTool()
{
}

const char *ExportProjectTool::GetName() const
{
  return "ExportProject";}

const char *ExportProjectTool::GetMenuName() const{  return "&Export Project";}const char *ExportProjectTool::GetHelpHint() const{  return "Export current project to text file";}const char *ExportProjectTool::GetRegKeyName() const{
  return "Enable Export Import Project";
}

ToolReturn ExportProjectTool::Execute(IPolyString * cmdLine,                                  ProjectNode * /* nodeArray */,
                                  int /* numNodes */ )
{
  if (cmdLine)
    cmdLine->Release();

  try
  {
    ProjectServer projectServer;

    if (projectServer->IsDefaultProject())
    {
      ShowMessageBox("No project opened.", ErrorMBox);
      return TR_Errors;
    }

    IdeWindow ideWin;

    LibTypes libTypes;
    libTypes.transferStyleSheets = false;
    libTypes.transferTools = false;
    libTypes.convertNodelessTarget = false;
    libTypes.clearOverrides = false;

    SetWaitCursor(true);

    // Set up servers
    ScriptServer scriptServer;
    TargetServer targetServer;
    OptionSetServer optionSetServer;

    MessageSystem messageSystem;
    MessageFolder messageFolder = messageSystem->NewFolder(MakePolyString("AddOn"), MakePolyString("JIde"));


    HMSGITEM hMsgItem = messageFolder->NewFileMessage(NULL, MakePolyString("Exporting project"));

    // Get project node info
    ProjectNode topNode = projectServer->QueryTopNode();
    ProjectNodeInfo info(projectServer->QueryNodeInfo(topNode));
    if (!info)
      throw "Cannot get top node info";

    // Get current directory for the project
    PolyString result(CreatePolyString());
    scriptServer->RunScriptCommand(MakePolyString("return IDE.CurrentDirectory;"), result.Get());

    PolyString name(info->GetName());

    char projectFileName[_MAX_PATH];
    wsprintf(projectFileName, "%s\\%s", result->GetCstr(), name->GetCstr());

    messageFolder->NewMessage(hMsgItem, MakePolyString(projectFileName));

    char outputFileName[MAX_PATH];
    wsprintf(outputFileName, "%s.idp", projectFileName);
    ofstream os(outputFileName);
    if (!os)
      throw outputFileName;


    os << "{ Version = 2.00 }" << endl;
    os << "{ Project = " << name->GetCstr() << endl;

    ProjectExporter exporter(os, messageFolder, projectServer,
                             targetServer, optionSetServer);

    exporter.SetLibTypes(libTypes);

    exporter.WriteOptions(topNode, false, hMsgItem);

    os << "}" << endl;

    // Export project targets and nodes
    exporter.WriteChildren(info->GetFirstChild(), 1);

    os.close();

    SetWaitCursor(false);

    return TR_Success;
  }
  catch (const char *msg)
  {
    SetWaitCursor(false);

    ShowMessageBox(msg, ErrorMBox);

    return TR_FatalError;
  }
}

////////////////////////////////////////////////////////////////////////////////

ImportProjectTool::ImportProjectTool()
{
}

const char *ImportProjectTool::GetName() const
{
  return "ImportProject";}

const char *ImportProjectTool::GetMenuName() const{  return "&Import Project";}const char *ImportProjectTool::GetHelpHint() const{  return "Import current project nodes from a text file";}const char *ImportProjectTool::GetRegKeyName() const{
  return "Enable Export Import Project";
}
ToolReturn ImportProjectTool::Execute(IPolyString * cmdLine,
                                  ProjectNode * /* nodeArray */,
                                  int /* numNodes */ )
{
  if (cmdLine)
    cmdLine->Release();

  try
  {
    ProjectServer projectServer;

    if (projectServer->IsDefaultProject())
    {
      ShowMessageBox("No project opened.", ErrorMBox);
      return TR_Errors;
    }

    IdeWindow ideWin;

    LibTypes libTypes;
    libTypes.transferStyleSheets = false;
    libTypes.transferTools = false;
    libTypes.convertNodelessTarget = false;
    libTypes.clearOverrides = false;

    SetWaitCursor(true);

    // Set up servers
    ScriptServer scriptServer;
    TargetServer targetServer;
    OptionSetServer optionSetServer;

    MessageSystem messageSystem;
    MessageFolder messageFolder = messageSystem->NewFolder(MakePolyString("AddOn"), MakePolyString("JIde"));


    HMSGITEM hMsgItem = messageFolder->NewFileMessage(NULL, MakePolyString("Loading project"));

    // Get project node info
    ProjectNode topNode = projectServer->QueryTopNode();
    ProjectNodeInfo info(projectServer->QueryNodeInfo(topNode));
    if (!info)
      throw "Cannot get top node info";

    // Get current directory for the project
    PolyString result(CreatePolyString());
    scriptServer->RunScriptCommand(MakePolyString("return IDE.CurrentDirectory;"), result.Get());

    PolyString name(info->GetName());

    char projectFileName[_MAX_PATH];
    wsprintf(projectFileName, "%s\\%s", result->GetCstr(), name->GetCstr());

    messageFolder->NewMessage(hMsgItem, MakePolyString(projectFileName));

    char outputFileName[MAX_PATH];
    wsprintf(outputFileName, "%s.idp", projectFileName);

    ifstream is(outputFileName);

    if (!is)
      throw outputFileName;

    ProjectImporter importer(is, messageFolder, projectServer,
                             targetServer, optionSetServer);

    // Read node in the new project
    importer.ReadProject(false);

    SetWaitCursor(false);

    return TR_Success;
  }
  catch (const char *msg)
  {
    SetWaitCursor(false);

    ShowMessageBox(msg, ErrorMBox);

    return TR_FatalError;
  }
  catch (...)
  {
    ShowMessageBox("Exception", ErrorMBox);

    return TR_FatalError;
  }
}

////////////////////////////////////////////////////////////////////////////////

TargetsSettingsTool::TargetsSettingsTool()
{
}

const char *TargetsSettingsTool::GetName() const
{
  return "TargetSettings";}

const char *TargetsSettingsTool::GetMenuName() const{  return "&Change all Targets Settings";}const char *TargetsSettingsTool::GetHelpHint() const{  return "Change the settings of all targets in the current project";}const char *TargetsSettingsTool::GetRegKeyName() const{
  return "Enable Change Target Settings";
}
ToolReturn TargetsSettingsTool::Execute(IPolyString * cmdLine,                                        ProjectNode * /* nodeArray */,
                                        int /* numNodes */ )
{
  if (cmdLine)
    cmdLine->Release();

  try
  {
    ProjectServer projectServer;

    if (projectServer->IsDefaultProject())
    {
      ShowMessageBox("No project opened.", ErrorMBox);
      return TR_Errors;
    }

    IdeWindow ideWin;

    LibTypes libTypes;

    if (TargetsDialog(ideWin->GetHwnd(), &libTypes) != IDOK)
      return TR_Success;

		if (libTypes.libStatic == LibTypes::SAME &&
        libTypes.libMT == LibTypes::SAME &&
        libTypes.libCG == LibTypes::SAME &&
        libTypes.libDiag == LibTypes::SAME &&
        libTypes.styleSheetNo < 0)
    {
      ShowMessageBox("Nothing to do.", ErrorMBox);
      return TR_Errors;
    }

    SetWaitCursor(true);

    // Set up servers
    ScriptServer scriptServer;
    TargetServer targetServer;
    OptionSetServer optionSetServer;

    MessageSystem messageSystem;
    MessageFolder messageFolder = messageSystem->NewFolder(MakePolyString("AddOn"), MakePolyString("JIde"));

    scriptServer->RunScriptCommand(MakePolyString("IDE.ViewProject();"));
    scriptServer->RunScriptCommand(MakePolyString("IDE.KeyboardManager.SendKeys(\"{VK_HOME}*\");"));

    ProjectNode lastNode = 0;

    while (true)
    {
      int nodeCount;
      ProjectNode *nodes = projectServer->QuerySelectedNodes(&nodeCount);
      if (nodeCount != 1)
      	break;

			if (nodes[0] == lastNode)
      	break;

			lastNode = nodes[0];

			if (targetServer->NodeIsTarget(nodes[0]))
      {
      	ProjectNodeInfo info(projectServer->QueryNodeInfo(nodes[0]));
        TargetData targetData(projectServer, info);

        bool changed = false;

		    HMSGITEM hMsgItem = messageFolder->NewFileMessage(NULL, info->GetName());

        if (libTypes.libStatic == LibTypes::SET && !targetData.IsStatic())
        {
			    scriptServer->RunScriptCommand(MakePolyString("IDE.KeyboardManager.SendKeys(\"%{VK_F10}t%s{VK_RETURN}\");"));
			    messageFolder->NewMessage(hMsgItem, MakePolyString("Set Static libraries"));
          changed = true;
        }
        if (libTypes.libStatic == LibTypes::CLEAR && targetData.IsStatic())
        {
			    scriptServer->RunScriptCommand(MakePolyString("IDE.KeyboardManager.SendKeys(\"%{VK_F10}t%s{VK_RETURN}\");"));
			    messageFolder->NewMessage(hMsgItem, MakePolyString("Set Dynamic libraries"));
          changed = true;
        }

        if (libTypes.libMT == LibTypes::SET && !targetData.IsMT())
        {
			    scriptServer->RunScriptCommand(MakePolyString("IDE.KeyboardManager.SendKeys(\"%{VK_F10}t%u{VK_RETURN}\");"));
			    messageFolder->NewMessage(hMsgItem, MakePolyString("Set Multithread libraries"));
          changed = true;
        }
        if (libTypes.libMT == LibTypes::CLEAR && targetData.IsMT())
        {
			    scriptServer->RunScriptCommand(MakePolyString("IDE.KeyboardManager.SendKeys(\"%{VK_F10}t%u{VK_RETURN}\");"));
			    messageFolder->NewMessage(hMsgItem, MakePolyString("Clear Multithread libraries"));
          changed = true;
        }

        if (libTypes.libCG == LibTypes::SET && !targetData.IsCG())
        {
			    scriptServer->RunScriptCommand(MakePolyString("IDE.KeyboardManager.SendKeys(\"%{VK_F10}t%g{VK_RETURN}\");"));
			    messageFolder->NewMessage(hMsgItem, MakePolyString("Set CodeGuard"));
          changed = true;
        }
        if (libTypes.libCG == LibTypes::CLEAR && targetData.IsCG())
        {
			    scriptServer->RunScriptCommand(MakePolyString("IDE.KeyboardManager.SendKeys(\"%{VK_F10}t%g{VK_RETURN}\");"));
			    messageFolder->NewMessage(hMsgItem, MakePolyString("Clear CodeGuard"));
          changed = true;
        }

        if (libTypes.libDiag == LibTypes::SET && !targetData.IsDiag())
        {
			    scriptServer->RunScriptCommand(MakePolyString("IDE.KeyboardManager.SendKeys(\"%{VK_F10}t%i{VK_RETURN}\");"));
			    messageFolder->NewMessage(hMsgItem, MakePolyString("Set Diagnostic libraries"));
          changed = true;
        }
        if (libTypes.libDiag == LibTypes::CLEAR && targetData.IsDiag())
        {
			    scriptServer->RunScriptCommand(MakePolyString("IDE.KeyboardManager.SendKeys(\"%{VK_F10}t%i{VK_RETURN}\");"));
			    messageFolder->NewMessage(hMsgItem, MakePolyString("Clear Diagnostic libraries"));
          changed = true;
        }

        if (changed && libTypes.clearOverrides)
					optionSetServer->OptionRemove(nodes[0], OID_Defines);

				if (libTypes.styleSheetNo >= 0)
        {
        	char buf[100];
          strcpy(buf, "IDE.KeyboardManager.SendKeys(\"%{VK_F10}n%s{VK_HOME}");
          for (int index = 0; index < libTypes.styleSheetNo; index++)
          	strcat(buf, "{VK_DOWN}");
          strcat(buf, "{VK_RETURN}\");");
			    scriptServer->RunScriptCommand(MakePolyString(buf));

			    messageFolder->NewMessage(hMsgItem, MakePolyString("Set Style Sheet"));
        }

      }

	    scriptServer->RunScriptCommand(MakePolyString("IDE.KeyboardManager.SendKeys(\"{VK_DOWN}\");"));
    }

    scriptServer->RunScriptCommand(MakePolyString("IDE.KeyboardManager.SendKeys(\"{VK_HOME}/\");"));


    SetWaitCursor(false);

    return TR_Success;
  }
  catch (const char *msg)
  {
    SetWaitCursor(false);

    ShowMessageBox(msg, ErrorMBox);

    return TR_FatalError;
  }
}


