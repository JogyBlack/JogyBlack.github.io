#include "all.h"
#pragma hdrstop

#include "targdata.h"

TargetData::TargetData(ProjectServer &projectServer, ProjectNodeInfo &info)
{
  targetType = TT_Application;
  targetPlatform = TP_Win32;  targetModel = TM_Gui;  targetStdLibs = (TargetStdLibs)0;  PolyString type(info->GetNodeType());  if (strcmp(type->GetCstr(), ".exe") == 0 || strcmp(type->GetCstr(), "AppExpert") == 0)    targetType = TT_Application;  else if (strcmp(type->GetCstr(), ".dll") == 0 || strcmp(type->GetCstr(), "AppExpertDll") == 0)    targetType = TT_Dll;  else if (strcmp(type->GetCstr(), ".lib") == 0)    targetType = TT_StaticLib;  else if (strcmp(type->GetCstr(), ".hlp") == 0)    targetType == TT_WinHelp;  ProjectNode node = info->GetFirstChild();  char buf[80];  while (node) {    ProjectNodeInfo info2(projectServer->QueryNodeInfo(node));    if (info2) {      if (projectServer->NodeHasFlags(node, PNF_Runtime)) {        PolyString name(info2->GetName());        strcpy(buf, name->GetCstr());        PolyString type(info2->GetNodeType());        char *p = strstr(buf, type->GetCstr());        if (p)          *p = '\0';        if (strcmp(type->GetCstr(), ".obj") == 0)          GetTargetOptionsObj(buf);        else if (strcmp(type->GetCstr(), ".lib") == 0)          GetTargetOptionsLib(buf);      }      node = info2->GetNextSibling();    }    else      node = 0;  }}
void TargetData::GetTargetOptionsObj(const char *target)
{
  // Checking for c0? startup modules

  if (target[0] != 'c' && target[1] != '0')
    return;

  if (target[3] == '3' && target[4] == '2') {
    targetPlatform = TP_Win32;

    switch (target[2]) {
      case 'w': targetType = TT_Application; targetModel = TM_Gui; break;
      case 'd': targetType = TT_Dll; targetModel = TM_Gui; break;
      case 'x': targetType = TT_Application; targetModel = TM_WinConsole; break;
    }

    return;
  }

  if (target[2] == 'w' || target[2] == 'd') {
    targetPlatform = TP_Win16;

    if (target[2] == 'w')
      targetType = TT_Application;
    else
      targetType = TT_Dll;

    switch (target[3]) {
      case 'l': targetModel = TM_Large; break;
      case 'c': targetModel = TM_Compact; break;
      case 'm': targetModel = TM_Medium; break;
      case 's': targetModel = TM_Small; break;
    }

    return;
  }

  targetType = TT_Application;
  targetPlatform = TP_Dos16;
  switch (target[2]) {
    case 'h': targetModel = TM_Huge; break;
    case 'l': targetModel = TM_Large; break;
    case 'c': targetModel = TM_Compact; break;
    case 'm': targetModel = TM_Medium; break;
    case 's': targetModel = TM_Small; break;
    case 't': targetModel = TM_Tiny; break;
  }
}

void TargetData::ExamineSuffix(const char *suffix)
{
	if (strchr(suffix, 'd') != 0)
  	SetStdLib(TL_Diagnostic);

  if (strchr(suffix, 't') != 0)
  	SetStdLib(TL_Multithread);

  if (strchr(suffix, 'i') != 0)
  	SetStdLib(TL_Dynamic);
  else
  	SetStdLib(TL_Static);
}

bool TargetData::BeginsWith(const char *str, const char *test)
{
  int i;

  for (i = 0; str[i] != '\0' && test[i] != '\0'; i++)
    if (str[i] != test[i])
      return false;

  return test[i] == '\0';
}

void TargetData::GetTargetOptionsLib(const char *target)
{
  if (BeginsWith(target, "cw32")) {
  	SetStdLib(TL_Rtl);

    const char *suffix = target + 4;    ExamineSuffix(suffix);    return;  }  if (BeginsWith(target, "cw")) {  	SetStdLib(TL_Rtl);  	SetStdLib(TL_Static);    return;  }  if (BeginsWith(target, "crtldll")) {  	SetStdLib(TL_Rtl);  	SetStdLib(TL_Dynamic);    return;  }  if (BeginsWith(target, "bids")) {  	SetStdLib(TL_Bids);    const char *suffix = target + 4;    ExamineSuffix(suffix);    return;  }  if (BeginsWith(target, "owl")) {  	SetStdLib(TL_Owl);    const char *suffix = target + 3;    ExamineSuffix(suffix);    return;  }  if (BeginsWith(target, "ocf")) {  	SetStdLib(TL_Ocf);    const char *suffix = target + 3;    ExamineSuffix(suffix);    return;  }  if (strcmp(target, "cg32") == 0 || strcmp(target, "cg16") == 0)  	SetStdLib(TL_Codeguard);}

