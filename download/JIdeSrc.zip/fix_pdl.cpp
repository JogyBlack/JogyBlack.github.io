#include "all.h"
#pragma hdrstop

#include "fix_pdl.h"

const int LINE_LEN = 255;

bool FixPdl(const char *projectname, bool transferTools)
{
	char source[MAX_PATH];
	char dest[MAX_PATH];
  char line[LINE_LEN + 1];

	strcpy(source, projectname);
  strcpy(dest, projectname);

  strcat(source, ".pd0");
  strcat(dest, ".pdl");

  ifstream ifs(source);
  ofstream ofs(dest);

  if (!ifs || !ofs)
    return false;

  while (ifs) {
  	ifs.getline(line, LINE_LEN);

    if (!transferTools && strcmp(line, "{ SubSystem = Tool") == 0)
    	break;

    if (strcmp(line, "    { CmdLine = \"$IMPLIB\" }") == 0)
    	ofs << "    { Path = \"implib.exe\" }" << endl;

    if (strcmp(line, "    { ToolFlag =  }") != 0)
    	ofs << line << endl;
  }

  return true;
}
