#ifndef ALL_H__  	// Sentry
#define ALL_H__

#include <windows.h>
#include <fstream.h>
#include <cstring.h>

#include <ideaddon\itool.h>
#include <ideaddon\iproj.h>
#include <ideaddon\itarg.h>
#include <ideaddon\ioption.h>
#include <ideaddon\iidewin.h>
#include <ideaddon\iideui.h>
#include <ideaddon\iscript.h>
#include <ideaddon\imsgsys.h>
#include <ideaddon\comhelp.h>
#include <ideaddon\imake.h>

#endif  	// Sentry

