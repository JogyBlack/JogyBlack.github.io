#ifndef OUTPATH_H__  	// Sentry
#define OUTPATH_H__

class OutputPathsMakeClient : public IMakeClient
{
	private:
	  ULONG refCount;

    void Recurse(ProjectNode node, ProjectServer &projectServer,
                 OptionSetServer &optionSetServer);
    bool MakePath(const char *path);
    bool CreatePath(const char *path);

 	public:
    OutputPathsMakeClient() : refCount( 1 ) {}

    // IUnknown members
    STDMETHODIMP QueryInterface (THIS_ REFIID, LPVOID FAR *) { return ResultFromScode(E_NOINTERFACE); }
    STDMETHODIMP_(ULONG) AddRef  (THIS) { return refCount++; }
    STDMETHODIMP_(ULONG) Release (THIS) { return --refCount == 0 ? (delete this, 0) : refCount; }

    void MakeBeginNotify();
    void MakeEndNotify() {}
};

#endif  	// Sentry

