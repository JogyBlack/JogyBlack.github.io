#include "all.h"
#pragma hdrstop

#include "repl_dlg.h"

#include "repl_dlg.rh"

extern HINSTANCE ghInst;

static ReplaceData *data;

static BOOL CALLBACK DlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM /*lParam*/)
{
  switch (message)
  {
    case WM_COMMAND:
      switch (LOWORD(wParam))
      {
        case IDOK:
          if (!GetDlgItemText(hDlg, IDC_FIND, data->find, data->find_len))
            data->find[0] = '\0';
          if (!GetDlgItemText(hDlg, IDC_REPLACE, data->repl, data->repl_len))
            data->repl[0] = '\0';

//          data->recurse = IsDlgButtonChecked(hDlg, IDC_RECURSE);

        case IDCANCEL:
            EndDialog(hDlg, wParam);
            return TRUE;
      }
  }
  return FALSE;
}

int ReplaceDialog(HWND hParent, ReplaceData *_data)
{
	data = _data;
  return DialogBox(ghInst, MAKEINTRESOURCE(IDD_SEARCH_REPLACE), hParent, (DLGPROC)DlgProc);}


