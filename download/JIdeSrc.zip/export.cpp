#include "all.h"
#pragma hdrstop

#include "helper.h"
#include "export.h"
#include "targdata.h"

ProjectExporter::ProjectExporter(ostream &_os,
                                 MessageFolder &_messageFolder,
                                 ProjectServer &_projectServer,                                 TargetServer &_targetServer,                                 OptionSetServer &_optionSetServer): os(_os), messageFolder(_messageFolder), projectServer(_projectServer),  targetServer(_targetServer), optionSetServer(_optionSetServer), isAppExpert(false){  buf = new char[1024];}
ProjectExporter::~ProjectExporter()
{
  delete [] buf;
}
bool ProjectExporter::GetOption(char *option, ProjectNode node,
                                OptionsStringIds oid, bool canBeOverriden)
{
  PolyString strOption(optionSetServer->OptionGet(node, oid));

  if (!strOption)    return false;  strcpy(option, strOption->GetCstr());  if (!canBeOverriden)    return true;  bool result = false;  optionSetServer->OptionRemove(node, oid);  PolyString strOption2(optionSetServer->OptionGet(node, oid));  if (strOption2)  {    if (strcmp(option, strOption2->GetCstr()) != 0)  // Option was overriden    {      // restore the option      optionSetServer->OptionApply(node, oid, MakePolyString(option));      result = true;    }  }  return result;}

void ProjectExporter::WriteOptions(ProjectNode node, bool canBeOverriden,
                                   HMSGITEM hMsgItem)
{
  os << "{ Options" << endl;

  if (GetOption(buf, node, OID_Include, canBeOverriden))    WriteSetting("Include", buf, hMsgItem);

  if (GetOption(buf, node, OID_Library, canBeOverriden))
    WriteSetting("Library", buf, hMsgItem);

  if (GetOption(buf, node, OID_Source, canBeOverriden))
    WriteSetting("Source", buf, hMsgItem);

  if (GetOption(buf, node, OID_Intermediate, canBeOverriden))
    WriteSetting("Intermediate", buf, hMsgItem);

  if (GetOption(buf, node, OID_Final, canBeOverriden))
    WriteSetting("Final", buf, hMsgItem);

  if (GetOption(buf, node, OID_Defines, canBeOverriden))
    WriteSetting("Defines", buf, hMsgItem);

  if (GetOption(buf, node, OID_CmdlineOverride, canBeOverriden))
    WriteSetting("CmdLineOverride", buf, hMsgItem);

  os << "}" << endl;
}

bool ProjectExporter::IsUserNode(ProjectNodeInfo &info, ProjectNode node)
{
  if (projectServer->NodeHasFlags(node, PNF_UserGen))    return true;  if (!projectServer->NodeHasFlags(node, PNF_Runtime))  {    PolyString type(info->GetNodeType());    if (!type)      return false;    if (strcmp(type->GetCstr(), "AppExpert") == 0 ||        strcmp(type->GetCstr(), "AppExpertDll") == 0)    {			isAppExpert = true;
      return true;
    }    return strcmp(type->GetCstr(), ".cpp") == 0 ||           strcmp(type->GetCstr(), ".rc") == 0 ||           strcmp(type->GetCstr(), ".def") == 0;  }  else    return false;}

void ProjectExporter::WriteChildren(ProjectNode node, int level, bool exportSiblings)
{
  ProjectNodeInfo info(projectServer->QueryNodeInfo(node));

  if (info)
  {
    if (IsUserNode(info, node))
    {
      os << "{ ";

      PolyString name(info->GetName());

      bool isTarget = targetServer->NodeIsTarget(node);

      ProjectNode child = info->GetFirstChild();
			if (libTypes.convertNodelessTarget && !child)
      	isTarget = false;		// Target nodes must have children?

      if (isTarget)
        strcpy(buf, "Target");
      else
        strcpy(buf, "Node");

      os << buf << " = " << name->GetCstr();
/*
      if (strchr(name->GetCstr(), '.') == 0)
      {
        PolyString type(info->GetNodeType());
        os << type->GetCstr();
      }
*/
      os << endl;

      strcat(buf, " ");
      strcat(buf, name->GetCstr());

//      HMSGITEM hMsgItem = messageFolder->NewFileMessage(NULL, MakePolyString(buf));
      HMSGITEM hMsgItem = 0;

      WriteSetting("Level", level, hMsgItem);

      if (isTarget)
      {
        TargetData targetData(projectServer, info);

        if (libTypes.libDiag == LibTypes::SET)
        	targetData.SetStdLib(TL_Diagnostic);
        else if (libTypes.libDiag == LibTypes::CLEAR)
        	targetData.ClearStdLib(TL_Diagnostic);

        if (libTypes.libMT == LibTypes::SET)
        	targetData.SetStdLib(TL_Multithread);
        else if (libTypes.libMT == LibTypes::CLEAR)
        	targetData.ClearStdLib(TL_Multithread);

        if (libTypes.libStatic == LibTypes::SET)
        {
        	targetData.SetStdLib(TL_Static);
        	targetData.ClearStdLib(TL_Dynamic);
        }
        else if (libTypes.libStatic == LibTypes::CLEAR)
        {
        	targetData.ClearStdLib(TL_Static);
        	targetData.SetStdLib(TL_Dynamic);
        }

        if (libTypes.libCG == LibTypes::SET)
        	targetData.SetStdLib(TL_Codeguard);
        else if (libTypes.libCG == LibTypes::CLEAR)
        	targetData.ClearStdLib(TL_Codeguard);

        WriteSetting("Type", targetData.GetType(), hMsgItem);
        WriteSetting("Platform", targetData.GetPlatform(), hMsgItem);
        WriteSetting("Model", targetData.GetModel(), hMsgItem);
        WriteSetting("StdLibs", targetData.GetStdLibs(), hMsgItem);
      }
      else
      {
        PolyString type(info->GetNodeType());
        if (type)
          WriteSetting("Type", type->GetCstr(), hMsgItem);
      }

      PolyString desc(info->GetDescription());
      if (desc)
        WriteSetting("Description", desc->GetCstr(), hMsgItem);

      os << "}" << endl;

      WriteFlags(node, hMsgItem);

      if (libTypes.clearOverrides)
			  os << "{ Options" << endl
			     << "}" << endl;
      else
	      WriteOptions(node, level > 1, hMsgItem);

      if (child)
        WriteChildren(child, level + 1);
    }

    if (exportSiblings)
    {
      ProjectNode next = info->GetNextSibling();
      if (next)
        WriteChildren(next, level);
    }
  }
}

void ProjectExporter::WriteFlags(ProjectNode node, HMSGITEM hMsgItem)
{
  os << "{ Flags" << endl;

  if (projectServer->NodeHasFlags(node, PNF_BuildDepends))    WriteSetting("Build", "Depends", hMsgItem);  if (projectServer->NodeHasFlags(node, PNF_BuildAlways))
    WriteSetting("Build", "Always", hMsgItem);
  if (projectServer->NodeHasFlags(node, PNF_BuildNever))
    WriteSetting("Build", "Never", hMsgItem);

  if (projectServer->NodeHasFlags(node, PNF_Exclude))
    WriteSetting("Exclude", "true", hMsgItem);

//  if (projectServer->NodeHasFlags(node, PNF_UserGen))
    WriteSetting("UserGen", "true", hMsgItem);

  os << "}" << endl;
}

void ProjectExporter::WriteSetting(const char *name, const char *value,
                                   HMSGITEM hMsgItem)
{
  if (!name || !value || !name[0] || !value[0])
    return;

  char *temp = new char[strlen(value) + 1];
  strcpy(temp, value);

  for (int index = 0; temp[index] != '\0'; index++)
  {
    if (temp[index] == '\n' || temp[index] == '\r')
      temp[index] = ' ';
  }

  os << "  { " << name << " = " << temp << " }" << endl;

  delete [] temp;

  if (hMsgItem)
  {
    char *temp = new char[strlen(name) + strlen(value) + 10];

    wsprintf(temp, "%s = %s", name, value);

    messageFolder->NewMessage(hMsgItem, MakePolyString(temp));

    delete [] temp;
  }
}
void ProjectExporter::WriteSetting(const char *name, int value,                                   HMSGITEM hMsgItem){  if (!name || !name[0])    return;

  os << "  { " << name << " = " << value << " }" << endl;
  if (hMsgItem)  {    char *temp = new char[strlen(name) + 10];

    wsprintf(temp, "%s = %d", name, value);

    messageFolder->NewMessage(hMsgItem, MakePolyString(temp));

    delete [] temp;
  }
}

