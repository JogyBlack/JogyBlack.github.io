#include <windows.h>

int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{

  int result = MessageBox(0, "Set options SaveAsText and ReadAsText in bcw5.ini?\n(Needed for transferring the style sheets.)", "JIdeTool", MB_YESNO | MB_ICONQUESTION);

  if (result == IDYES) {
    WritePrivateProfileString("Project", "SaveAsText", "1", "bcw5.ini");
    WritePrivateProfileString("Project", "ReadAsText", "1", "bcw5.ini");
  }

  return 0;
}
