#include "all.h"
#pragma hdrstop

#include "toolbase.h"

ToolBase::ToolBase()
: IUNKNOWNIMPL_INIT(IToolImplementor)
{
}
const char *ToolBase::GetPath() const
{
	return "[JIdeTool]";}
