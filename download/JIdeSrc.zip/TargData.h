#ifndef TARGDATA_H__  	// Sentry
#define TARGDATA_H__

#include "helper.h"

class TargetData
{
	public:
  	TargetData(ProjectServer &projectServer, ProjectNodeInfo &info);

    TargetType GetType() const { return targetType; }
    TargetPlatform GetPlatform() const { return targetPlatform; }
    TargetModel GetModel() const { return targetModel; }
    TargetStdLibs GetStdLibs() const { return targetStdLibs; }

    bool IsApplication() const { return targetType == TT_Application; }
    bool IsDll() const { return targetType == TT_Dll; }

    bool Is32bit() const { return targetPlatform == TP_Win32; }

    bool IsOwl() const { return targetStdLibs & TL_Owl; }
    bool IsBids() const { return targetStdLibs & TL_Bids; }
    bool IsRtl() const { return targetStdLibs & TL_Rtl; }
    bool IsStatic() const { return targetStdLibs & TL_Static; }
    bool IsDynamic() const { return targetStdLibs & TL_Dynamic; }
    bool IsOle2() const { return targetStdLibs & TL_Ole2; }
    bool IsOcf() const { return targetStdLibs & TL_Ocf; }
    bool IsCG() const { return targetStdLibs & TL_Codeguard; }
    bool IsDiag() const { return targetStdLibs & TL_Diagnostic; }
    bool IsMT() const { return targetStdLibs & TL_Multithread; }

    void SetStdLib(TargetStdLibs lib) { targetStdLibs = (TargetStdLibs)(targetStdLibs | lib); }
    void ClearStdLib(TargetStdLibs lib) { targetStdLibs = (TargetStdLibs)(targetStdLibs & ~lib); }

  private:
		void GetTargetOptionsObj(const char *target);
    void GetTargetOptionsLib(const char *target);
    void ExamineSuffix(const char *suffix);
    bool BeginsWith(const char *str, const char *test);

    TargetType targetType;
    TargetPlatform targetPlatform;
    TargetModel targetModel;
    TargetStdLibs targetStdLibs;
};

#endif  	// Sentry

