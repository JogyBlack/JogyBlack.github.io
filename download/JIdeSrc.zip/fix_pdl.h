#ifndef FIX_PDL_H__  	// Sentry
#define FIX_PDL_H__

extern bool FixPdl(const char *projectname, bool transferTools);

#endif  	// Sentry

