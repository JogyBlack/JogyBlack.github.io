#include "all.h"
#pragma hdrstop

#include "helper.h"
#include "tools.h"
#include "toolbase.h"
#include "rebuild.h"
#include "sort.h"
#include "repl.h"
#include "gen_txt.h"
#include "outpath.h"

const int maxToolCount = 16;

JIdeTool::JIdeTool()
{
  toolCount = 0;
  toolArray = new PToolBase[maxToolCount];
  toolArray[toolCount++] = new ProjectRebuildTool;
  toolArray[toolCount++] = new ProjectRestoreTool;
  toolArray[toolCount++] = new TargetsSettingsTool;
  toolArray[toolCount++] = new GenTxtTool;
  toolArray[toolCount++] = new ExportBranchTool;
  toolArray[toolCount++] = new ImportBranchTool;
  toolArray[toolCount++] = new ExportProjectTool;
  toolArray[toolCount++] = new ImportProjectTool;
  toolArray[toolCount++] = new NodeSortTool;
  toolArray[toolCount++] = new NodeReplaceTool;

  projectClient = new ProjectClient;

  projectClient->RegisterJIdeTool(this);
  toolServer = GET_INTERFACE(IToolServer);
  projectServer = GET_INTERFACE(IProjectServer);

  if (projectServer)
  {
    projectClient->AddRef();
    projectServer->RegisterProjectClient(projectClient);
    IProjectServer2 *ps2 = GET_INTERFACE(IProjectServer2);
    if (ps2)   // this interface not available on BCW versions < 5.01
    {
      projectClient->AddRef();
      ps2->RegisterProjectSaveClient(projectClient);
      ps2->Release();
    }
  }

  if (LoadOption("Enable Automatic Path Creation", true))
  {
    makeClient = new OutputPathsMakeClient;

    MakeServer makeServer;
    makeServer->RegisterMakeClient(makeClient);
  }
  else
  	makeClient = 0;

}

JIdeTool::~JIdeTool()
{
  IProjectServer2 *ps2 = GET_INTERFACE(IProjectServer2);
  if (ps2)   // this interface not available on BCW versions < 5.01
  {
    projectClient->AddRef();
    ps2->UnregisterProjectSaveClient(projectClient);
    ps2->Release();
  }
  projectClient->AddRef();
  projectServer->UnregisterProjectClient(projectClient);
  projectClient->Release();
  projectClient = 0;

  for (int index = 0; index < toolCount; index++)
    toolArray[index]->Release();

  delete [] toolArray;

  if (projectServer)
    projectServer->Release();

//  MakeServer makeServer;
//  makeServer->UnRegisterMakeClient(makeClient);

	delete makeClient;
}

void JIdeTool::RegisterTools()
{
  if (!toolServer)    return;

	ScriptServer scriptServer;  PolyString result(CreatePolyString());
  scriptServer->RunScriptCommand(MakePolyString("return IDE.Version;"), result.Get());
	ver = atoi(result->GetCstr());

  for (int index = 0; index < toolCount; index++)  {    IToolInfo *toolInfo;    ToolObj tool;

    tool = toolServer->ToolFind(MakePolyString(toolArray[index]->GetName()));
    if (tool)
      toolServer->ToolRemove(tool);

		if (toolArray[index]->RequiredVersion() > ver)
    	continue;

	  if (!LoadOption(toolArray[index]->GetRegKeyName(), true))
    	continue;

    toolInfo = toolServer->CreateToolInfoInstance();
    if (!toolInfo)
      return;

    toolInfo->SetTypes(toolArray[index]->GetTypes());
    toolInfo->SetName(MakePolyString(toolArray[index]->GetName()));
    toolInfo->SetPath(MakePolyString(toolArray[index]->GetPath()));
    toolInfo->SetFlags(toolArray[index]->GetFlags());
    toolInfo->SetMenuName(MakePolyString(toolArray[index]->GetMenuName()));
    toolInfo->SetHelpHint(MakePolyString(toolArray[index]->GetHelpHint()));
    toolInfo->SetDefCmdLine(MakePolyString(toolArray[index]->GetDefCmdLine()));
    toolInfo->SetSupportedTypes(MakePolyString(toolArray[index]->GetSupportedTypes()));
    toolInfo->SetDefaultForTypes(MakePolyString(toolArray[index]->GetDefaultForTypes()));
    toolInfo->SetTranslateTo(MakePolyString(toolArray[index]->GetTranslateTo()));

    toolArray[index]->AddRef();
    toolInfo->SetImplementor(toolArray[index]);

    toolServer->ToolAdd(toolInfo);
  }

}

void JIdeTool::UnregisterTools()
{
  if (!toolServer)
    return;

  for (int index = 0; index < toolCount; index++)
  {
    IPolyString *toolName = MakePolyString(toolArray[index]->GetName());
    ToolObj tool = toolServer->ToolFind(toolName);
    if (tool)
      toolServer->ToolRemove(tool);
  }
}

////////////////////////////////////////////////////////////////////////////////

void ProjectClient::OpenNotify(IPolyString *projectName)
{
  if (jIdeTool)
    jIdeTool->RegisterTools();

  projectName->Release();
}

void ProjectClient::CloseNotify() {}

void ProjectClient::BeforeSaveNotify()
{
  //
  // Yank the add-on tool before the project is saved, so it will not
  // appear in the project if it is loaded when this add-on isn't installed.
  //
  if (jIdeTool)
    jIdeTool->UnregisterTools();
}

void ProjectClient::AfterSaveNotify()
{
  //
  // Now that the project has been saved, we must re-install the add-on tool.
  //
  if (jIdeTool)
    jIdeTool->RegisterTools();
}


