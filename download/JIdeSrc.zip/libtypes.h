#ifndef __LIBTYPES_H__  	// Sentry
#define __LIBTYPES_H__

struct LibTypes
{
	enum LibType { SAME, SET, CLEAR };

  LibTypes() : libStatic(SAME), libMT(SAME), libCG(SAME), libDiag(SAME),
               transferStyleSheets(true), transferTools(false),
               convertNodelessTarget(true), clearOverrides(true),
               styleSheetNo(-1) {}

  LibType libStatic;
  LibType libMT;  LibType libCG;  LibType libDiag;

  bool transferStyleSheets;
  bool transferTools;

  bool convertNodelessTarget;
  bool clearOverrides;

  int styleSheetNo;
};


#endif  	// Sentry

