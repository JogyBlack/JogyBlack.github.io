#include "all.h"
#pragma hdrstop

#include "helper.h"
#include "outpath.h"

void OutputPathsMakeClient::MakeBeginNotify()
{
	ProjectServer projectServer;
  OptionSetServer optionSetServer;
  ProjectNode topNode = projectServer->QueryTopNode();

	Recurse(topNode, projectServer, optionSetServer);
}

void OutputPathsMakeClient::Recurse(ProjectNode node,
                                    ProjectServer &projectServer,
                                    OptionSetServer &optionSetServer)
{
  ProjectNodeInfo info(projectServer->QueryNodeInfo(node));
  if (info && !projectServer->NodeHasFlags(node, PNF_BuildNever) &&
      !projectServer->NodeHasFlags(node, PNF_Exclude))
  {
    PolyString intermediate(optionSetServer->OptionGet(node, OID_Intermediate));
    if (intermediate)
    	MakePath(intermediate->GetCstr());
    PolyString final(optionSetServer->OptionGet(node, OID_Final));
    if (final)
    	MakePath(final->GetCstr());
  }

  if (info)
  {
    ProjectNode child = info->GetFirstChild();
    if (child)
      Recurse(child, projectServer, optionSetServer);

    ProjectNode next = info->GetNextSibling();
    if (next)
      Recurse(next, projectServer, optionSetServer);
  }
}

bool OutputPathsMakeClient::MakePath(const char *path)
{
	char temp[_MAX_PATH];
  if (GetCurrentDirectory(_MAX_PATH, temp) == 0)
  	return false;

	bool result = true;

	if (SetCurrentDirectory(path) == FALSE)
  {
  	char buf[_MAX_PATH];
    strcpy(buf, path);
    char *p = strchr(buf, '\\');
    while (p)
    {
      *p = '\0';
      if (SetCurrentDirectory(buf) == FALSE)
	      if (!CreatePath(buf))
        {
        	result = false;
          break;
        }
			*p = '\\';
      p = strchr(p + 1, '\\');
    }

    if (!CreatePath(buf))
    	result = false;
  }

  SetCurrentDirectory(temp);

  return result;
}

bool OutputPathsMakeClient::CreatePath(const char *path)
{
  MessageSystem messageSystem;
  MessageFolder messageFolder = messageSystem->NewFolder(MakePolyString("AddOn"), MakePolyString("JIde"));

	bool result;

  char msg[_MAX_PATH];
  if (CreateDirectory(path, 0) == TRUE)
  {
	  strcpy(msg, "Creating folder ");
    result = true;
  }
  else
  {
	  strcpy(msg, "Error creating folder ");
    result = true;
  }
  
  strcat(msg, path);
  messageFolder->NewMessage(NULL, MakePolyString(msg));
  return result;
}

