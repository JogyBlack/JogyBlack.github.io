/*------------------------------------------------------------------------------
Header: repl.h
Description:
Note:
Author: Jogy
Date created: 21 March 2000
Date last modified: 21 March 2000
------------------------------------------------------------------------------*/

#ifndef __repl_h__  	// Sentry
#define __repl_h__

#include "toolbase.h"

class ProjectServer3;
class ProjectNodeInfo;

class NodeReplaceTool : public ToolBase
{
  public:
    NodeReplaceTool();

    virtual ToolTypes GetTypes() const { return TT_Viewer; }
    virtual const char *GetName() const;    virtual unsigned GetFlags() const { return TIFlag_OnLocalMenu; }    virtual const char *GetMenuName() const;    virtual const char *GetHelpHint() const;    virtual const char *GetSupportedTypes() const;
    virtual int RequiredVersion() const { return 502; }
    virtual const char *GetRegKeyName() const;

    virtual ToolReturn Execute(IPolyString *cmdLine,
                               ProjectNode *nodeArray,
                               int numNodes);

  private:
    bool ReplaceNodes(ProjectNode node, ProjectServer3 &projectServer,
                      const char *find, const char *repl, bool recurse);
};

#endif  	// Sentry

