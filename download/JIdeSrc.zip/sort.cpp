#include "all.h"
#pragma hdrstop

#include "sort.h"
#include "helper.h"

NodeSortTool::NodeSortTool()
{
}

const char *NodeSortTool::GetName() const
{
  return "NodeSort";}

const char *NodeSortTool::GetMenuName() const{  return "Sort &Nodes";}const char *NodeSortTool::GetHelpHint() const{  return "Sort subnodes in alphabetical order";}const char *NodeSortTool::GetSupportedTypes() const{	return ".dll;.exe;.lib;SourcePool;AppExpert;AppExpertDll";}
const char *NodeSortTool::GetRegKeyName() const
{
	return "Enable Node Sort";
}

ToolReturn NodeSortTool::Execute(IPolyString * cmdLine,
                                  ProjectNode *nodeArray,
                                  int numNodes)
{
  if (cmdLine)
    cmdLine->Release();

  try
  {
    SetWaitCursor(true);

    // Set up servers
    ProjectServer3 projectServer;

    for (int index = 0; index < numNodes; index++)
      SortNodes(nodeArray[index], projectServer);

    SetWaitCursor(false);

    return TR_Success;
  }
  catch (const char *msg)
  {
    SetWaitCursor(false);

    ShowMessageBox(msg, ErrorMBox);

    return TR_FatalError;
  }
}

bool NodeSortTool::SortNodes(ProjectNode node, ProjectServer3 &projectServer)
{
  ProjectNodeInfo info(projectServer->QueryNodeInfo(node));  bool done;  do  {    done = true;    ProjectNode child = info->GetFirstChild();    while (child)    {      if (NodeSwapped(child, projectServer))        done = false;;    }  } while (!done);  return true;}
bool NodeSortTool::NodeSwapped(ProjectNode &node, ProjectServer3 &projectServer)
{
  ProjectNodeInfo info(projectServer->QueryNodeInfo(node));  ProjectNode nodeNext = info->GetNextSibling();  if (nodeNext)  {    ProjectNodeInfo infoNext(projectServer->QueryNodeInfo(nodeNext));    if (CompareNodes(info, infoNext) > 0)    {      if (projectServer->NodeIsValidMove(nodeNext, node, PNP_BeforeSibling))      {        projectServer->NodeMove(nodeNext, node, PNP_BeforeSibling);        return true;      }    }  }  node = nodeNext;  return false;}int NodeSortTool::CompareNodes(ProjectNodeInfo &info1, ProjectNodeInfo &info2){  PolyString type1(info1->GetNodeType());  PolyString type2(info2->GetNodeType());  int result = strcmp(type1->GetCstr(), type2->GetCstr());  if (result == 0)  {    PolyString name1(info1->GetName());    PolyString name2(info2->GetName());    result = strcmp(name1->GetCstr(), name2->GetCstr());  }  return result;}