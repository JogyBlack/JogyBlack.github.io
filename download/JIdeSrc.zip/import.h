/*------------------------------------------------------------------------------
Header: import.h
Description: 
Note: 
Author: Jogy
Date created: 22 March 2000
Date last modified: 22 March 2000
------------------------------------------------------------------------------*/

#ifndef __import_h__  	// Sentry
#define __import_h__

struct Version;

class NodeOptions;
class NodeInfo;

class ProjectImporter
{
  public:
    ProjectImporter(istream &_is,                    MessageFolder &_messageFolder,                    ProjectServer &_projectServer,                    TargetServer &_targetServer,                    OptionSetServer &_optionSetServer);    ~ProjectImporter();    void ReadProject(bool _loadTargets = true);    void ReadProject(ProjectNode node);  private:    bool ReadLine(char *line, int len);    char *ReadValue(char *line);    bool ReadVersion(Version &ver);    bool ReadProjectName(char *name);    int ReadNodeCount();    bool ReadOptions(NodeOptions &options, HMSGITEM hMsgItem);    bool ReadFlags(ProjectNodeFlags &flags, HMSGITEM hMsgItem);    bool ReadNode(NodeInfo &nodeInfo);    void SetOptions(ProjectNode node, NodeOptions &options);    void SetOption(ProjectNode node, const char *option, OptionsStringIds oid);
    ProjectNode FindNode(ProjectNode parent, const char *name, const char *type);    ProjectNode FindTarget(ProjectNode parent, const char *name);    istream &is;    char *buf;    MessageFolder &messageFolder;    ProjectServer &projectServer;    TargetServer &targetServer;    OptionSetServer &optionSetServer;    bool loadTargets;};
#endif  	// Sentry

