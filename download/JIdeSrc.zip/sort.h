/*------------------------------------------------------------------------------
Header: sort.h
Description:
Note:
Author: Jogy
Date created: 21 March 2000
Date last modified: 21 March 2000
------------------------------------------------------------------------------*/

#ifndef __sort_h__  	// Sentry
#define __sort_h__

#include "toolbase.h"

class ProjectServer3;
class ProjectNodeInfo;

class NodeSortTool : public ToolBase
{
  public:
    NodeSortTool();

    virtual ToolTypes GetTypes() const { return TT_Viewer; }
    virtual const char *GetName() const;    virtual unsigned GetFlags() const { return TIFlag_OnLocalMenu; }    virtual const char *GetMenuName() const;    virtual const char *GetHelpHint() const;    virtual const char *GetSupportedTypes() const;
    virtual int RequiredVersion() const { return 502; }
    virtual const char *GetRegKeyName() const;

    virtual ToolReturn Execute(IPolyString *cmdLine,
                               ProjectNode *nodeArray,
                               int numNodes);

  private:
    bool SortNodes(ProjectNode node, ProjectServer3 &projectServer);
    bool NodeSwapped(ProjectNode &node, ProjectServer3 &projectServer);
    int CompareNodes(ProjectNodeInfo &info1, ProjectNodeInfo &info2);
};

#endif  	// Sentry

