/*------------------------------------------------------------------------------
Header: tools.h
Description:
Note:
Author: Jogy
Date created: 17 March 2000
Date last modified: 17 March 2000
------------------------------------------------------------------------------*/

#ifndef __tools_h__  	// Sentry
#define __tools_h__

class ToolBase;

class JIdeTool;

////////////////////////////////////////////////////////////////////////////////
//
// This class inherits from two IUnknown decendents. The IUnknown methods
// are overridden by the comhelp IUnknownImp template class in the
// ProjectClient class below.
//
class projectClientCombo : public IProjectClient, public IProjectSaveClient {
};

class ProjectClient : public IUnknownImp<projectClientCombo>
{
  public:
    ProjectClient()
    : IUnknownImp<projectClientCombo>(IID_Addon_IProjectClient)
    { jIdeTool = 0; }

    virtual void OpenNotify(IPolyString * projectName);
    virtual void CloseNotify();
    virtual void NodeDeleteNotify(ProjectNode node) {}
    virtual void NodeAddNotify(ProjectNode node) {}
    virtual void NodeCopyNotify(ProjectNode, ProjectNode, BOOL) {}
    virtual void NodeMoveNotify(ProjectNode, ProjectNode) {}
    virtual void NodeChangeNotify(ProjectNode) {}
    virtual BOOL HandleAddNodeUI() { return FALSE; }
    virtual void DependencyQueryResponder(ProjectNode node, IPolyString *outputName)
    { outputName->Release(); }

    // IProjectSaveClient implementation
    virtual void BeforeSaveNotify();
    virtual void AfterSaveNotify();

    void RegisterJIdeTool(JIdeTool *_jIdeTool) { jIdeTool = _jIdeTool; }

  protected:
    JIdeTool *jIdeTool;
};

////////////////////////////////////////////////////////////////////////////////

class OutputPathsMakeClient;

class JIdeTool
{
  public:
    JIdeTool();
    virtual ~JIdeTool();

    void RegisterTools();
    void UnregisterTools();

  protected:
    IToolServer *toolServer;
    IProjectServer *projectServer;
    ProjectClient *projectClient;

    ToolBase **toolArray;
    int toolCount;

    int ver;

    OutputPathsMakeClient *makeClient;
};

#endif  	// Sentry

