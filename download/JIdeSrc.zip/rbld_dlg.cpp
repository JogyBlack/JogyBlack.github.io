#include "all.h"
#pragma hdrstop

#include <commctrl.h>

#include "helper.h"
#include "libtypes.h"

#include "rbld_dlg.rh"

extern HINSTANCE ghInst;

static LibTypes *libTypes;

const int BUFLEN = 80;

LibTypes::LibType LoadOption(const char *name, LibTypes::LibType defValue)
{
  char buf[BUFLEN];

  if (LoadOption(name, buf, BUFLEN))
	{
    if (stricmp(buf, "Same") == 0)
      return LibTypes::SAME;
    else if (stricmp(buf, "Set") == 0)
      return LibTypes::SET;
    else if (stricmp(buf, "Clear") == 0)
      return LibTypes::CLEAR;
  }

	return defValue;
}

void SaveOption(const char *name, LibTypes::LibType value)
{
  char buf[BUFLEN];

	switch (value)
  {
    case LibTypes::SAME:
	  	strcpy(buf, "Same");
      break;

    case LibTypes::SET:
	  	strcpy(buf, "Set");
      break;

    case LibTypes::CLEAR:
	  	strcpy(buf, "Clear");
      break;

		default:
      buf[0] = '\0';
      break;
  }

  SaveOption(name, buf, BUFLEN);
}


static LibTypes::LibType GetLibType(HWND hDlg, int nIdBtnSame, int nIdBtnSet, int nIdBtnClear)
{
  if (IsDlgButtonChecked(hDlg, nIdBtnSame))
    return LibTypes::SAME;
  else if (IsDlgButtonChecked(hDlg, nIdBtnSet))
    return LibTypes::SET;
  else if (IsDlgButtonChecked(hDlg, nIdBtnClear))
    return LibTypes::CLEAR;

  return LibTypes::SAME;
}

static void SetLibType(LibTypes::LibType type, HWND hDlg, int nIdBtnSame, int nIdBtnSet, int nIdBtnClear)
{
  switch (type)
  {
    case LibTypes::SAME:
      CheckRadioButton(hDlg, nIdBtnSame, nIdBtnClear, nIdBtnSame);
      break;

    case LibTypes::SET:
      CheckRadioButton(hDlg, nIdBtnSame, nIdBtnClear, nIdBtnSet);
      break;

    case LibTypes::CLEAR:
      CheckRadioButton(hDlg, nIdBtnSame, nIdBtnClear, nIdBtnClear);
      break;
  }
}

static BOOL CALLBACK DlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM /*lParam*/)
{
  switch (message)
  {
    case WM_INITDIALOG:
    	SetLibType(LoadOption("Static libraries", LibTypes::SAME), hDlg, IDC_STATICSAME, IDC_STATICSET, IDC_STATICCLEAR);
    	SetLibType(LoadOption("Multithread libraries", LibTypes::SAME), hDlg, IDC_MTSAME, IDC_MTSET, IDC_MTCLEAR);
    	SetLibType(LoadOption("Diagnostic libraries", LibTypes::SAME), hDlg, IDC_DIAGSAME, IDC_DIAGSET, IDC_DIAGCLEAR);
    	SetLibType(LoadOption("CodeGuard", LibTypes::SAME), hDlg, IDC_CGSAME, IDC_CGSET, IDC_CGCLEAR);

      if (LoadOption("Transfer style sheets", true))
      {
	      if (LoadOption("Transfer tools", false))
		      CheckRadioButton(hDlg, IDC_TRANSFERNONE, IDC_TRANSFERTOOLS, IDC_TRANSFERTOOLS);
        else
		      CheckRadioButton(hDlg, IDC_TRANSFERNONE, IDC_TRANSFERTOOLS, IDC_TRANSFERSTYLESHEETS);
      }
      else
	      CheckRadioButton(hDlg, IDC_TRANSFERNONE, IDC_TRANSFERTOOLS, IDC_TRANSFERNONE);

      CheckDlgButton(hDlg, IDC_CLEAROVERRIDES, LoadOption("Clear overrides", false) ? BST_CHECKED : BST_UNCHECKED);
      CheckDlgButton(hDlg, IDC_CONVNODELESSTARGETS, LoadOption("Convert childless targets", true) ? BST_CHECKED : BST_UNCHECKED);

    	return TRUE;

    case WM_COMMAND:
      switch (LOWORD(wParam))
      {
        case IDOK:
        	libTypes->libStatic = GetLibType(hDlg, IDC_STATICSAME, IDC_STATICSET, IDC_STATICCLEAR);
        	libTypes->libMT = GetLibType(hDlg, IDC_MTSAME, IDC_MTSET, IDC_MTCLEAR);
        	libTypes->libCG = GetLibType(hDlg, IDC_CGSAME, IDC_CGSET, IDC_CGCLEAR);
        	libTypes->libDiag = GetLibType(hDlg, IDC_DIAGSAME, IDC_DIAGSET, IDC_DIAGCLEAR);

          if (IsDlgButtonChecked(hDlg, IDC_TRANSFERNONE))
          {
            libTypes->transferStyleSheets = false;
            libTypes->transferTools = false;
          }
          if (IsDlgButtonChecked(hDlg, IDC_TRANSFERSTYLESHEETS))
          {
            libTypes->transferStyleSheets = true;
            libTypes->transferTools = false;
          }
          else if (IsDlgButtonChecked(hDlg, IDC_TRANSFERTOOLS))
          {
            libTypes->transferStyleSheets = true;
            libTypes->transferTools = true;
          }

          libTypes->clearOverrides = IsDlgButtonChecked(hDlg, IDC_CLEAROVERRIDES);
          libTypes->convertNodelessTarget = IsDlgButtonChecked(hDlg, IDC_CONVNODELESSTARGETS);

        	SaveOption("Static libraries", libTypes->libStatic);
        	SaveOption("Multithread libraries", libTypes->libMT);
        	SaveOption("Diagnostic libraries", libTypes->libDiag);
        	SaveOption("CodeGuard", libTypes->libCG);

					SaveOption("Clear overrides", libTypes->clearOverrides);
					SaveOption("Convert childless targets", libTypes->convertNodelessTarget);
          SaveOption("Transfer style sheets", libTypes->transferStyleSheets);
          SaveOption("Transfer tools", libTypes->transferTools);


        case IDCANCEL:
            EndDialog(hDlg, wParam);
            return TRUE;
      }
  }
  return FALSE;
}

int RebuildDialog(HWND hParent, LibTypes *_libTypes)
{
	libTypes = _libTypes;

  return DialogBox(ghInst, MAKEINTRESOURCE(IDD_REBUILD_OPTIONS), hParent, (DLGPROC)DlgProc);}

////////////////////////////////////////////////////////////////////////////////

static BOOL CALLBACK DlgProcTargets(HWND hDlg, UINT message, WPARAM wParam, LPARAM /*lParam*/)
{
  switch (message)
  {
    case WM_INITDIALOG:
      {
        SetLibType(LoadOption("Static libraries T", LibTypes::SAME), hDlg, IDC_STATICSAME, IDC_STATICSET, IDC_STATICCLEAR);
        SetLibType(LoadOption("Multithread libraries T", LibTypes::SAME), hDlg, IDC_MTSAME, IDC_MTSET, IDC_MTCLEAR);
        SetLibType(LoadOption("Diagnostic libraries T", LibTypes::SAME), hDlg, IDC_DIAGSAME, IDC_DIAGSET, IDC_DIAGCLEAR);
        SetLibType(LoadOption("CodeGuard T", LibTypes::SAME), hDlg, IDC_CGSAME, IDC_CGSET, IDC_CGCLEAR);

        CheckDlgButton(hDlg, IDC_CLEAROVERRIDES, LoadOption("Clear overrides T", false) ? BST_CHECKED : BST_UNCHECKED);

        int styleSheetNo = LoadOption("Style Sheet No T", -1);
        CheckDlgButton(hDlg, IDC_SETSTYLESHEET, styleSheetNo >= 0 ? BST_CHECKED : BST_UNCHECKED);

        SendDlgItemMessage(hDlg, IDC_UPDOWNSTYLESHEETNO, UDM_SETRANGE, 0, MAKELONG(100, 0));

				if (styleSheetNo >= 0)
	        SendDlgItemMessage(hDlg, IDC_UPDOWNSTYLESHEETNO, UDM_SETPOS, 0, MAKELONG(styleSheetNo, 0));
        else
        {
	        SendDlgItemMessage(hDlg, IDC_UPDOWNSTYLESHEETNO, UDM_SETPOS, 0, MAKELONG(0, 0));
					EnableWindow(GetDlgItem(hDlg, IDC_EDITSTYLESHEETNO), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_UPDOWNSTYLESHEETNO), FALSE);
        }

        return TRUE;
      }

    case WM_COMMAND:
      switch (LOWORD(wParam))
      {
        case IDOK:
        	libTypes->libStatic = GetLibType(hDlg, IDC_STATICSAME, IDC_STATICSET, IDC_STATICCLEAR);
        	libTypes->libMT = GetLibType(hDlg, IDC_MTSAME, IDC_MTSET, IDC_MTCLEAR);
        	libTypes->libCG = GetLibType(hDlg, IDC_CGSAME, IDC_CGSET, IDC_CGCLEAR);
        	libTypes->libDiag = GetLibType(hDlg, IDC_DIAGSAME, IDC_DIAGSET, IDC_DIAGCLEAR);

          libTypes->clearOverrides = IsDlgButtonChecked(hDlg, IDC_CLEAROVERRIDES);

					if (IsDlgButtonChecked(hDlg, IDC_SETSTYLESHEET))
          {
						char buf[20];
            SendDlgItemMessage(hDlg, IDC_EDITSTYLESHEETNO, WM_GETTEXT, 20, (LPARAM)buf);
          	libTypes->styleSheetNo = atoi(buf);
          }
          else
          	libTypes->styleSheetNo = -1;

        	SaveOption("Static libraries T", libTypes->libStatic);
        	SaveOption("Multithread libraries T", libTypes->libMT);
        	SaveOption("Diagnostic libraries T", libTypes->libDiag);
        	SaveOption("CodeGuard T", libTypes->libCG);

					SaveOption("Clear overrides T", libTypes->clearOverrides);
					SaveOption("Style Sheet No T", libTypes->styleSheetNo);

        case IDCANCEL:
            EndDialog(hDlg, wParam);
            return TRUE;

        case IDC_SETSTYLESHEET:
					if (IsDlgButtonChecked(hDlg, IDC_SETSTYLESHEET))
          {
            EnableWindow(GetDlgItem(hDlg, IDC_EDITSTYLESHEETNO), TRUE);
            EnableWindow(GetDlgItem(hDlg, IDC_UPDOWNSTYLESHEETNO), TRUE);
          }
          else
          {
            EnableWindow(GetDlgItem(hDlg, IDC_EDITSTYLESHEETNO), FALSE);
            EnableWindow(GetDlgItem(hDlg, IDC_UPDOWNSTYLESHEETNO), FALSE);
          }
          return TRUE;
      }
  }
  return FALSE;
}

int TargetsDialog(HWND hParent, LibTypes *_libTypes)
{
	libTypes = _libTypes;

  InitCommonControls();

  return DialogBox(ghInst, MAKEINTRESOURCE(IDD_TARGETS_OPTIONS), hParent, (DLGPROC)DlgProcTargets);
}


