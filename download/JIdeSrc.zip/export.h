/*------------------------------------------------------------------------------
Header: export.h
Description:
Note:
Author: Jogy
Date created: 22 March 2000
Date last modified: 22 March 2000
------------------------------------------------------------------------------*/

#ifndef __export_h__  	// Sentry
#define __export_h__

#include "libtypes.h"

class TargetInfo;

class ProjectExporter
{
  public:
    ProjectExporter(ostream &_os,
                    MessageFolder &_messageFolder,                    ProjectServer &_projectServer,                    TargetServer &_targetServer,                    OptionSetServer &_optionSetServer);    ~ProjectExporter();    void WriteChildren(ProjectNode node, int level, bool exportSiblings = true);    void WriteOptions(ProjectNode node, bool canBeOverriden,                      HMSGITEM hMsgItem);    void SetLibTypes(LibTypes _libTypes) { libTypes = _libTypes; }    bool IsAppExpert() const { return isAppExpert; }  private:    void WriteSetting(const char *name, const char *value, HMSGITEM hMsgItem);    void WriteSetting(const char *name, int value, HMSGITEM hMsgItem);    bool GetOption(char *option, ProjectNode node, OptionsStringIds oid,                   bool canBeOverriden);    void WriteFlags(ProjectNode node, HMSGITEM hMsgItem);    bool IsUserNode(ProjectNodeInfo &info, ProjectNode node);
    ostream &os;    char *buf;    MessageFolder &messageFolder;    ProjectServer &projectServer;    TargetServer &targetServer;    OptionSetServer &optionSetServer;    LibTypes libTypes;    bool isAppExpert;};
#endif  	// Sentry

