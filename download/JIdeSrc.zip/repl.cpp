#include "all.h"
#pragma hdrstop

#include "repl.h"
#include "repl_dlg.h"
#include "helper.h"

NodeReplaceTool::NodeReplaceTool()
{
}

const char *NodeReplaceTool::GetName() const
{
  return "NodeReplace";}

const char *NodeReplaceTool::GetMenuName() const{  return "Search and Replace Node Names";}const char *NodeReplaceTool::GetHelpHint() const{  return "Search and replace in node names";}const char *NodeReplaceTool::GetSupportedTypes() const{	return ".dll;.exe;.lib;SourcePool;AppExpert;AppExpertDll";}
const char *NodeReplaceTool::GetRegKeyName() const
{
	return "Enable Node Replace";
}

const int BUFLEN = 80;

ToolReturn NodeReplaceTool::Execute(IPolyString * cmdLine,
                                    ProjectNode *nodeArray,
                                    int numNodes)
{
  if (cmdLine)
    cmdLine->Release();

  try
  {
    char find[BUFLEN + 1];
    char repl[BUFLEN + 1];

    ReplaceData data(find, BUFLEN, repl, BUFLEN);

    IdeWindow ideWin;

    if (ReplaceDialog(ideWin->GetHwnd(), &data) != IDOK)
      return TR_Success;

    SetWaitCursor(true);

    // Set up servers
    ProjectServer3 projectServer;

    for (int index = 0; index < numNodes; index++)
      ReplaceNodes(nodeArray[index], projectServer, find, repl, data.recurse);

    SetWaitCursor(false);

    return TR_Success;
  }
  catch (const char *msg)
  {
    SetWaitCursor(false);

    ShowMessageBox(msg, ErrorMBox);

    return TR_FatalError;
  }
}

bool NodeReplaceTool::ReplaceNodes(ProjectNode node, ProjectServer3 &projectServer,
                                   const char *find, const char *repl, bool recurse)
{
  ProjectNodeInfo info(projectServer->QueryNodeInfo(node));  bool done;  do  {    done = true;    ProjectNode child = info->GetFirstChild();    while (child)    {      if (recurse)      	ReplaceNodes(child, projectServer, find, repl, recurse);      ProjectNodeInfo info2(projectServer->QueryNodeInfo(child));      ProjectNode next = info2->GetNextSibling();      if (projectServer->NodeHasFlags(child, PNF_UserGen))      {        PolyString name(info2->GetName());        PolyString type(info2->GetNodeType());        const char *orig_name = name->GetCstr();        const char *p = strstr(orig_name, find);        if (p)        {          int new_len = strlen(orig_name) + strlen(repl) + 1;          char *new_name = new char[new_len];          int offset = p - orig_name;          if (offset > 0)          {            strncpy(new_name, orig_name, offset);            new_name[offset] = '\0';          }          else            new_name[0] = '\0';          strcat(new_name, repl);          strcat(new_name, p + strlen(find));          projectServer->NodeRemove(child);          child = projectServer->NodeAdd(node, MakePolyString(new_name), MakePolyString(type->GetCstr()));          if (next && projectServer->NodeIsValidMove(child, next))            projectServer->NodeMove(child, next);          delete [] new_name;        }      }      child = next;    }  } while (!done);  return true;}

