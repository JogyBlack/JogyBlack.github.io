#include "all.h"
#pragma hdrstop

#include <windows.h>
#include <string.h>
#include <assert.h>

#include "tools.h"

extern HINSTANCE ghInst = NULL;

extern "C" void WINAPI __export BcwAddOnEntry(IIdeServer * pIdeServer)
{
  static JIdeTool *jIdeTool = 0;

  if (pIdeServer) {
    SetIdeServer(pIdeServer);

    jIdeTool = new JIdeTool;
  }
  else {
    ReleaseIdeServer();

    delete jIdeTool;
    jIdeTool = 0;
  }
}

extern "C" BOOL WINAPI __export DllEntryPoint(HINSTANCE hInst, DWORD fdwReason, LPVOID)
{
  static BOOL oleInit = FALSE;

  ghInst = hInst;

  switch (fdwReason) {
    case DLL_PROCESS_ATTACH:
      if (FAILED(OleInitialize(NULL)))
      	return FALSE;
      oleInit = TRUE;
      break;

    case DLL_PROCESS_DETACH:
      if (oleInit)
        OleUninitialize();
      break;
  }
  return TRUE;
}

