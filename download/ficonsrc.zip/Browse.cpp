#pragma hdrstop
#include <windows.h>
#include <shlobj.h>

// Callback for the BrowseForFolder, which purpose is to set the initial folder
int CALLBACK BrowseCallbackProc(HWND hwnd, UINT uMsg, LPARAM /*lParam*/, LPARAM lpData)
{
  switch (uMsg)
  {
    case BFFM_INITIALIZED:
      ::SendMessage(hwnd, BFFM_SETSELECTION, (WPARAM)TRUE, lpData);
      break;
  }

  return 0;
}


// The initial folder, and the result of the function are contained in buf
bool BrowseForFolder(HWND hWnd, char *buf, const char *title)
{
  CoInitialize(0);

  // Global pointer to the shell's IMalloc interface.
  LPMALLOC g_pMalloc;

  // Get the shell's allocator.
  if (!SUCCEEDED(SHGetMalloc(&g_pMalloc)))
  {
    CoUninitialize();
    return false;
  }

  BROWSEINFO     bi;
  LPITEMIDLIST  pidlMyComputer;  // PIDL for MyComputer folder

  LPITEMIDLIST  pidlBrowse;      // PIDL selected by user


  // Get the PIDL for the Programs folder.

  if (!SUCCEEDED(SHGetSpecialFolderLocation(hWnd, CSIDL_DRIVES, &pidlMyComputer)))
  {
    CoUninitialize();
    return false;
  }

  // Fill in the BROWSEINFO structure.

  bi.hwndOwner = hWnd;
  bi.pidlRoot = pidlMyComputer;
  bi.pszDisplayName = buf;
  bi.lpszTitle = title;
  bi.ulFlags = BIF_RETURNONLYFSDIRS | BIF_RETURNFSANCESTORS | BIF_EDITBOX | BIF_USENEWUI;
  bi.lpfn = BrowseCallbackProc;
  bi.lParam = (LPARAM)buf;

  // Browse for a folder and return its PIDL.

  pidlBrowse = SHBrowseForFolder(&bi);
  bool result = (pidlBrowse != 0);
  if (result)
  {
    if (!SHGetPathFromIDList(pidlBrowse, buf))
      result = false;

    // Free the PIDL returned by SHBrowseForFolder.

    g_pMalloc->Free(pidlBrowse);
  }

  // Clean up.

  g_pMalloc->Free(pidlMyComputer);

  CoUninitialize();
  
  return result;
}


