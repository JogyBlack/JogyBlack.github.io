//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include <vcl\inifiles.hpp>

#include "Main.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFormMain *FormMain;

extern bool BrowseForFolder(HWND hWnd, char *buf, const char *title);
//---------------------------------------------------------------------------
__fastcall TFormMain::TFormMain(TComponent* Owner)
  : TForm(Owner)
{
  count = 0;
  icons = 0;
  folder = new char[_MAX_PATH];
  folder[0] = '\0';

  TIniFile *iniFile = new TIniFile(ChangeFileExt(Application->ExeName, ".ini"));

  AnsiString str = iniFile->ReadString("Options", "LastFolder", folder);
  strcpy(folder, str.c_str());

  delete iniFile;

  if (folder[0] != '\0')
  {
    BitBtnClearIcon->Enabled = true;
    Caption = AnsiString("SetFolderIcon - ") + folder;
  }
  else
  {
    BitBtnClearIcon->Enabled = false;
    Caption = AnsiString("SetFolderIcon");
  }
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::BitBtnFileClick(TObject *Sender)
{
  if (OpenDialogFile->Execute())
  {
    int result = (int)::ExtractIcon(HInstance, OpenDialogFile->FileName.c_str(), -1);

    if (result <= 0)
    {
      Application->MessageBox("No icons", "Error", MB_OK | MB_ICONSTOP);
      return;
    }

    if (count > 0 && icons != 0)
    {
      ListViewIcons->Items->Clear();
      ImageListIcons->Clear();

      for (int index = 0; index < count; index++)
        delete icons[index];
      delete [] icons;

      BitBtnSetIcon->Enabled = false;
    }

    char buf[10];

    count = result;
    icons = new PTIcon[count];
    for (int index = 0; index < count; index++)
    {
      icons[index] = new TIcon;
      icons[index]->Handle = ::ExtractIcon(HInstance, OpenDialogFile->FileName.c_str(), index);

      int image = ImageListIcons->AddIcon(icons[index]);

      wsprintf(buf, "%d", index);
      TListItem *item = ListViewIcons->Items->Add();
      item->Caption = buf;
      item->ImageIndex = image;
      item->Data = (void*)index;
    }
  }
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::BitBtnQuitClick(TObject *Sender)
{
  Close();
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::ListViewIconsClick(TObject *Sender)
{
  BitBtnSetIcon->Enabled = (ListViewIcons->SelCount > 0) && folder[0] != '\0';
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::BitBtnBrowseFolderClick(TObject *Sender)
{
  if (!BrowseForFolder(Handle, folder, "Select the folder, which icon is to be changed."))
    return;
    
  BitBtnSetIcon->Enabled = (ListViewIcons->SelCount > 0) && (folder[0] != '\0');
  BitBtnClearIcon->Enabled = (folder[0] != '\0');

  if (folder[0] != '\0')
    Caption = AnsiString("SetFolderIcon - ") + folder;
  else
    Caption = AnsiString("SetFolderIcon");
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::BitBtnSetIconClick(TObject *Sender)
{
  if (ListViewIcons->SelCount > 0 && folder[0] != '\0')
  {
    int image = (int)ListViewIcons->Selected->Data;

    char temp[_MAX_PATH];
    strcpy(temp, folder);
    if (temp[strlen(temp) - 1] != '\\')
      strcat(temp, "\\");
    strcat(temp, "desktop.ini");

    TIniFile *iniFile = new TIniFile(temp);

    iniFile->WriteString(".ShellClassInfo", "IconFile", OpenDialogFile->FileName.c_str());
    iniFile->WriteInteger(".ShellClassInfo", "IconIndex", image);

    if (!EditInfoTip->Text.IsEmpty())
      iniFile->WriteString(".ShellClassInfo", "InfoTip", EditInfoTip->Text.c_str());

    delete iniFile;

    DWORD attr = ::GetFileAttributes(folder);
    if (!(attr & FILE_ATTRIBUTE_SYSTEM))
      ::SetFileAttributes(folder, attr | FILE_ATTRIBUTE_SYSTEM);

    attr = ::GetFileAttributes(temp);
    if (!(attr & FILE_ATTRIBUTE_HIDDEN))
      ::SetFileAttributes(temp, attr | FILE_ATTRIBUTE_HIDDEN);

    Application->MessageBox("The icon is set successfully.", "SetFolderIcon", MB_OK);
  }
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::BitBtnClearIconClick(TObject *Sender)
{
  if (folder[0] != '\0')
  {
    char temp[_MAX_PATH];
    strcpy(temp, folder);
    if (temp[strlen(temp) - 1] != '\\')
      strcat(temp, "\\");
    strcat(temp, "desktop.ini");

    DWORD attr = ::GetFileAttributes(folder);
    if (attr & FILE_ATTRIBUTE_SYSTEM)
      ::SetFileAttributes(folder, attr & ~FILE_ATTRIBUTE_SYSTEM);

    TIniFile *iniFile = new TIniFile(temp);

    iniFile->EraseSection(".ShellClassInfo");

    delete iniFile;

    Application->MessageBox("The icon is cleared successfully.", "SetFolderIcon", MB_OK);
  }
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::FormDestroy(TObject *Sender)
{
  TIniFile *iniFile = new TIniFile(ChangeFileExt(Application->ExeName, ".ini"));

  iniFile->WriteString("Options", "LastFolder", folder);

  delete iniFile;

  delete [] folder;
}
//---------------------------------------------------------------------------
