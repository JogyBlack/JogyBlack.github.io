//---------------------------------------------------------------------------

#ifndef MainH
#define MainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <Dialogs.hpp>
#include <ComCtrls.hpp>
#include <ImgList.hpp>
//---------------------------------------------------------------------------
typedef TIcon *PTIcon;
//---------------------------------------------------------------------------
class TFormMain : public TForm
{
__published:	// IDE-managed Components
  TBitBtn *BitBtnFile;
  TOpenDialog *OpenDialogFile;
  TBitBtn *BitBtnBrowseFolder;
  TBitBtn *BitBtnQuit;
  TListView *ListViewIcons;
  TImageList *ImageListIcons;
  TBitBtn *BitBtnSetIcon;
  TBitBtn *BitBtnClearIcon;
  TLabel *LabelInfoTip;
  TEdit *EditInfoTip;
  void __fastcall BitBtnFileClick(TObject *Sender);
  void __fastcall BitBtnQuitClick(TObject *Sender);
  void __fastcall ListViewIconsClick(TObject *Sender);
  void __fastcall BitBtnBrowseFolderClick(TObject *Sender);
  void __fastcall BitBtnSetIconClick(TObject *Sender);
  void __fastcall BitBtnClearIconClick(TObject *Sender);
  void __fastcall FormDestroy(TObject *Sender);

private:	// User declarations
  int count;
  PTIcon *icons;
  char *folder;

public:		// User declarations
  __fastcall TFormMain(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFormMain *FormMain;
//---------------------------------------------------------------------------
#endif
