#include <ctype.h>

#include <fstream.h>

typedef enum { None, DOSCyr, DOSRus, WinCyr, LatinCyr, UnicodeCyr } ConvType;

void Help()
{
	cout << "Text file cyrillic convertor" << endl;
  cout << "Usage: CONV /I[D|R|W|L|U] /O[D|R|W|L] InputFile OutputFile" << endl;
  cout << "  D - DOS cyrillic" << endl;
  cout << "  R - DOS russian cyrillic" << endl;
  cout << "  W - Windows cyrillic" << endl;
  cout << "  L - Latin cyrillic" << endl;
  cout << "  U - Unicode cyrillic (Input only)" << endl << endl;
}

void DOSCyr2DOSRus(unsigned char &c)
{
  if (c >= '\xB0' && c <= '\xBF')
    c += (0xE0 - 0xB0);
  else if (c == '\xCF')
    c = '\xBF';
  else if (c == '\xD3')
    c = '\xB3';
  else if (c == '\xD4')
    c = '\xB4';
  else if (c == '\xD5')
    c = '\xFC';
  else if (c == '\xD6')
    c = '\x15';
}

void DOSRus2DOSCyr(unsigned char &c)
{
	if (c >= '\xE0' && c <= '\xEF')
  	c -= (0xE0 - 0xB0);
  else if (c == '\xBF')
  	c = '\xCF';
  else if (c == '\xB3')
    c = '\xD3';
  else if (c == '\xB4')
    c = '\xD4';
  else if (c == '\xFC')
    c = '\xD5';
}

void DOSCyr2WinCyr(unsigned char &c)
{
	if (c >= '\x80' && c < '\xC0')
  	c += (0xC0 - 0x80);
}

void WinCyr2DOSCyr(unsigned char &c)
{
	if (c >= '\xC0')
  	c -= (0xC0 - 0x80);
}

void LatinCyr2WinCyr(unsigned char &c)
{
	switch (c) {
  	case 'a': c = '�'; break;
  	case 'b': c = '�'; break;
  	case 'c': c = '�'; break;
  	case 'd': c = '�'; break;
  	case 'e': c = '�'; break;
  	case 'f': c = '�'; break;
  	case 'g': c = '�'; break;
  	case 'h': c = '�'; break;
  	case 'i': c = '�'; break;
  	case 'j': c = '�'; break;
  	case 'k': c = '�'; break;
  	case 'l': c = '�'; break;
  	case 'm': c = '�'; break;
  	case 'n': c = '�'; break;
  	case 'o': c = '�'; break;
  	case 'p': c = '�'; break;
  	case 'q': c = '�'; break;
  	case 'r': c = '�'; break;
  	case 's': c = '�'; break;
  	case 't': c = '�'; break;
  	case 'u': c = '�'; break;
  	case 'v': c = '�'; break;
  	case 'w': c = '�'; break;
  	case 'x': c = '�'; break;
  	case 'y': c = '�'; break;
  	case 'z': c = '�'; break;
  	case '[': c = '�'; break;
  	case ']': c = '�'; break;
  	case '`': c = '�'; break;
  	case '\\': c = '�'; break;
  	case 'A': c = '�'; break;
  	case 'B': c = '�'; break;
  	case 'C': c = '�'; break;
  	case 'D': c = '�'; break;
  	case 'E': c = '�'; break;
  	case 'F': c = '�'; break;
  	case 'G': c = '�'; break;
  	case 'H': c = '�'; break;
  	case 'I': c = '�'; break;
  	case 'J': c = '�'; break;
  	case 'K': c = '�'; break;
  	case 'L': c = '�'; break;
  	case 'M': c = '�'; break;
  	case 'N': c = '�'; break;
  	case 'O': c = '�'; break;
  	case 'P': c = '�'; break;
  	case 'Q': c = '�'; break;
  	case 'R': c = '�'; break;
  	case 'S': c = '�'; break;
  	case 'T': c = '�'; break;
  	case 'U': c = '�'; break;
  	case 'V': c = '�'; break;
  	case 'W': c = '�'; break;
  	case 'X': c = '�'; break;
  	case 'Y': c = '�'; break;
  	case 'Z': c = '�'; break;
  	case '{': c = '�'; break;
  	case '}': c = '�'; break;
  	case '~': c = '�'; break;
  	case '|': c = '�'; break;
  }
}

void WinCyr2LatinCyr(unsigned char &c)
{
	switch (c) {
        case '�': c = 'a'; break;
        case '�': c = 'b'; break;
        case '�': c = 'c'; break;
        case '�': c = 'd'; break;
        case '�': c = 'e'; break;
        case '�': c = 'f'; break;
        case '�': c = 'g'; break;
        case '�': c = 'h'; break;
        case '�': c = 'i'; break;
        case '�': c = 'j'; break;
        case '�': c = 'k'; break;
        case '�': c = 'l'; break;
        case '�': c = 'm'; break;
        case '�': c = 'n'; break;
        case '�': c = 'o'; break;
        case '�': c = 'p'; break;
        case '�': c = 'q'; break;
        case '�': c = 'r'; break;
        case '�': c = 's'; break;
        case '�': c = 't'; break;
        case '�': c = 'u'; break;
        case '�': c = 'v'; break;
        case '�': c = 'w'; break;
        case '�': c = 'x'; break;
        case '�': c = 'y'; break;
        case '�': c = 'z'; break;
        case '�': c = '['; break;
        case '�': c = ']'; break;
        case '�': c = '`'; break;
        case '�': c = '\\'; break;
        case '�': c = 'A'; break;
        case '�': c = 'B'; break;
        case '�': c = 'C'; break;
        case '�': c = 'D'; break;
        case '�': c = 'E'; break;
        case '�': c = 'F'; break;
        case '�': c = 'G'; break;
        case '�': c = 'H'; break;
        case '�': c = 'I'; break;
        case '�': c = 'J'; break;
        case '�': c = 'K'; break;
        case '�': c = 'L'; break;
        case '�': c = 'M'; break;
        case '�': c = 'N'; break;
        case '�': c = 'O'; break;
        case '�': c = 'P'; break;
        case '�': c = 'Q'; break;
        case '�': c = 'R'; break;
        case '�': c = 'S'; break;
        case '�': c = 'T'; break;
        case '�': c = 'U'; break;
        case '�': c = 'V'; break;
        case '�': c = 'W'; break;
        case '�': c = 'X'; break;
        case '�': c = 'Y'; break;
        case '�': c = 'Z'; break;
        case '�': c = '{'; break;
        case '�': c = '}'; break;
        case '�': c = '~'; break;
        case '�': c = '|'; break;
  }
}

void Translate(unsigned char &c, ConvType InputConv, ConvType OutputConv)
{
	if (InputConv == LatinCyr) {
  	LatinCyr2WinCyr(c);
    if (OutputConv != WinCyr)
    	Translate(c, WinCyr, OutputConv);
  }

  if (OutputConv == LatinCyr) {
  	if (InputConv != WinCyr)
    	Translate(c, InputConv, WinCyr);
    WinCyr2LatinCyr(c);
  }

  if (InputConv == DOSCyr && OutputConv == DOSRus)
  	DOSCyr2DOSRus(c);
  else if (InputConv == DOSRus && OutputConv == DOSCyr)
  	DOSRus2DOSCyr(c);
  else if (InputConv == DOSCyr && OutputConv == WinCyr)
  	DOSCyr2WinCyr(c);
  else if (InputConv == WinCyr && OutputConv == DOSCyr)
  	WinCyr2DOSCyr(c);
  else if (InputConv == DOSRus && OutputConv == WinCyr) {
  	DOSRus2DOSCyr(c);
  	DOSCyr2WinCyr(c);
  }
  else if (InputConv == WinCyr && OutputConv == DOSRus) {
  	WinCyr2DOSCyr(c);
  	DOSCyr2DOSRus(c);
  }
}

void UnicodeCyr2WinCyr(unsigned char &c, unsigned char c2)
{
  if (c2 == '\0') {
//    c = c2;
    return;
  }

  if (c2 == '\x04') {
    c = c - '\x10' + '�';
    return;
  }
}

int main(int argc, char *argv[])
{
	char *InputFileName = 0;
  char *OutputFileName = 0;

  ConvType InputConv = None;
  ConvType OutputConv = None;

  for (int Index = 1; Index < argc; Index++) {
  	if (argv[Index][0] == '-' || argv[Index][0] == '/') {
    	switch (tolower(argv[Index][1])) {
      	case '?':
        case 'h':
        	Help();
          return 0;

        case 'i':
        	switch (tolower(argv[Index][2])) {
						case 'd':
              InputConv = DOSCyr; break;
						case 'r':
              InputConv = DOSRus; break;
						case 'w':
              InputConv = WinCyr; break;
						case 'l':
              InputConv = LatinCyr; break;
						case 'u':
              InputConv = UnicodeCyr; break;
          }
        	break;

        case 'o':
        	switch (tolower(argv[Index][2])) {
						case 'd':
              OutputConv = DOSCyr; break;
						case 'r':
              OutputConv = DOSRus; break;
						case 'w':
              OutputConv = WinCyr; break;
						case 'l':
              OutputConv = LatinCyr; break;
						case 'u':
              OutputConv = UnicodeCyr; break;
          }
        	break;
      }
    }
    else {
    	if (!InputFileName)
       	InputFileName = argv[Index];
      else if (!OutputFileName)
       	OutputFileName = argv[Index];
    }
  }

  if (!InputFileName || !OutputFileName ||
      InputConv == None || OutputConv == None) {
  	Help();
    return 1;
  }

  if (InputConv == OutputConv) {
  	cout << "Nothing to convert" << endl;
    return 1;
  }

  ifstream InputFile(InputFileName, ios::binary);

  if (!InputFile) {
		cout << "Cannot open " << InputFileName << endl;
    return 2;
  }

  ofstream OutputFile(OutputFileName, ios::binary);

  if (!OutputFile) {
  	cout << "Cannot open " << OutputFileName << endl;
    return 2;
  }

  InputFile.seekg(0, ios::end);
  long len = InputFile.tellg();
  InputFile.seekg(0, ios::beg);

  long percent;

  long step = len / 100;

  long pos = 0;

  while (!InputFile.eof()) {
		unsigned char c;

    InputFile.get(c);

    if (InputFile.gcount() < 1)
    	break;

    pos++;

    if (pos % step == 0) {
    	percent = pos * 100 / len;
    	cout << "\r\r\r\r\r\r" << percent << " %";
    }

    if (InputConv == UnicodeCyr) {
      unsigned char c2;

      InputFile.get(c2);

      if (InputFile.gcount() < 1)
        break;

      pos++;

      UnicodeCyr2WinCyr(c, c2);
      if (OutputConv != WinCyr)
        Translate(c, WinCyr, OutputConv);

    }
    else
      Translate(c, InputConv, OutputConv);

    OutputFile.put(c);
  }

  cout << "\r\r\r\r\r\r" << 100 << " %" << endl;

  return 0;
}
