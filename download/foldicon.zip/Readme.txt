SetFolderIcon is Windows GUI application for changing the icon of any folder.

To set an icon for a folder:
- Click on the "Select Folder" button to select the folder which icon is to be changed.
- Click on the "Select File" button to select a file, containing icons. When the file is opened,
the list of available icons will appear in the right-hand box.
- If you want a tooltip to be shown for the folder, enter the text in the "InfoTip" edit field.
- Select the desired icon and click the "Set Icon" button.

To restore the default folder icon:
- Click on the "Select Folder" button to select the folder which icon is to be restored.
- Click on the "Clear Icon" button.


This program is inspired by a post from Yoto Yotov in borland.public.cppbuilder.winapi,
describing how to change the folder icons.

Basicaly, the program writes a desktop.ini file, which contains the path to the icon file,
and sets the system attribute of the folder.


This program and it's full source are public domain, and can be used free of charge.

Copyright (c) 2001 by Jogy







