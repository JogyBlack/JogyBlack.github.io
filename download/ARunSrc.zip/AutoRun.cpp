#include <windows.h>
#include <string.h>

int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE, LPSTR, int nCmdShow)
{
	char buf[_MAX_PATH + 1];

	GetModuleFileName(hInstance, buf, _MAX_PATH);
  char *p = strrchr(buf, '.');
  if (p)
  	*p = '\0';
  strcat(buf, ".inf");

  GetPrivateProfileString("AutoRun", "File", "StartPage.html", buf, _MAX_PATH, buf);

	ShellExecute(NULL, "open", buf, NULL, NULL, nCmdShow);

  return 0;
}
