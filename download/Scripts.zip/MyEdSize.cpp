//--------------------------------------------------------------------------
// NEWEDSIZ.CPP: Auto sizes editor windows. Use with NEWEDSIZE.SPP script
//
// Copyright (c) 1996 by Kent Reisdorph, All Rights Reserved
//
//--------------------------------------------------------------------------
#define WIN32_LEAN_AND_MEAN
#define STRICT
#include <windows.h>
#include <cstring.h>
#include <dir.h>
#include <stdio.h>

int xPos;
int yPos;
HWND hWndNew;
HWND hWndExisting;
HWND hWndMDI;

enum FileGroup {
	Header,
  Source,
  Other
};

#define PAIRS_NUM 3

static const char* HeaderSourcePairsExt [][PAIRS_NUM] = {
	{".h", ".cpp"},
	{".hxx", ".cxx"},
	{".rh",".rc"},
};

FileGroup GetFileGroup(const char* pszExt)
{
	for (int i = 0; i < PAIRS_NUM; i++)
  	if (!strcmpi(pszExt, HeaderSourcePairsExt[i][Header]))
    	return Header;
    else
	  	if (!strcmpi(pszExt, HeaderSourcePairsExt[i][Source]))
      	return Source;

  return Other;
}

const char* GetCorrespondingExt(FileGroup fileGroup, const char* pszExt)
{
	for (int i = 0; i<PAIRS_NUM; i++)
  	if (!strcmpi(pszExt,HeaderSourcePairsExt[i][fileGroup]))
    	return HeaderSourcePairsExt[i][(fileGroup+1)%2];

  return 0;
}

int GetOffset()
{
	return GetSystemMetrics(SM_CYCAPTION) +(GetSystemMetrics(SM_CYFRAME) * 2);
}


string GetPath(const char* pszWndCaption)
{
	string sCaption(pszWndCaption);
  int nPos = sCaption.find_last_of(string(":"));
  if (nPos != NPOS && nPos != 1)//C:\.....
	  sCaption.remove(nPos);

  nPos = sCaption.find_first_of(string(" "));
  if (nPos != NPOS)
	  sCaption.remove(nPos);

  return sCaption;
}

string GetNameExt(const char* pszWndTitle, char* pszName, char* pszExt)
{
	string sPath = GetPath(pszWndTitle);
  fnsplit(sPath.c_str(),0,0,pszName,pszExt);
  return string(pszName) + pszExt;
}

string GetNameExt(const char* pszWndTitle)
{
  char pszName[MAXFILE];
  char pszExt[MAXEXT];
  return GetNameExt(pszWndTitle,pszName,pszExt);
}

BOOL CALLBACK FindExistingWindow(HWND hwnd, LPARAM pszNameExt)
{
	const int size = 20;
  char className[size];

  GetClassName(hwnd, className, size);

  if (hwnd == hWndNew || strcmp(className, "BCW5Editor"))
  	return TRUE;

  if (IsIconic(hwnd))
  	return TRUE;

  const int nCurrWndTitleLen = MAXPATH + 3;//title:2
  char pszCurrWndTitle[nCurrWndTitleLen];
  GetWindowText(hwnd,pszCurrWndTitle,nCurrWndTitleLen);
  string sCurrNameExt = GetNameExt(pszCurrWndTitle);

  if (sCurrNameExt == (char*)pszNameExt) {
  	hWndExisting = hwnd;
    return FALSE;
  }
  
  return TRUE;
}

// callback function called to enumerate
// the child windows
BOOL CALLBACK EnumProc(HWND hwnd, LPARAM lParam)
{
	const int size = 20;
  char className[size];

  GetClassName(hwnd, className, size);

  if (hwnd == hWndNew || strcmp(className, "BCW5Editor")) return TRUE;

  if (IsIconic(hwnd))
  	return TRUE;

	RECT rect;
  POINT point;

	int offset = GetOffset();

	GetWindowRect(hwnd, &rect);
  point.x = rect.left;
  point.y = rect.top;

  ScreenToClient((HWND)lParam, &point);

  if (point.y >= yPos)
    yPos = point.y + offset;

  return TRUE;
}

extern "C"
void PASCAL _export
PositionWindow(char* title, int width, int height, bool bSourceInLeft = true)
{
	// reset x and y pos before each run
	xPos = yPos = 0;
  hWndExisting = 0;
  string::set_case_sensitive(0);

  // find the IDE window
	HWND hWndIDE = FindWindow("CPPFRAME", NULL);

  // find the MDI client which is the client
  // window of the IDE
	hWndMDI = FindWindowEx(hWndIDE, NULL, "MDIClient", NULL);

  // get a handle to the newly-created editor
	hWndNew = FindWindowEx(hWndMDI, NULL, "BCW5Editor", title);


  char pszName[MAXFILE];
  char pszExt[MAXEXT];
  GetNameExt(title,pszName,pszExt);

  FileGroup fileGroup = GetFileGroup(pszExt);

  if (fileGroup != Other) {
    RECT rect;
    if(fileGroup == (bSourceInLeft ? Source : Header)) {
      GetClientRect(hWndMDI, &rect);
      xPos = rect.right - width;
    }
  	strcpy(pszExt,GetCorrespondingExt(fileGroup,pszExt));
    char pszNameExt[MAXFILE + MAXEXT + 1];
    sprintf(pszNameExt,"%s%s",pszName,pszExt);
	  EnumChildWindows(hWndMDI, FindExistingWindow, (LPARAM)pszNameExt);
    if (hWndExisting) {
      POINT point;
      GetWindowRect(hWndExisting, &rect);
      point.x = rect.left;
      point.y = rect.top;
      ScreenToClient(hWndMDI, &point);
      yPos = point.y;
    }
    else
		  EnumChildWindows(hWndMDI, EnumProc, (LPARAM)hWndMDI);
  }
  else
	  EnumChildWindows(hWndMDI, EnumProc, (LPARAM)hWndMDI);

  if (hWndNew)
  	SetWindowPos(hWndNew, 0, xPos, yPos, width, height, SWP_NOZORDER);
}


