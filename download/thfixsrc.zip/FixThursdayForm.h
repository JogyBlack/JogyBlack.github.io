//---------------------------------------------------------------------------

#ifndef FixThursdayFormH
#define FixThursdayFormH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
#include "common.h"
#include <Buttons.hpp>

class TForm1 : public TForm
{
__published:	// IDE-managed Components
  TLabel *Label1;
  TLabel *Label2;
  TEdit *EditFile;
  TListBox *ListBoxPositions;
  TCheckBox *CheckBoxBackup;
  TBitBtn *ButtonFix;
  TBitBtn *ButtonRestore;
  TBitBtn *ButtonAbout;
  TBitBtn *ButtonClose;
  void __fastcall FormCreate(TObject *Sender);
  void __fastcall ButtonFixClick(TObject *Sender);
  void __fastcall ButtonCloseClick(TObject *Sender);
  void __fastcall ButtonRestoreClick(TObject *Sender);
  void __fastcall ButtonAboutClick(TObject *Sender);

private:	// User declarations
  ThursdayFixer fixer;

public:		// User declarations
  __fastcall TForm1(TComponent* Owner);
  __fastcall ~TForm1();
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
