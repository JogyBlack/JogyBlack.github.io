#pragma hdrstop

#include <windows.h>
#include <fstream>
#include <vector>

#include "common.h"

const char filename[] = "\\locale.nls";

const char ext[] = ".bak";

const char match[] = {
  '\x47', '\x04',
  '\x35', '\x04',
  '\x42', '\x04',
  '\x32', '\x04',
  '\x4A', '\x04',
  '\x32', '\x04',
  '\x42', '\x04',
  '\x4A', '\x04',
  '\x3A', '\x04',
  '\0', '\0',
};


ThursdayFixer::ThursdayFixer()
{
  file = new char[_MAX_PATH];
  file[0] = '\0';
}

ThursdayFixer::~ThursdayFixer()
{
  delete [] file;
}

bool ThursdayFixer::Init()
{
  GetSystemDirectory(file, _MAX_PATH - sizeof(filename));

  strcat(file, filename);

  std::ifstream ifs(file);

  if (!ifs) {
    file[0] = '\0';
    return false;
  }
  else
    return true;
}

bool ThursdayFixer::ExistBackup()
{
  if (!IsValid())
    return false;

  char temp[_MAX_PATH + 1];

  strcpy(temp, file);
  strcat(temp, ext);

  std::ifstream ifs(temp);

  if (!ifs)
    return false;
  else
    return true;
}

bool ThursdayFixer::RestoreFile()
{
  if (!IsValid())
    return false;

  char temp[_MAX_PATH + 1];

  strcpy(temp, file);
  strcat(temp, ext);

  return MoveFile(temp, file);
}

bool ThursdayFixer::GetOffsets(std::vector<int> &offsets)
{
  if (!IsValid())
    return false;

  std::ifstream ifs(file, std::ios::binary | std::ios::in);

  if (!ifs)
    return false;

  int index = 0;
  int pos = 0;

  while (ifs) {
    char c;

    ifs.get(c);

    if (c == match[index]) {
      index++;
      if (match[index] == '\0') {
        offsets.insert(offsets.end(), pos - sizeof(match) + 3);
        index = 0;
      }
    }
    else
      index = 0;

    pos++;
  }

  return true;
}

bool ThursdayFixer::CreateBackup()
{
  char temp[_MAX_PATH];

  strcpy(temp, file);

  strcat(temp, ext);

  return CopyFile(file, temp, FALSE) == TRUE;
}

bool ThursdayFixer::FixFile()
{
  if (!IsValid())
    return false;

  char temp[_MAX_PATH + 1];

  strcpy(temp, file);
  char *p = strrchr(temp, '.');
  if (p)
    *p = '\0';
  strcat(temp, ".tmp");

  std::ifstream ifs(file, std::ios::binary | std::ios::in);
  if (!ifs)
    return false;

  std::ofstream ofs(temp, std::ios::binary | std::ios::out);
  if (!ofs)
    return false;

  char buf[sizeof(match) + 1];

  int index = 0;

  while (ifs) {
    char c;

    ifs.get(c);

    if (!ifs)
      break;

    if (c == match[index]) {
      buf[index] = c;
      index++;
      if (match[index] == '\0') {
        buf[10] = '\x40';
        for (int index2 = 0; index2 < index; index2++)
          ofs.put(buf[index2]);

        index = 0;
      }
    }
    else {
      if (index > 0) {
        for (int index2 = 0; index2 < index; index2++)
          ofs.put(buf[index2]);

        index = 0;
      }

      ofs.put(c);
    }
  }

  return MoveFile(temp, file);
}

bool ThursdayFixer::Shutdown()
{
  if (IsNT()) {
    HANDLE hToken;
    TOKEN_PRIVILEGES tkp;

    // Get a token for this process.

    if (!OpenProcessToken(GetCurrentProcess(),
          TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken))
      return false;

    // Get the LUID for the shutdown privilege.

    LookupPrivilegeValue(NULL, SE_SHUTDOWN_NAME, &tkp.Privileges[0].Luid);

    tkp.PrivilegeCount = 1;  // one privilege to set
    tkp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

    // Get the shutdown privilege for this process.

    AdjustTokenPrivileges(hToken, FALSE, &tkp, 0, (PTOKEN_PRIVILEGES)NULL, 0);

    // Cannot test the return value of AdjustTokenPrivileges.

    if (GetLastError() != ERROR_SUCCESS)
      return false;
  }

  // Shut down the system and force all applications to close.

  if (!ExitWindowsEx(EWX_REBOOT, 0))
    return false;

  return true;
}

bool ThursdayFixer::IsNT()
{
  OSVERSIONINFO os;
  memset(&os, '\0', sizeof(os));
  os.dwOSVersionInfoSize = sizeof(os);

  GetVersionEx(&os);

  return os.dwPlatformId == VER_PLATFORM_WIN32_NT; 
}

bool ThursdayFixer::MoveFile(const char *src, const char *dest)
{
  if (IsNT())
    return MoveFileEx(src, dest, MOVEFILE_DELAY_UNTIL_REBOOT |
                                 MOVEFILE_REPLACE_EXISTING) == TRUE;
  else
    return WritePrivateProfileString("rename", dest, src,
                                     "wininit.ini") == TRUE;
}

