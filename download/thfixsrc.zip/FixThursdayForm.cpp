//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "FixThursdayForm.h"
#include "AboutForm.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
  : TForm(Owner)
{
}
//---------------------------------------------------------------------------
__fastcall TForm1::~TForm1()
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
  if (!fixer.Init()) {
    EditFile->Text = "(not found)";
    return;
  }

  EditFile->Text = fixer.GetFile();

  ButtonRestore->Enabled = fixer.ExistBackup();

  std::vector<int> offsets;
  if (!fixer.GetOffsets(offsets)) {
    EditFile->Text = "(not found)";
    return;
  }

  if (offsets.size() < 1) {
    ListBoxPositions->Items->Add("(none found)");
    return;
  }

  for (std::vector<int>::iterator iter = offsets.begin(); iter != offsets.end(); iter++) {
    char buf[20];
    wsprintf(buf, "Offset: %d", (int)*iter);
    ListBoxPositions->Items->Add(buf);

  }

  ButtonFix->Enabled = true;
}

void __fastcall TForm1::ButtonFixClick(TObject *Sender)
{
  if (CheckBoxBackup->Checked) {
    if (!fixer.CreateBackup()) {
      int result = Application->MessageBox("Cannot create backup. Continue anyway?",
                                           "Warning", MB_YESNO | MB_ICONWARNING);

      if (result != IDYES)
        return;
    }
  }

  if (!fixer.FixFile()) {
    Application->MessageBox("Cannot fix file", "Error", MB_OK | MB_ICONSTOP);
    return;
  }

  int result = Application->MessageBox("Reboot computer now?",
                                       "Question", MB_YESNO | MB_ICONQUESTION);

  if (result == IDYES) {
    if (!fixer.Shutdown()) {
      Application->MessageBox("Cannot reboot computer", "Warning", MB_OK | MB_ICONWARNING);
    }
  }
  
  Close();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonCloseClick(TObject *Sender)
{
  Close();
}
//---------------------------------------------------------------------------


void __fastcall TForm1::ButtonRestoreClick(TObject *Sender)
{
  if (!fixer.RestoreFile()) {
    Application->MessageBox("Cannot restore file", "Error", MB_OK | MB_ICONSTOP);
    return;
  }

  int result = Application->MessageBox("Reboot computer now?",
                                       "Question", MB_YESNO | MB_ICONQUESTION);

  if (result == IDYES) {
    if (!fixer.Shutdown()) {
      Application->MessageBox("Cannot reboot computer", "Warning", MB_OK | MB_ICONWARNING);
    }
  }
}


void __fastcall TForm1::ButtonAboutClick(TObject *Sender)
{
  Form2->ShowModal();  
}
//---------------------------------------------------------------------------

