#ifndef COMMON_H
#define COMMON_H

#include <vector>

class ThursdayFixer
{
  public:
    ThursdayFixer();
    ~ThursdayFixer();

    bool Init();
    bool IsValid() { return file && file[0] != '\0'; }

    const char *GetFile() { return file; }

    bool ExistBackup();

    bool RestoreFile();
    bool GetOffsets(std::vector<int> &offsets);
    bool CreateBackup();
    bool FixFile();
    bool Shutdown();

  private:
    char *file;

    bool IsNT();
    bool MoveFile(const char *src, const char *dest);
};

#endif
