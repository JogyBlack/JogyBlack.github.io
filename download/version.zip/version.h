//----------------------------------------------------------------------------
// ObjectWindows
// Copyright (c) 1991, 1996 by Borland International, All Rights Reserved
// 1998-2000 by Yura Bidus
//
//$Revision$
//$Author$
//$Date$
//
//----------------------------------------------------------------------------

#if !defined(OWL_VERSION_H)
#define OWL_VERSION_H



// OWL Version number, format: Major, Minor, YYYY, MMDD
// NB! No leading zero in MMDD! (leading zero = octal)
//
#define _OWL_VERSION(v) v(6,20,2005,706)

// Used by OWLMaker
#define OWLVersionStr "6.20"

// Version string and number builders.
//
#define V_4WORD(major,minor,year,mmdd) major, minor, year, mmdd

//Jogy  apparently macros with arguments do not work with borland resource compiler
#if defined(__BORLANDC__) && defined(RC_INVOKED)
#define V_STRING(major,minor,year,mmdd) "6.20.2005.706"
#define V_MAJORMINORSTRING(major,minor,year,mmdd) "6.20"
#define V_OWLDLL(major,minor,year,mmdd) "OWL6.20"
#else
#define V_STRING(major,minor,year,mmdd) #major "." #minor "." #year "." #mmdd
#define V_MAJORMINORSTRING(major,minor,year,mmdd) #major "." #minor
#define V_OWLDLL(major,minor,year,mmdd) "OWL" #major #minor
#endif

#define V_16BIT(major,minor,year,mmdd) \
  (((major/10) << 12) | ((major%10) << 8) | ((minor/10) << 4) | (minor%10))
  // 0xMmNn, where M=Major/10, m=Major%10, N=Minor/10, n=Minor%10
  // E.g. 0x0620 (6.20)



#define V_32BIT(major,minor,year,mmdd) \
  (((long)(V_16BIT(major, minor, 0, 0)) << 16) | ((year%10) << 12) | mmdd)
  // 0xMmNnYddd, where M=Major/10, m=Major%10, N=Minor/10, n=minor%10, Y=Year%10, ddd=100*Month+Day
  // E.g. 0x06205193 (6.20.2005.0403)
  // NB! After 2009, Y will swap around.

// Version number defines
//
 // major, minor, year, mmdd
#define OWLFileVersion _OWL_VERSION(V_4WORD)

 // major, minor, year, mmdd
#define OWLProductVersion OWLFileVersion

 // "major.minor.year.mmdd"
#define OWLFileVersionString _OWL_VERSION(V_STRING)

 // "major.minor"
#define OWLProductVersionString _OWL_VERSION(V_MAJORMINORSTRING)

 // Internal 16-bit version number.
#define OWLVersion  _OWL_VERSION(V_16BIT)

 // Internal 32-bit version number.
#define OWLInternalVersion  _OWL_VERSION(V_32BIT)

// OWL DLL naming
//
#define OWLDLLNameBase _OWL_VERSION(V_OWLDLL) // OWL DLL name base, e.g. "OWL620".

#if defined(USERBUILD)
#  define OWLDLLName USERNAME
#else

#  if defined(__WIN32__)  || defined (_WIN32)

#    if defined(__BORLANDC__) || defined(WORKSHOP_INVOKED)
#      if defined(_DEBUG)
#        if defined(__MT__)
#         if defined(VCLRTL)
#           if defined(_UNICODE)
#              define OWLDLLName OWLDLLNameBase "DTVU"
#           else
#              define OWLDLLName OWLDLLNameBase "DTV"
#           endif
#         else
#           if defined(_UNICODE)
#              define OWLDLLName OWLDLLNameBase "DTU"
#           else
#              define OWLDLLName OWLDLLNameBase "DT"
#           endif 
#         endif 
#        else
#          if defined(_UNICODE) 
#            define OWLDLLName OWLDLLNameBase "DFU"
#          else 
#            define OWLDLLName OWLDLLNameBase "DF"
#          endif 
#        endif
#      else // defined (_DEBUG)
#        if defined(__MT__)
#         if defined(VCLRTL) 
#           if defined(_UNICODE) 
#              define OWLDLLName OWLDLLNameBase "TVU"
#           else 
#              define OWLDLLName OWLDLLNameBase "TV"
#           endif 
#         else 
#           if defined(_UNICODE) 
#              define OWLDLLName OWLDLLNameBase "TU"
#           else 
#              define OWLDLLName OWLDLLNameBase "T"
#           endif 
#         endif 
#        else
#         if defined(_UNICODE) 
#            define OWLDLLName OWLDLLNameBase "FU"
#         else 
#            define OWLDLLName OWLDLLNameBase "F"
#         endif 
#        endif
#      endif // defined(_DEBUG)

#    elif defined(__GNUC__)
#      if defined(_DEBUG)
#        if defined(__MT__)
#          if defined(_UNICODE) 
#            define OWLDLLName OWLDLLNameBase "GDTU"
#          else
#            define OWLDLLName OWLDLLNameBase "GDT"
#          endif
#        else
#          if defined(_UNICODE) 
#            define OWLDLLName OWLDLLNameBase "GDFU"
#          else
#            define OWLDLLName OWLDLLNameBase "GDF"
#          endif
#        endif
#      else // defined(_DEBUG)
#        if defined(__MT__)
#         if defined(_UNICODE) 
#            define OWLDLLName OWLDLLNameBase "GTU"
#          else
#            define OWLDLLName OWLDLLNameBase "GT"
#          endif
#        else
#         if defined(_UNICODE) 
#            define OWLDLLName OWLDLLNameBase "GU"
#          else
#            define OWLDLLName OWLDLLNameBase "G"
#          endif
#        endif
#      endif // defined(_DEBUG)

#    elif defined(MAINWIN)
#      if defined(_DEBUG)
#        define OWLDLLNAME OWLDLLNameBase "D"
#      else
#        define OWLDLLNAME OWLDLLNameBase
#      endif

#    elif defined(_MSC_VER) || defined(RC_INVOKED)
#      if defined(_DEBUG)
#        if defined(_UNICODE) 
#          define OWLDLLName OWLDLLNameBase "VDU"
#        else
#          define OWLDLLName OWLDLLNameBase "VD"
#        endif
#      else // defined(_DEBUG)
#        if defined(_UNICODE) 
#          define OWLDLLName OWLDLLNameBase "VU"
#        else
#          define OWLDLLName OWLDLLNameBase "V"
#        endif
#      endif // defined(_DEBUG)

#    else
#     error must be defined OWLDLLName
#    endif

#  else // defined(__WIN32__)

#    if defined(_DEBUG)
#      define OWLDLLName OWLDLLNameBase "D"
#    else
#      define OWLDLLName OWLDLLNameBase
#    endif
#  endif // defined(__WIN32__)

#endif  // defined(USERBUILD)

#endif  //  OWL_VERSION_H
