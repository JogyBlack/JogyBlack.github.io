#include <owl/pch.h>
#pragma hdrstop

#include "client.h"

#include "namedccb.h"

#include "app.rh"                  // Definition of all resources.

extern TColor GetJumpColor();
extern TColor GetPopupColor();

extern bool SetJumpColor(const TColor &color);
extern bool SetPopupColor(const TColor &color);

DEFINE_RESPONSE_TABLE1(WinHelpColorsClient, TDialog)
  EV_COMMAND(IDOK, CmOk),
END_RESPONSE_TABLE;

WinHelpColorsClient::WinHelpColorsClient(TWindow* parent, TResId resId, TModule* module)
: TDialog(parent, resId == TResId(0) ? TResId(IDD_CLIENT) : resId, module ? module : ::Module)
{
  gbOk = new TGlyphButton(this, IDOK, TGlyphButton::btOk);                 // Ok
  gbOk->SetLayoutStyle(TGlyphButton::lsH_GST);
  gbCancel = new TGlyphButton(this, IDCANCEL, TGlyphButton::btCancel);         // Cancel
  gbCancel->SetLayoutStyle(TGlyphButton::lsH_GST);

  jumpColor = new TNamedColorComboBox(this, IDC_COMBOBOXJUMPCOLOR);
  popupColor = new TNamedColorComboBox(this, IDC_COMBOBOXPOPUPCOLOR);

  tooltip = new TTooltip(this);
}

WinHelpColorsClient::~WinHelpColorsClient()
{
  Destroy();
}

void WinHelpColorsClient::SetupWindow()
{
	TDialog::SetupWindow();	jumpColor->SelectColor(GetJumpColor());	popupColor->SelectColor(GetPopupColor());}
bool WinHelpColorsClient::PreProcessMsg(MSG &msg)
{
// This code is taken from the book Core OWL by Ted Neward
  if (tooltip && tooltip->IsWindow())    tooltip->RelayEvent(msg);  return TDialog::PreProcessMsg(msg);}

void WinHelpColorsClient::CmOk()
{
	SetJumpColor(jumpColor->GetSelColor(GetJumpColor()));
	SetPopupColor(popupColor->GetSelColor(GetPopupColor()));

	TDialog::CmOk();
}


