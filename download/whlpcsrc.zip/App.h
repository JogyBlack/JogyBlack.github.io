#if !defined(app_h)              // Sentry, use file only if it's not already included.
#define app_h

#include <owl\applicat.h>

////////////////////////////////////////////////////////////////////////////////

class WinHelpColorsApp : public TApplication
{
  public:
    WinHelpColorsApp();
    virtual ~WinHelpColorsApp();

    virtual void InitMainWindow();
};

#endif  // app_h sentry.
