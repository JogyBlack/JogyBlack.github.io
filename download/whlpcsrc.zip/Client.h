#if !defined(client_h)              // Sentry, use file only if it's not already included.
#define client_h

#include <owl\glyphbtn.h>
#include <owl\tooltip.h>

class TNamedColorComboBox;

class WinHelpColorsClient : public TDialog
{
  public:
    WinHelpColorsClient(TWindow* parent, TResId resId = TResId(0), TModule* module = 0);
    virtual ~WinHelpColorsClient();

  protected:
    void SetupWindow();

    bool PreProcessMsg(MSG &msg);

    void CmOk();

    TGlyphButton *gbOk;
    TGlyphButton *gbCancel;

		TNamedColorComboBox *jumpColor;
		TNamedColorComboBox *popupColor;

    TTooltip *tooltip;

DECLARE_RESPONSE_TABLE(WinHelpColorsClient);
};


#endif  // client_h sentry.
