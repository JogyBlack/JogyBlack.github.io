#include <owl/pch.h>
#pragma hdrstop

#include <owl/registry.h>

const int BUFLEN = 40;

static TColor GetColor(const char *buf)
{
  int r, g, b;
  r = atoi(buf);
  const char *p = strchr(buf, ' ');
  if (!p)
    return TColor(r, 0, 0);

  g = atoi(p + 1);

  p = strchr(p + 1, ' ');
  if (!p)
    return TColor(r, g, 0);

  b = atoi(p + 1);

  return TColor(r, g, b);
}

static TColor GetRegColor(const char *name)
{
  TRegKey key(TRegKey::CurrentUser(), "Software\\Microsoft\\Windows Help",
              KEY_ALL_ACCESS, TRegKey::NoCreate);

  if (!key)
    return TColor(0, 255, 0);

  char buf[BUFLEN + 1];

  uint32 type;
  uint32 dataSize = BUFLEN;

  long hResult = key.QueryValue(name, &type, (uint8 *)buf, &dataSize);

  if (hResult != ERROR_SUCCESS)
    return TColor(0, 255, 0);

  return GetColor(buf);
}

static bool SetRegColor(const char *name, const TColor &color)
{
  TRegKey key(TRegKey::CurrentUser(), "Software\\Microsoft\\Windows Help",
              KEY_ALL_ACCESS, TRegKey::CreateOK);

  if (!key)
    return false;

  char buf[BUFLEN + 1];

	wsprintf(buf, "%d %d %d", color.Red(), color.Green(), color.Blue());

  long hResult = key.SetValue(name, REG_SZ, (uint8 *)buf, strlen(buf));

  if (hResult != ERROR_SUCCESS)
    return false;

  return true;
}

static TColor GetIniColor(const char *name)
{
  char buf[BUFLEN + 1];

  GetProfileString("Windows Help", name, "0 255 0", buf, BUFLEN);

  return GetColor(buf);
}

static bool SetIniColor(const char *name, const TColor &color)
{
  char buf[BUFLEN + 1];

	wsprintf(buf, "%d %d %d", color.Red(), color.Green(), color.Blue());

  return WriteProfileString("Windows Help", name, buf) == TRUE;
}

TColor GetJumpColor()
{
	if (TSystem::IsNT())
  	return GetRegColor("JumpColor");
  else
  	return GetIniColor("JumpColor");
}

TColor GetPopupColor()
{
	if (TSystem::IsNT())
  	return GetRegColor("PopupColor");
  else
  	return GetIniColor("PopupColor");
}

bool SetJumpColor(const TColor &color)
{
	if (TSystem::IsNT())
    return SetRegColor("JumpColor", color);
  else
    return SetIniColor("JumpColor", color);
}

bool SetPopupColor(const TColor &color)
{
	if (TSystem::IsNT())
    return SetRegColor("PopupColor", color);
  else
    return SetIniColor("PopupColor", color);
}
