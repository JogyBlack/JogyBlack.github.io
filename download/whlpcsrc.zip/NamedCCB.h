#ifndef __NAMEDCCB_H__  	// Sentry
#define __NAMEDCCB_H__

#include <owl/color.h>
#include <owl/combobox.h>
#include <owl/template.h>


class TNamedColor : public TColor
{
	public:
    TNamedColor();
    TNamedColor(const TNamedColor& src, const char *name = 0);

    TNamedColor(COLORREF value, const char *name = 0);
    TNamedColor(long value, const char *name = 0);

    TNamedColor(int r, int g, int b, const char *name = 0);
    TNamedColor(int r, int g, int b, int f, const char *name = 0);
    TNamedColor(int index, const char *name = 0);

    TNamedColor(const PALETTEENTRY & pe, const char *name = 0);
    TNamedColor(const RGBQUAD & q, const char *name = 0);
    TNamedColor(const RGBTRIPLE & t, const char *name = 0);

    const char *GetName() const { return Name.c_str(); }
    void SetName(const char *name);

    static const char *GetCommonName(TColor &color);

  private:
  	owl_string Name;
};

typedef TPtrArray<TNamedColor*> TNamedColorArray;
typedef TNamedColorArray::Iterator TNamedColorArrayIter;

////////////////////////////////////////////////////////////////////////////////

class TNamedColorComboBox : public TComboBox
{
  public:
    TNamedColorComboBox(TWindow* parent, int id, int x, int y, int w, int h,
                        TNamedColorArray *colors = 0, TModule* module = 0);

    TNamedColorComboBox(TWindow* parent, int resourceId,
                        TNamedColorArray *colors = 0, TModule* module = 0);

    virtual ~TNamedColorComboBox();

    void SelectColor(const TColor &color);

    TColor GetSelColor(const TColor &defColor = TColor::White);

  protected:
  	virtual void SetupWindow();

    virtual void ODADrawEntire(DRAWITEMSTRUCT &drawInfo);
    virtual void ODAFocus(DRAWITEMSTRUCT &drawInfo);
    virtual void ODASelect(DRAWITEMSTRUCT &drawInfo);

    virtual void MeasureItem(MEASUREITEMSTRUCT &measureInfo);

		void CbnSelChanged();

  private:
    void InitColors(TNamedColorArray *colors);

    void Draw(TDC &dc, TRect &rect, DWORD dwItemData, bool selected = false);
    void DrawColor(TDC &dc, TRect &rect, const TColor &color);
    void DrawText(TDC &dc, TRect &rect, const char *name, bool selected = false);

    TNamedColorArray Colors;

	DECLARE_RESPONSE_TABLE(TNamedColorComboBox);
};

////////////////////////////////////////////////////////////////////////////////

inline TNamedColor::TNamedColor()
: Name("")
{
}

inline TNamedColor::TNamedColor(const TNamedColor& src, const char *name)
: TColor(src)
{
	SetName(name);
}

inline TNamedColor::TNamedColor(COLORREF value, const char *name)
: TColor(value)
{
	SetName(name);
}

inline TNamedColor::TNamedColor(long value, const char *name)
: TColor(value)
{
	SetName(name);
}

inline TNamedColor::TNamedColor(int r, int g, int b, const char *name)
: TColor(r, g, b)
{
	SetName(name);
}

inline TNamedColor::TNamedColor(int r, int g, int b, int f, const char *name)
: TColor(r, g, b, f)
{
	SetName(name);
}

inline TNamedColor::TNamedColor(int index, const char *name)
: TColor(index)
{
	SetName(name);
}

inline TNamedColor::TNamedColor(const PALETTEENTRY & pe, const char *name)
: TColor(pe)
{
	SetName(name);
}

inline TNamedColor::TNamedColor(const RGBQUAD & q, const char *name)
: TColor(q)
{
	SetName(name);
}

inline TNamedColor::TNamedColor(const RGBTRIPLE & t, const char *name)
: TColor(t)
{
	SetName(name);
}

////////////////////////////////////////////////////////////////////////////////
#endif  	// Sentry

