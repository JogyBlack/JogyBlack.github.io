#include <owl/pch.h>
#pragma hdrstop

#include <owl/chooseco.h>

#include "namedccb.h"

void TNamedColor::SetName(const char *name)
{
  if (name)
  	Name = owl_string(name);
  else
  	Name = GetCommonName(*this);
}

const char *TNamedColor::GetCommonName(TColor &color)
{
	if (color == TColor::Black)
  	return "Black";
  else if (color == TColor::LtGray)
  	return "Light Gray";
  else if (color == TColor::Gray)
  	return "Dark Gray";
  else if (color == TColor::LtRed)
  	return "Red";
  else if (color == TColor::LtGreen)
  	return "Green";
  else if (color == TColor::LtYellow)
  	return "Yellow";
  else if (color == TColor::LtBlue)
  	return "Blue";
  else if (color == TColor::LtMagenta)
  	return "Magenta";
  else if (color == TColor::LtCyan)
  	return "Cyan";
  else if (color == TColor::White)
  	return "White";

  return "Custom";
}

////////////////////////////////////////////////////////////////////////////////

DEFINE_RESPONSE_TABLE1(TNamedColorComboBox, TComboBox)
  EV_CBN_SELCHANGE(-1, CbnSelChanged),
END_RESPONSE_TABLE;

TNamedColorComboBox::TNamedColorComboBox(TWindow* parent, int id, int x, int y, int w, int h,
                                         TNamedColorArray *colors, TModule* module)
: TComboBox(parent, id, x, y, w, h, CBS_OWNERDRAWFIXED | CBS_DROPDOWNLIST, 0, module)
{
	InitColors(colors);
}

TNamedColorComboBox::TNamedColorComboBox(TWindow* parent, int resourceId,
                                         TNamedColorArray *colors, TModule* module)
: TComboBox(parent, resourceId, 0, module)
{
	InitColors(colors);
}

TNamedColorComboBox::~TNamedColorComboBox()
{
	Destroy();

  for (TNamedColorArrayIter iter(Colors); iter; iter++) {
  	delete iter.Current();
  }
}

void TNamedColorComboBox::InitColors(TNamedColorArray *colors)
{
  if (colors) {
    for (TNamedColorArrayIter iter(*colors); iter; iter++)
      Colors.Add(new TNamedColor(*iter.Current()));
  }
  else {
		Colors.Add(new TNamedColor(TColor::White));
		Colors.Add(new TNamedColor(TColor::LtYellow));
		Colors.Add(new TNamedColor(TColor::LtRed));
		Colors.Add(new TNamedColor(TColor::LtMagenta));
		Colors.Add(new TNamedColor(TColor::LtCyan));
		Colors.Add(new TNamedColor(TColor::LtBlue));
		Colors.Add(new TNamedColor(TColor::LtGreen));
		Colors.Add(new TNamedColor(TColor::LtGray));
		Colors.Add(new TNamedColor(TColor::Gray));
		Colors.Add(new TNamedColor(TColor::Black));
  }
}

void TNamedColorComboBox::SetupWindow()
{
	TComboBox::SetupWindow();

  int index = 0;
  for (TNamedColorArrayIter iter(Colors); iter; iter++, index++) {
    int item = AddString(iter.Current()->GetName());
    SetItemData(item, (uint32)index);
  }

  int item = AddString("(Other...)");
  SetItemData(item, (uint32)-1);
}

void TNamedColorComboBox::SelectColor(const TColor &color)
{
	int index = 0;
  bool found = false;
  for (TNamedColorArrayIter iter(Colors); iter; iter++, index++) {
  	if (*iter.Current() == color) {
    	found = true;
			break;
    }
  }

  if (!found)
    index = Colors.Add(new TNamedColor(color));

	int count = GetCount();

	for (int item = 0; item < count; item++) {
    uint32 data = GetItemData(item);
    if (data == (uint32)index) {
    	SetSelIndex(item);
      return;
    }
  }

  int item = InsertString(Colors[index]->GetName(), 0);
  SetItemData(item, (uint32)index);
  SetSelIndex(item);
}

TColor TNamedColorComboBox::GetSelColor(const TColor &defColor)
{
	int index = GetSelIndex();
  if (index < 0)
  	return defColor;

  uint32 data = GetItemData(index);
  if (data == (uint32)-1)
  	return defColor;

  return *Colors[data];
}

void TNamedColorComboBox::ODADrawEntire(DRAWITEMSTRUCT &drawInfo)
{
  TDC drawDC(drawInfo.hDC);
  TRect itemRect(drawInfo.rcItem.left, drawInfo.rcItem.top,
                 drawInfo.rcItem.right, drawInfo.rcItem.bottom);

	if (drawInfo.itemState & ODS_SELECTED)
  	ODASelect(drawInfo);
  else
  	Draw(drawDC, itemRect, drawInfo.itemData, false);
}

void TNamedColorComboBox::ODAFocus(DRAWITEMSTRUCT &drawInfo)
{
  TDC drawDC(drawInfo.hDC);
  TRect itemRect(drawInfo.rcItem.left, drawInfo.rcItem.top,
                 drawInfo.rcItem.right, drawInfo.rcItem.bottom);

  drawDC.DrawFocusRect(itemRect);
	if (drawInfo.itemState & ODS_SELECTED)
  	ODASelect(drawInfo);
  else
  	Draw(drawDC, itemRect, drawInfo.itemData, false);
}

void TNamedColorComboBox::ODASelect(DRAWITEMSTRUCT &drawInfo)
{
  TDC drawDC(drawInfo.hDC);
  TRect itemRect(drawInfo.rcItem.left, drawInfo.rcItem.top,
                 drawInfo.rcItem.right, drawInfo.rcItem.bottom);

  if (drawInfo.itemState & ODS_SELECTED)
	  drawDC.FillRect(itemRect, TBrush(TColor::SysHighlight));
  else
	  drawDC.FillRect(itemRect, TBrush(TColor::SysWindow));

  Draw(drawDC, itemRect, drawInfo.itemData, drawInfo.itemState & ODS_SELECTED);
}

void TNamedColorComboBox::MeasureItem(MEASUREITEMSTRUCT &measureInfo)
{
	measureInfo.itemWidth = 40;
	measureInfo.itemHeight = 16;
}

void TNamedColorComboBox::CbnSelChanged()
{
	static TColor CustColors[16];

  uint32 data = GetItemData(GetSelIndex());

  if (data == (uint32)-1) {
    TChooseColorDialog::TData ColorData;

    ColorData.CustColors = CustColors;
    ColorData.Flags = 0;

    if (TChooseColorDialog(this, ColorData).Execute() == IDOK)
    	SelectColor(ColorData.Color);
    else
    	SetSelIndex(0);
  }

	// Give to parent the chance to receive this notification
  DefaultProcessing();
}

void TNamedColorComboBox::Draw(TDC &dc, TRect &rect, DWORD dwItemData, bool selected)
{
  TNamedColor *color = Colors[dwItemData];

	if (dwItemData == DWORD(-1))
   	DrawText(dc, rect.InflatedBy(-1, -1), "(Other...)", selected);
  else {
  	TRect r(rect.InflatedBy(-1, -1));
    TRect clrRect(r.TopLeft(), TSize(r.Height(), r.Height()));
    DrawColor(dc, clrRect, *color);
    TRect textRect(TPoint(clrRect.TopRight().x + 2, clrRect.TopRight().y), r.BottomRight());
    DrawText(dc, textRect, color->GetName(), selected);
  }
}

void TNamedColorComboBox::DrawColor(TDC &dc, TRect &rect, const TColor &color)
{
  dc.SelectObject(TBrush(color));
  dc.Rectangle(rect);
}

void TNamedColorComboBox::DrawText(TDC &dc, TRect &rect, const char *name, bool selected)
{
	dc.SetBkMode(TRANSPARENT);
	dc.SetTextColor(selected ? TColor::SysHighlightText : TColor::SysWindowText);
	dc.DrawText(name, -1, rect, DT_LEFT);
}


