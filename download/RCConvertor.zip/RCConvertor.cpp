// RCConvertor.cpp : Defines the entry point for the console application.
//

#ifdef _MSC_VER
#   pragma warning(disable:4786)
#endif

#include <string>
#include <cassert>
#include <strstream>
#include <fstream>
#include <direct.h>
#include <map>

using namespace std;

inline void PrintUsage()
{
    printf("Usage: \n progName nameoffile.rc targetdir\ne.g.:\n rcconvertor res\\myfile.rc res\n");
}

inline void ChangeSlashes(string& strStrippedFile)
{
  for (int i = 0; i < strStrippedFile.length(); ++i)
  {
    if (strStrippedFile[i] == '/')
      strStrippedFile[i] = '\\';
  }
}

inline void MakeUnixSlashes(char* strStrippedFile)
{
  char* pCurr = strStrippedFile;
  while (*pCurr)
  {
    if (*pCurr == '\\')
      *pCurr = '/';
    ++pCurr;
  }
}

inline string GetFileDir(const string& rsFileName)
{
  string::size_type pos = rsFileName.rfind('\\');
  return (pos == string::npos) ? string(".\\") : rsFileName.substr(0, pos);
}

typedef map<string, string> ResTypeMap;
ResTypeMap stResTypes;

void WriteBitmap(istream& is, ostream& os, string sTargetDir, 
                 string sIdentifier, string sResurce, string sExtension);

int main(int argc, char *argv[ ])
{
  if (argc < 2)
  {
    PrintUsage();
    return 1;
  }

  string sTargetDir;
  if (argc > 2)
    sTargetDir = argv[2];

  if (sTargetDir.empty())
    sTargetDir = "\\";
  else if (*sTargetDir.rbegin() != '\\')
    sTargetDir += '\\';

  FILE* fp = fopen(argv[1], "rb");
  if (!fp)
  {
    printf("Cannot open file");
    return 2;
  }

  string sFileDir = GetFileDir(argv[1]);

  stResTypes.insert(ResTypeMap::value_type("BITMAP", "BMP"));
  stResTypes.insert(ResTypeMap::value_type("CURSOR", "CUR"));
  stResTypes.insert(ResTypeMap::value_type("ICON", "ICO"));

  fseek(fp, 0, SEEK_END);
  int nSize = ftell(fp);
  fseek(fp, 0, SEEK_SET);
  auto_ptr<char> strBuf(new char[nSize]);
  size_t res = fread(strBuf.get(), 1, nSize, fp);
  assert(res == nSize);
  fclose(fp);

  istrstream in(strBuf.get(), nSize);
  ostrstream out;

  const int MAXLINE = 1024;
  char strLineBuf[MAXLINE];
  while(in)
  {
    try
    {
     in.getline(strLineBuf, MAXLINE);

     string sIdentifier;
     string sResType;
     string sResFile;

     istrstream sLine(strLineBuf);
     sLine >> sIdentifier;
     sLine >> sResType;
     if (sResType == "+") //e.g. IDB_X + 50
     {
       sIdentifier += "+";
       string strNext;
       sLine >> strNext;
       sIdentifier += strNext;
       sLine >> sResType;
     }
     ResTypeMap::const_iterator iter = stResTypes.find(sResType);
     if (iter == stResTypes.end())
       throw 0;

     if (!sLine || sLine.peek() == '\r') //We begin a data block
     {
       WriteBitmap(in, out, sTargetDir, sIdentifier, sResType, (*iter).second);
       continue;
     }

     sLine >> sResFile;
     if (sResFile.length() > 3)
     {
       //Whithout quates:
       string strStrippedFile = sResFile.substr(1, sResFile.length() - 2);
       ChangeSlashes(strStrippedFile);
       if (ifstream(strStrippedFile.c_str()))//if this is a real bitmap
       {
         MakeUnixSlashes(strLineBuf);
         throw 0;
       }

       char savedDir[_MAX_PATH];
       getcwd(savedDir, sizeof(savedDir));
       if (chdir(sFileDir.c_str()) != -1)
       {
         bool bFound = ifstream(strStrippedFile.c_str()).good();
         int nRes = chdir(savedDir);//now restore
         assert(nRes != -1);

         if (bFound) 
         {
           MakeUnixSlashes(strLineBuf);
           throw 0;
         }
       }
     }

     //Else we are in bitmap definition, just find "{"
     while (in && in.get() != '{')
       ;
     WriteBitmap(in, out, sTargetDir, sIdentifier, sResType, (*iter).second);
    }
    catch(int)
    {
       out << strLineBuf << endl;
    }
  }

  {
   char path_buffer[_MAX_PATH];
   char drive[_MAX_DRIVE];
   char dir[_MAX_DIR];
   char fname[_MAX_FNAME];
   char ext[_MAX_EXT];

   _splitpath( argv[1], drive, dir, fname, ext );
   _makepath( path_buffer, drive, dir, fname, ".bak");
   rename(argv[1], path_buffer);
  }
  if (FILE* fp = fopen(argv[1], "wb"))
  {
    size_t res = fwrite(out.str(), 1, out.tellp(), fp);
    fclose(fp);
  }
  return 0; 
}

bool IsHexDigit(const char ch)
{
  return (('0' <= ch) && (ch <= '9')) ||
         (('A' <= ch) && (ch <= 'F'));
}

unsigned GetHexDigit(const char ch)
{
  assert(IsHexDigit(ch));
  if (isdigit(ch))
    return unsigned(ch) - unsigned('0');
  else
    return unsigned(ch) - unsigned('A') + 10;
}

string MakeFileName(const string& rsIdentifier)
{
  char str[_MAX_PATH];
  ostrstream temp(str, sizeof(str));
  bool bPrevUndrscr = false;
  string::const_iterator it = rsIdentifier.begin();
  while (it != rsIdentifier.end())
  {
    if (*it == ' ' || *it == '+')
    {
      if (!bPrevUndrscr)
        temp << '_';
      bPrevUndrscr = true;
    }
    else
    {
      bPrevUndrscr = (*it == '_');
      temp << *it;
    }
    ++it;
  }
  temp << ends;
  temp.flush();
  str[sizeof(str) - 1 ] = 0;//in case of overflow

  return str;
}

void WriteBitmap(istream& is, ostream& os, string sTargetDir, 
                 string sIdentifier, string sResurce, string sExtension)
{
  char pszFile[_MAX_PATH];
  {//  "res\bmp\idb_test.bmp" :
    string sIdent = MakeFileName(sIdentifier);
    MakeFileName(sIdentifier);
    ostrstream(pszFile, sizeof(pszFile)) << sTargetDir << sExtension << '\\'
      << sIdent << '.' << sExtension << ends; 
  }
  pszFile[sizeof(pszFile) - 1] = 0;//If overflow in upper stream
  strlwr(pszFile);
  MakeUnixSlashes(pszFile);

  //Put the quated filename in the output:
  os << sIdentifier << ' ' << sResurce << ' ' << '\"' << pszFile << "\"\r" << endl;
  ofstream bmpFile(pszFile, ios::binary);
  while (is)
  {
    char chCurr = is.get();
    if (chCurr == '}')
      break;
    
    if (IsHexDigit(chCurr))
    {
      if (!is)
        break;
      char chNext = is.get();
      if (!IsHexDigit(chNext))
        break;
      unsigned nRes = GetHexDigit(chCurr)*16 + GetHexDigit(chNext);
      if (nRes > 255)
        break;

      unsigned char cRes = nRes;
      bmpFile.write((char*)&cRes, 1);
    }
  }
}
