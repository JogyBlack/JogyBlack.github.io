#include <owl/pch.h>
#pragma hdrstop

#include <owl/configfl.h>

#include "client.h"
#include "help.h"
#include "util.h"

#include "replacer.h"

#include "app.rh"                  // Definition of all resources.

const char regKeyName[] = "JogySoft\\ReplacePlus";

class TMyMemComboBox : public TMemComboBox
{
	public:    TMyMemComboBox(TWindow*          parent,                   int               resId,
                   const owl_string& name,
                   uint              textLimit = 255,
                   uint              itemLimit = 25,
                   TModule*          module = 0)
    : TMemComboBox(parent, resId, name, textLimit, itemLimit, module) {}

    TConfigFile* CreateConfigFile() { return new TRegConfigFile(regKeyName); }

    ~TMyMemComboBox() {}
};
////////////////////////////////////////////////////////////////////////////////

DEFINE_RESPONSE_TABLE1(ReplaceClient, TDialog)
  EV_BN_CLICKED(IDC_BROWSE, BnBrowseClicked),
  EV_BN_CLICKED(IDC_HLP, BnHelpClicked),
  EV_BN_CLICKED(IDC_ACTIONFIND, BnActionClicked),
  EV_BN_CLICKED(IDC_ACTIONTOUCH, BnActionClicked),
  EV_COMMAND(IDOK, CmOk),
END_RESPONSE_TABLE;

ReplaceClient::ReplaceClient(TWindow* parent, TResId resId, TModule* module)
: TDialog(parent, resId == TResId(0) ? TResId(IDD_CLIENT) : resId, module)
{
  gbOk = new TGlyphButton(this, IDOK, TGlyphButton::btOk);                 // Ok
  gbOk->SetLayoutStyle(TGlyphButton::lsH_GST);
  gbCancel = new TGlyphButton(this, IDCANCEL, TGlyphButton::btCancel);         // Cancel
  gbCancel->SetLayoutStyle(TGlyphButton::lsH_GST);

  gbBrowse = new TGlyphButton(this, IDC_BROWSE, TGlyphButton::btBrowse);
  gbBrowse->SetLayoutStyle(TGlyphButton::lsH_GST);

  gbHelp = new TGlyphButton(this, IDC_HLP, TGlyphButton::btHelp);
  gbHelp->SetLayoutStyle(TGlyphButton::lsH_GST);

  comboFolder = new TMyMemComboBox(this, IDC_FOLDER, "Folder");
  comboFilter = new TMyMemComboBox(this, IDC_FILTER, "Filter");
  comboFind = new TMyMemComboBox(this, IDC_FIND, "Find");
  comboReplace = new TMyMemComboBox(this, IDC_REPLACE, "Replace");

  pickerTime = new TDateTimePicker(this, IDC_EDITTIME);
  pickerDate = new TDateTimePicker(this, IDC_EDITDATE);

  radioFind = new TRadioButton(this, IDC_ACTIONFIND);
  radioTouch = new TRadioButton(this, IDC_ACTIONTOUCH);

  checkSubfolders = new TCheckBox(this, IDC_SUBFOLDERS);
  checkCaseSensitive = new TCheckBox(this, IDC_CASESENSITIVE);
  checkWholeWords = new TCheckBox(this, IDC_WHOLEWORDS);
  checkCreateBackups = new TCheckBox(this, IDC_CREATEBACKUPS);

  stFind = new TStatic(this, IDC_ST_FIND);
  stReplace = new TStatic(this, IDC_ST_REPLACE);
  stTime = new TStatic(this, IDC_ST_TIME);

  tooltip = new TTooltip(this);
}

ReplaceClient::~ReplaceClient()
{
  Destroy();
}

void ReplaceClient::SetupWindow()
{
	TDialog::SetupWindow();  TRegConfigFile configFile(regKeyName);  TConfigFileSection configSection(configFile, "Options");  bool subfolders = configSection.ReadBool("Subfolders", true);
  bool caseSensitive = configSection.ReadBool("CaseSensitive", true);  bool wholeWords = configSection.ReadBool("WholeWords", true);  bool createBackups = configSection.ReadBool("CreateBackups", false);  int action = configSection.ReadInteger("Action", 1);  switch (action)  {    default:    case 1:      radioFind->SetCheck(BF_CHECKED);      radioTouch->SetCheck(BF_UNCHECKED);
      break;

    case 2:
      radioFind->SetCheck(BF_UNCHECKED);
      radioTouch->SetCheck(BF_CHECKED);
      break;
  }

  checkSubfolders->SetCheck(subfolders ? BF_CHECKED : BF_UNCHECKED);
  checkCaseSensitive->SetCheck(caseSensitive ? BF_CHECKED : BF_UNCHECKED);
  checkWholeWords->SetCheck(wholeWords ? BF_CHECKED : BF_UNCHECKED);
  checkCreateBackups->SetCheck(createBackups ? BF_CHECKED : BF_UNCHECKED);

  ReplaceData &replaceData = ReplaceData::GetInstance();

  InitCombo(replaceData.GetFolder(), comboFolder);
  InitCombo(replaceData.GetFilter(), comboFilter);
  InitCombo(replaceData.GetFind(), comboFind);
  InitCombo(replaceData.GetReplace(), comboReplace);

  // If all fields are initialized, perform the operation
  //   without showing the dialog
  if (replaceData.GetReplace())
  {
    Perform(false);
    PostQuitMessage(0);
  }

  // Add tooltips to various controls
  tooltip->AddTool(TToolInfo(*this, *gbOk, "Perform the action"));
  tooltip->AddTool(TToolInfo(*this, *gbCancel, "Close the program"));

  tooltip->AddTool(TToolInfo(*this, *gbBrowse, "Browse for folder"));
  tooltip->AddTool(TToolInfo(*this, *checkSubfolders, "Recurse subfolders of chosen folder"));

  tooltip->AddTool(TToolInfo(*this, *radioFind, "Find and replace text in files"));
  tooltip->AddTool(TToolInfo(*this, *radioTouch, "Change file date/time"));

  tooltip->AddTool(TToolInfo(*this, *comboFolder, "Enter start folder or select from recent list"));
  tooltip->AddTool(TToolInfo(*this, *comboFilter, "Enter filters like *.cpp;*.c;*.h or select from recent list"));

  tooltip->Activate();

  BnActionClicked();
}

void ReplaceClient::InitCombo(const char *str, TComboBox *combo)
{
  if (str)
  	combo->SetText(str);
  else if (combo->GetCount() > 0)
  	combo->SetSelIndex(0);
}

bool ReplaceClient::PreProcessMsg(MSG &msg)
{
// This code is taken from the book Core OWL by Ted Neward
  if (tooltip && tooltip->IsWindow())    tooltip->RelayEvent(msg);  return TDialog::PreProcessMsg(msg);}

void ReplaceClient::BnBrowseClicked()
{
  TAPointer<char> buf = new char[MAX_PATH];

  comboFolder->GetText(buf, MAX_PATH);

  if (BrowseForFolder(GetHandle(), buf, "Select folder"))
    comboFolder->SetText(buf);
}

void ReplaceClient::BnActionClicked()
{
  bool bFindAction = (radioFind->GetCheck() == BF_CHECKED);

  comboFind->EnableWindow(bFindAction);
  comboReplace->EnableWindow(bFindAction);
  checkCaseSensitive->EnableWindow(bFindAction);
  checkWholeWords->EnableWindow(bFindAction);
  checkCreateBackups->EnableWindow(bFindAction);
  comboFind->ShowWindow(bFindAction ? SW_SHOW : SW_HIDE);
  comboReplace->ShowWindow(bFindAction ? SW_SHOW : SW_HIDE);
  stFind->ShowWindow(bFindAction ? SW_SHOW : SW_HIDE);
  stReplace->ShowWindow(bFindAction ? SW_SHOW : SW_HIDE);
  checkCaseSensitive->ShowWindow(bFindAction ? SW_SHOW : SW_HIDE);
  checkWholeWords->ShowWindow(bFindAction ? SW_SHOW : SW_HIDE);
  checkCreateBackups->ShowWindow(bFindAction ? SW_SHOW : SW_HIDE);

  pickerTime->EnableWindow(!bFindAction);
  pickerDate->EnableWindow(!bFindAction);
  pickerTime->ShowWindow(!bFindAction ? SW_SHOW : SW_HIDE);
  pickerDate->ShowWindow(!bFindAction ? SW_SHOW : SW_HIDE);
  stTime->ShowWindow(!bFindAction ? SW_SHOW : SW_HIDE);
}

void ReplaceClient::CmOk()
{
  Perform(true);

//	TDialog::CmOk();
}

void ReplaceClient::BnHelpClicked()
{
  THelpDialog(this).Execute();
}

void ReplaceClient::Perform(bool showResult)
{
  TAPointer<char> folder = new char[MAX_PATH];
  TAPointer<char> filter = new char[MAX_PATH];

  comboFolder->GetText(folder, MAX_PATH);
  comboFilter->GetText(filter, MAX_PATH);

  if (folder[0] == '\0')
  {
    MessageBox("Enter folder.");
    return;
  }

  if (filter[0] == '\0')
  {
    MessageBox("Enter filter.");
    return;
  }

  bool subfolders = (checkSubfolders->GetCheck() == BF_CHECKED);
  bool caseSensitive = (checkCaseSensitive->GetCheck() == BF_CHECKED);
  bool wholeWords = (checkWholeWords->GetCheck() == BF_CHECKED);
  bool createBackups = (checkCreateBackups->GetCheck() == BF_CHECKED);

  TRegConfigFile configFile(regKeyName);
  TConfigFileSection configSection(configFile, "Options");

  if (radioFind->GetCheck() == BF_CHECKED)
  {
    TAPointer<char> search = new char[MAX_PATH];
    TAPointer<char> replace = new char[MAX_PATH];

    comboFind->GetText(search, MAX_PATH);
    comboReplace->GetText(replace, MAX_PATH);

    if (search[0] == '\0')
    {
      MessageBox("Enter search string.");
      return;
    }

    if (replace[0] == '\0')
    {
      MessageBox("Enter replace string.");
      return;
    }

    configSection.WriteBool("Subfolders", subfolders);
    configSection.WriteBool("CaseSensitive", caseSensitive);
    configSection.WriteBool("WholeWords", wholeWords);
    configSection.WriteBool("CreateBackups", createBackups);
    configSection.WriteInteger("Action", 1);

    Replacer replacer(search, replace, caseSensitive, wholeWords, createBackups);

    if (FileRecurser(folder, filter, subfolders, &replacer).RecurseFolders())
      if (showResult)
        replacer.ReportResults(this);
  }
  else
  {
    TSystemTime time, date;    pickerTime->GetTime(time);    pickerDate->GetTime(date);

    TTime filetime(date, time.GetHour(), time.GetMinute(), time.GetSecond());

    TFileTime ft(filetime);
    ft.ToUniversalTime();

    filetime = ft;

    configSection.WriteBool("Subfolders", subfolders);
//    configSection.WriteBool("CaseSensitive", caseSensitive);
//    configSection.WriteBool("WholeWords", wholeWords);
//    configSection.WriteBool("CreateBackups", createBackups);
    configSection.WriteInteger("Action", 2);

    Toucher toucher(filetime);

    if (FileRecurser(folder, filter, subfolders, &toucher).RecurseFolders())
      if (showResult)
        toucher.ReportResults(this);
  }
}

