#if !defined(client_h)              // Sentry, use file only if it's not already included.
#define client_h

#include <owl\radiobut.h>
#include <owl\glyphbtn.h>
#include <owl\memcbox.h>
#include <owl\datetime.h>
#include <owl\static.h>
#include <owl\tooltip.h>

class ReplaceClient : public TDialog
{
  public:
    ReplaceClient(TWindow* parent, TResId resId = TResId(0), TModule* module = 0);
    virtual ~ReplaceClient();

  protected:
    void SetupWindow();

    bool PreProcessMsg(MSG &msg);

    void BnBrowseClicked();
    void BnActionClicked();
    void BnHelpClicked();
    void CmOk();

    // Init the combo box edit field with the given string or the first selection
		void InitCombo(const char *str, TComboBox *combo);
    
    void Perform(bool showResult);

    TGlyphButton *gbOk;
    TGlyphButton *gbCancel;
    TGlyphButton *gbBrowse;
    TGlyphButton *gbHelp;

    TMemComboBox *comboFolder;
    TMemComboBox *comboFilter;
    TMemComboBox *comboFind;
    TMemComboBox *comboReplace;

    TDateTimePicker *pickerTime;
    TDateTimePicker *pickerDate;

    TRadioButton *radioFind;
    TRadioButton *radioTouch;

    TCheckBox *checkSubfolders;
    TCheckBox *checkCaseSensitive;
    TCheckBox *checkWholeWords;
    TCheckBox *checkCreateBackups;

    TStatic *stFind;
    TStatic *stReplace;
    TStatic *stTime;

    TTooltip *tooltip;

DECLARE_RESPONSE_TABLE(ReplaceClient);
};


#endif  // client_h sentry.
