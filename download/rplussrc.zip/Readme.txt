ReplacePlus by Jogy

This is an application, which recurses folders and files
which match the given filters,
and performs search\replace or changes file date and time.
It can be used from batch file.


It demostrates the following OWL/OWLNext classes:

- TMemComboBox and TRegConfigFile to remember previous user entries

- TDateTimePicker to enter date and time

- TShell::SHBrowseForFolder to select staring folder

- TFileNameIterator to iterate files and folders

- TFileName for creating temporary files, copying files
            and changing file date and time

- TGlyphButton and TTooltip to add more colorful view to the dialog


Revision history:
v 1.1
 - Added options for case sensitive search, for whole words only search
   and backup of the files.

v 1.0
 - Initial version.

