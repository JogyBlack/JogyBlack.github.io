//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include <graphics.hpp>

#include <sstream>
#include <fstream>

#include "Main.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFormMain *FormMain;
//---------------------------------------------------------------------------
__fastcall TFormMain::TFormMain(TComponent* Owner)
  : TForm(Owner)
{
  BitBtnConvert->Enabled = false;
  BitBtnSave->Enabled = false;
  CheckBoxUseMask->Enabled = false;
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::BitBtnQuitClick(TObject *Sender)
{
  Close();  
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::ButtonBrowseInputFileClick(TObject *Sender)
{
  OpenDialogInputFile->FileName = LabeledEditInputImage->Text;

  if (OpenDialogInputFile->Execute())
    LabeledEditInputImage->Text = OpenDialogInputFile->FileName;
}
//---------------------------------------------------------------------------
unsigned int GetGrayValue(TColor color)
{
  COLORREF clr = ColorToRGB(color);

  unsigned int r = GetRValue(clr);
  unsigned int g = GetGValue(clr);
  unsigned int b = GetBValue(clr);

  return (r * 77 + g * 150 + b * 29) / 256;
}

void __fastcall TFormMain::BitBtnConvertClick(TObject *Sender)
{
  MemoOutput->Lines->Clear();

  Graphics::TBitmap *bitmap = new Graphics::TBitmap;

  bitmap->LoadFromFile(LabeledEditInputImage->Text);

  ImagePreview->Picture->Bitmap = new Graphics::TBitmap(*bitmap);

  if (!bitmap->Empty)
  {
    Graphics::TBitmap *mask = 0;

    if (!LabeledEditInputMask->Text.IsEmpty() && CheckBoxUseMask->Checked)
    {
      mask = new Graphics::TBitmap;
      mask->LoadFromFile(LabeledEditInputMask->Text);

      if (mask->Empty)
      {
        Application->MessageBox("Cannot load the mask", "Error", MB_OK | MB_ICONSTOP);
        delete mask;
        mask = 0;
      }

      if (mask->Width != bitmap->Width || mask->Height != bitmap->Height)
      {
        Application->MessageBox("Mask dimensions differ from image", "Error", MB_OK | MB_ICONSTOP);
        delete mask;
        mask = 0;
      }
    }

    if (mask)
      ImageMask->Picture->Bitmap = new Graphics::TBitmap(*mask);
    else
      ImageMask->Picture->Bitmap = new Graphics::TBitmap();

    TCursor cursor = Screen->Cursor;
    Screen->Cursor = crHourGlass;
    MemoOutput->Visible = false;

    bool isSource = (RadioGroupOutput->ItemIndex == 1);
    bool isVRML = (RadioGroupOutput->ItemIndex == 2);

    bool isGrayScale = (RadioGroupColors->ItemIndex == 1);

    int nPixelsPerLine = atoi(LabeledEditPixelsPerLine->Text.c_str());

    int nPixels;

    if (isVRML)
    {
      MemoOutput->Lines->Add("#VRML V2.0 utf8");
      MemoOutput->Lines->Add("DEF TEXTURE PixelTexture {");
    }

    std::ostringstream s;

    if (isSource)
      s << "  \"";

    s << "image " << bitmap->Width << " " << bitmap->Height << " ";

    if (isGrayScale)
    {
      if (mask)
        s << "2";
      else
        s << "1";
    }
    else
    {
      if (mask)
        s << "4";
      else
        s << "3";
    }

    if (isSource)
      s << "\\n\"";

    MemoOutput->Lines->Add(AnsiString(s.str().c_str()));
    s.str("");

    for (int y = 0; y < bitmap->Height; y++)
    {
      nPixels = 0;

      if (isSource)
        s << "  \"";

      for (int x = 0; x < bitmap->Width; x++)
      {
        TColor color = bitmap->Canvas->Pixels[x][bitmap->Height - y - 1];

        unsigned int val;

        if (isGrayScale)
        {
          val = GetGrayValue(color);
        }
        else
        {
          COLORREF clr = ColorToRGB(color);

          unsigned int r = GetRValue(clr);
          unsigned int g = GetGValue(clr);
          unsigned int b = GetBValue(clr);

          val = r * 65536 + g * 256 + b;
        }

        if (mask)
        {
          unsigned int maskval = GetGrayValue(mask->Canvas->Pixels[x][bitmap->Height - y - 1]);
          val = val * 256 + maskval;          
        }

        s << "0x" << std::hex << val;

        nPixels++;

        if (nPixels >= nPixelsPerLine)
        {
          if (isSource)
            s << "\\n\"";

          AnsiString str = s.str().c_str();
          if (CheckBoxUppercase->Checked)
            str = str.UpperCase();
          MemoOutput->Lines->Add(str);
          s.str("");

          nPixels = 0;
        }
        else
          s << " ";
      }

      if (isSource)
        s << "\\n\"";

      AnsiString str = s.str().c_str();
      if (CheckBoxUppercase->Checked)
        str = str.UpperCase();
      MemoOutput->Lines->Add(str);
      s.str("");
    }

    if (isVRML)
    {
      MemoOutput->Lines->Add("}");
      MemoOutput->Lines->Add("Shape {");
      MemoOutput->Lines->Add("  appearance Appearance {");
      MemoOutput->Lines->Add("    material Material {}");
      MemoOutput->Lines->Add("    texture USE TEXTURE");
      MemoOutput->Lines->Add("  }");
      MemoOutput->Lines->Add("  geometry Box {}");
      MemoOutput->Lines->Add("}");
    }

    MemoOutput->Visible = true;
    Screen->Cursor = cursor;
    BitBtnSave->Enabled = true;

    if (mask)
      delete mask;
  }
  else
  {
    Application->MessageBox("Cannot load the bitmap", "Error", MB_OK | MB_ICONSTOP);
    BitBtnSave->Enabled = false;
  }

  delete bitmap;
}
//---------------------------------------------------------------------------
void __fastcall TFormMain::ButtonBrowseInputMaskClick(TObject *Sender)
{
  OpenDialogInputFile->FileName = LabeledEditInputMask->Text;

  if (OpenDialogInputFile->Execute())
    LabeledEditInputMask->Text = OpenDialogInputFile->FileName;
}
//---------------------------------------------------------------------------


void __fastcall TFormMain::LabeledEditInputImageChange(TObject *Sender)
{
  BitBtnConvert->Enabled = !LabeledEditInputImage->Text.IsEmpty();
}
//---------------------------------------------------------------------------

void __fastcall TFormMain::LabeledEditInputMaskChange(TObject *Sender)
{
  CheckBoxUseMask->Enabled = !LabeledEditInputMask->Text.IsEmpty();
}
//---------------------------------------------------------------------------

void __fastcall TFormMain::BitBtnSaveClick(TObject *Sender)
{
  switch (RadioGroupOutput->ItemIndex)
  {
    case 0:
      SaveDialogOutputFile->FilterIndex = 1;
      break;

    case 1:
      SaveDialogOutputFile->FilterIndex = 2;
      break;

    case 2:
      SaveDialogOutputFile->FilterIndex = 4;
      break;

  }


  if (SaveDialogOutputFile->Execute())
  {
    std::ofstream ofs(SaveDialogOutputFile->FileName.c_str());

    if (!ofs)
    {
      Application->MessageBox("Cannot create output file", "Error", MB_OK | MB_ICONSTOP);

      return;
    }

    for (int index = 0; index < MemoOutput->Lines->Count; index++)
      ofs << MemoOutput->Lines->Strings[index].c_str() << std::endl;

    ofs.close();

    if (RadioGroupOutput->ItemIndex == 2)
    {
      ShellExecute(Handle, NULL, SaveDialogOutputFile->FileName.c_str(), NULL, "", SW_SHOW);
    }
  }
}
//---------------------------------------------------------------------------

void __fastcall TFormMain::BitBtnAboutClick(TObject *Sender)
{
  Application->MessageBox("Convert bitmap images to VRML PixelTexture node\n\nCopyright (c) 2003 by Jogy",
                          "VRML PixelTexture Converter", MB_OK);
}
//---------------------------------------------------------------------------

