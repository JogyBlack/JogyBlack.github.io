//---------------------------------------------------------------------------

#ifndef MainH
#define MainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Buttons.hpp>
#include <Dialogs.hpp>
#include <ComCtrls.hpp>
//---------------------------------------------------------------------------
class TFormMain : public TForm
{
__published:	// IDE-managed Components
  TButton *ButtonBrowseInputFile;
  TBitBtn *BitBtnConvert;
  TBitBtn *BitBtnQuit;
  TOpenDialog *OpenDialogInputFile;
  TPageControl *PageControlOutput;
  TTabSheet *TabSheetOutput;
  TMemo *MemoOutput;
  TTabSheet *TabSheetPreview;
  TScrollBox *ScrollBoxPreview;
  TImage *ImagePreview;
  TButton *ButtonBrowseInputMask;
  TCheckBox *CheckBoxUseMask;
  TRadioGroup *RadioGroupColors;
  TRadioGroup *RadioGroupOutput;
  TLabeledEdit *LabeledEditPixelsPerLine;
  TUpDown *UpDownPixelsPerLine;
  TLabeledEdit *LabeledEditInputImage;
  TLabeledEdit *LabeledEditInputMask;
  TCheckBox *CheckBoxUppercase;
  TBitBtn *BitBtnSave;
  TBitBtn *BitBtnAbout;
  TSaveDialog *SaveDialogOutputFile;
  TTabSheet *TabSheetMask;
  TScrollBox *ScrollBoxMask;
  TImage *ImageMask;
  void __fastcall BitBtnQuitClick(TObject *Sender);
  void __fastcall ButtonBrowseInputFileClick(TObject *Sender);
  void __fastcall BitBtnConvertClick(TObject *Sender);
  void __fastcall ButtonBrowseInputMaskClick(TObject *Sender);
  void __fastcall LabeledEditInputImageChange(TObject *Sender);
  void __fastcall LabeledEditInputMaskChange(TObject *Sender);
  void __fastcall BitBtnSaveClick(TObject *Sender);
  void __fastcall BitBtnAboutClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
  __fastcall TFormMain(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFormMain *FormMain;
//---------------------------------------------------------------------------
#endif
